// Compane API on Supabase: the same rules as the local Java API, served by one Edge Function.
// Every rule lives in the database functions; this layer only checks who is signed in and passes calls on.
import postgres from "npm:postgres@3.4.5";

const sql = postgres(Deno.env.get("SUPABASE_DB_URL")!, { prepare: false, max: 4, idle_timeout: 20 });
const RESEND_KEY = (Deno.env.get("RESEND_API_KEY") ?? "").trim();
const RESEND_FROM = (Deno.env.get("RESEND_FROM") ?? "").trim();
const DEMO_PEOPLE = (Deno.env.get("SAMPLE_PEOPLE") ?? Deno.env.get("DEMO_PEOPLE") ?? "false").trim().toLowerCase() === "true";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "content-type, x-compane-session, x-acting-user, authorization, apikey",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
};

class HttpError extends Error {
  constructor(public status: number, message: string) { super(message); }
}
const bad = (m: string) => new HttpError(400, m);
const json = (data: unknown, status = 200) =>
  new Response(typeof data === "string" ? data : JSON.stringify(data), { status, headers: { ...CORS, "Content-Type": "application/json" } });

// ---------- SQL helpers: "?" placeholders, as in the Java version ----------
// JSON goes in as text (?::text::jsonb) so the driver never encodes it a second time.
async function one(text: string, ...args: unknown[]): Promise<unknown> {
  let n = 0;
  const q = text.replace(/\?/g, () => `$${++n}`);
  const rows = await sql.unsafe(q, args as never[]);
  if (!rows.length) return null;
  const v = Object.values(rows[0])[0];
  return v;
}
async function rows(text: string, ...args: unknown[]) {
  let n = 0;
  const q = text.replace(/\?/g, () => `$${++n}`);
  return await sql.unsafe(q, args as never[]);
}
const raw = (v: unknown) => (v === null || v === undefined ? "null" : typeof v === "string" ? v : JSON.stringify(v));
const ok = { ok: true };

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
function uuid(v: unknown, label: string): string {
  const s = String(v ?? "").trim();
  if (!UUID.test(s)) throw bad(`${label} is not a valid ID`);
  return s;
}
type Body = Record<string, unknown>;
const text = (b: Body, k: string) => (b[k] === null || b[k] === undefined || String(b[k]).trim() === "" ? null : String(b[k]));
const req = (b: Body, k: string, label: string) => { if (text(b, k) === null) throw bad(`${label} is required`); return uuid(b[k], label); };
const opt = (b: Body, k: string, label: string) => (text(b, k) === null ? null : uuid(b[k], label));
function isoDate(v: unknown, label: string) {
  const s = String(v ?? "").trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) throw bad(`${label} must be a date (YYYY-MM-DD)`);
  return s;
}
const date = (b: Body, k: string) => (text(b, k) === null ? null : isoDate(b[k], "Due date"));
function num(b: Body, k: string) {
  const v = text(b, k);
  if (v === null) return null;
  if (isNaN(Number(v))) throw bad(`${k.replace("_", " ")} must be a number`);
  return v.trim();
}
const js = (v: unknown) => JSON.stringify(v ?? {});

// ---------- who is asking ----------
async function sessionUser(r: Request): Promise<string | null> {
  const t = r.headers.get("x-compane-session");
  if (!t) return null;
  const u = await one("SELECT user_id::text FROM app_session WHERE token = ? AND expires_at > now()", t);
  return (u as string) ?? null;
}
async function actor(r: Request): Promise<string> {
  const me = await sessionUser(r);
  const as = r.headers.get("x-acting-user");
  if (as && UUID.test(as)) {
    if (DEMO_PEOPLE) return as;
    if (me && (as === me || (await one("SELECT is_super(?::uuid)", me)))) return as;
  }
  if (!me) throw new HttpError(401, "Sign in first");
  return me;
}
async function newSession(userId: string) {
  const token = crypto.randomUUID() + crypto.randomUUID().replaceAll("-", "");
  await rows("INSERT INTO app_session (token, user_id) VALUES (?, ?::uuid)", token, userId);
  return token;
}

// ---------- codes by email (Resend) ----------
const PURPOSE: Record<string, string> = {
  access: "to sign in to Yousr", signin: "to sign in", create_user_email: "to create your account",
  mobile: "to confirm your mobile (the SMS service is not connected yet, so it comes by email)",
  work_email: "to confirm the entity's work email", create_entity_personal: "to confirm your personal email for the new entity",
  join_work: "to join the entity with your work email", invite_sender: "to send an invite",
  connect_inviter: "to send a connection invite", connect_accept: "to accept a connection", business_model: "to change the Business Model",
};
async function sendCode(to: string, code: string, purpose: string) {
  const html = `<div style="font-family:Arial,sans-serif;font-size:15px;color:#1c1b1a"><p>Your one-time code ${PURPOSE[purpose] ?? "to continue"} is</p>`
    + `<p style="font-size:28px;letter-spacing:6px;font-weight:bold">${code}</p><p style="color:#75736f">It works once. If you did not ask for it, ignore this email.</p></div>`;
  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${RESEND_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({ from: RESEND_FROM, to: [to], subject: `Your Yousr code: ${code}`, html }),
  });
  if (!res.ok) throw bad(`The email could not be sent (${res.status}). Check the Resend key and the sender's domain.`);
}

// ---------- the table API (Masters), same rules as the Java version ----------
type Col = { name: string; label: string; type: string; required: boolean; options: string[] | null; expr: string | null; virtual: boolean };
type Ent = { key: string; table: string; pk: string; pkLabel: string; label: string; orderBy: string; readOnly: boolean; design: boolean; openToAll: boolean; cols: Col[] };
let META: { entities: Ent[]; statuses: string[] } | null = null;
async function meta() {
  if (!META) META = (await one("SELECT meta FROM app_registry WHERE id = 1")) as typeof META;
  return META!;
}
async function ent(key: string): Promise<Ent> {
  const e = (await meta()).entities.find((x) => x.key === key);
  if (!e) throw new HttpError(404, `Unknown table: ${key}`);
  return e;
}
function selectList(e: Ent) {
  const parts = [`${e.pk}::text AS ${e.pk}`];
  for (const c of e.cols) {
    if (c.virtual) continue;
    if (c.expr) { parts.push(`${c.expr} AS ${c.name}`); continue; }
    if (c.type === "INT" || c.type === "BOOL") parts.push(c.name);
    else if (c.type === "UUIDS" || c.type === "ENUMS") parts.push(`COALESCE(array_to_json(${c.name}), '[]'::json) AS ${c.name}`);
    else parts.push(`${c.name}::text AS ${c.name}`);
  }
  return parts.join(", ");
}
const CASTS: Record<string, string> = { UUID: "::uuid", DATE: "::date", UUIDS: "::uuid[]", ENUMS: "::text[]" };
const mark = (c: Col, i: number) => `$${i}` + (CASTS[c.type] ?? "");
function convert(c: Col, v: unknown, statuses: string[]): unknown {
  if (v === null || v === undefined) return null;
  if (typeof v === "string" && v.trim() === "" && c.type !== "UUIDS" && c.type !== "ENUMS") return null;
  switch (c.type) {
    case "UUID": return uuid(v, c.label);
    case "DATE": return isoDate(v, c.label);
    case "INT": { const n = Number(v); if (!Number.isInteger(n)) throw bad(`${c.label} must be a whole number`); return n; }
    case "BOOL": return typeof v === "boolean" ? v : String(v) === "true";
    case "STATUS": if (!statuses.includes(String(v))) throw bad(`Status must be one of ${statuses.join(", ")}`); return String(v);
    case "UUIDS": if (!Array.isArray(v)) throw bad(`${c.label} must be a list of IDs`); return `{${[...new Set(v.map((x) => uuid(x, c.label)))].join(",")}}`;
    case "ENUM": if (!(c.options ?? []).includes(String(v))) throw bad(`${c.label} must be one of ${(c.options ?? []).join(", ")}`); return String(v);
    case "ENUMS": {
      if (!Array.isArray(v)) throw bad(`${c.label} must be a list`);
      const q = [...new Set(v.map(String))].map((x) => { if (!(c.options ?? []).includes(x)) throw bad(`${c.label} must be from ${(c.options ?? []).join(", ")}`); return `"${x.replace(/\\/g, "\\\\").replace(/"/g, '\\"')}"`; });
      return `{${q.join(",")}}`;
    }
    default: return String(v);
  }
}
async function checkWrite(e: Ent, who: string, body: Body | null, id: string | null) {
  if (e.readOnly) throw bad(`${e.label} changes only through actions, not by direct edits`);
  if (e.design) {
    if (e.key === "krama" && id === null) {
      const owner = body?.owner_entity;
      delete body!.status; delete body!.version; delete body!.pool_mark;
      if (owner === null || owner === undefined || String(owner).trim() === "") {
        if (!(await one("SELECT is_super(?::uuid)", who))) throw new HttpError(403, "Only the platform super-user builds platform Kramas");
        delete body!.owner_entity;
        return;
      }
      if (!(await one("SELECT is_entity_super(?::uuid, ?::uuid)", who, uuid(owner, "Owner entity")))) throw new HttpError(403, "Only that entity's super-user builds its Kramas");
      body!.ownership_type = "Entity Built Entity Owned";
      body!.pool_mark = "Entity Built";
      return;
    }
    const rowJson = id === null ? js(body)
      : raw(await one(`SELECT row_to_json(t)::text FROM ${e.table} t WHERE ${e.pk} = ?::uuid`, uuid(id, e.pkLabel)));
    if (id !== null && body && e.key !== "krama") {
      if (!(await one("SELECT COALESCE(can_design(?::uuid, design_krama(?, ?::text::json)), true)", who, e.key, js(body)))) throw new HttpError(403, "You cannot change this Krama");
    }
    if (!(await one("SELECT COALESCE(can_design(?::uuid, design_krama(?, ?::text::json)), false)", who, e.key, rowJson))) throw new HttpError(403, "You cannot change this Krama");
    return;
  }
  if (!(await one("SELECT is_super(?::uuid)", who))) throw new HttpError(403, "Only the platform super-user can change masters");
}
async function crud(r: Request, method: string, key: string, id: string | null, body: Body | null) {
  const e = await ent(key);
  const m = await meta();
  const fetchRow = async (rid: string) => (await rows(`SELECT ${selectList(e)} FROM ${e.table} WHERE ${e.pk} = $1::uuid`, rid))[0];
  if (method === "GET") {
    if (!e.openToAll) {
      const who = await actor(r);
      if (!(await one("SELECT is_super(?::uuid)", who))) throw new HttpError(403, `You do not have access to ${e.label}`);
    } else if (!DEMO_PEOPLE) await actor(r);
    if (id) {
      const row = await fetchRow(uuid(id, e.pkLabel));
      if (!row) throw new HttpError(404, `${e.label} not found`);
      return json(row);
    }
    return json(await rows(`SELECT ${selectList(e)} FROM ${e.table} ORDER BY ${e.orderBy}`));
  }
  const who = await actor(r);
  if (method === "DELETE") {
    await checkWrite(e, who, null, id);
    const res = await rows(`DELETE FROM ${e.table} WHERE ${e.pk} = $1::uuid RETURNING 1`, uuid(id, e.pkLabel));
    if (!res.length) throw new HttpError(404, `${e.label} not found`);
    return new Response(null, { status: 204, headers: CORS });
  }
  body = body ?? {};
  if (method === "POST") {
    await checkWrite(e, who, body, null);
    const names: string[] = [], marks: string[] = [], args: unknown[] = [];
    for (const c of e.cols) {
      if (c.expr || c.virtual) continue;
      const v = convert(c, body[c.name], m.statuses);
      if (v === null) { if (c.required) throw bad(`${c.label} is required`); continue; }
      names.push(c.name); args.push(v); marks.push(mark(c, args.length));
    }
    const q = names.length
      ? `INSERT INTO ${e.table} (${names.join(", ")}) VALUES (${marks.join(", ")}) RETURNING ${e.pk}::text AS id`
      : `INSERT INTO ${e.table} DEFAULT VALUES RETURNING ${e.pk}::text AS id`;
    const nid = (await sql.unsafe(q, args as never[]))[0].id as string;
    return json(await fetchRow(nid), 201);
  }
  if (method === "PUT") {
    if (e.key === "krama") for (const k of ["owner_entity", "ownership_type", "status", "version", "pool_mark"]) delete body[k];
    await checkWrite(e, who, body, id);
    const sets: string[] = [], args: unknown[] = [];
    for (const c of e.cols) {
      if (c.expr || c.virtual || !(c.name in body)) continue;
      let v = convert(c, body[c.name], m.statuses);
      if (v === null && c.required) throw bad(`${c.label} is required`);
      if (v === null && (c.type === "UUIDS" || c.type === "ENUMS")) v = "{}";
      if (v === null && c.type === "BOOL") v = false;
      if (v === null && c.type === "STATUS") v = m.statuses[0];
      args.push(v); sets.push(`${c.name} = ${mark(c, args.length)}`);
    }
    if (!sets.length) throw bad("Nothing to update");
    args.push(uuid(id, e.pkLabel));
    const res = await sql.unsafe(`UPDATE ${e.table} SET ${sets.join(", ")} WHERE ${e.pk} = $${args.length}::uuid RETURNING 1`, args as never[]);
    if (!res.length) throw new HttpError(404, `${e.label} not found`);
    return json(await fetchRow(id!));
  }
  throw new HttpError(405, "Not allowed");
}

// ---------- routes ----------
async function route(r: Request): Promise<Response> {
  const url = new URL(r.url);
  const path = url.pathname.replace(/^\/functions\/v1/, "").replace(/^\/api/, "") || "/";
  const p = path.split("/").filter(Boolean);
  const m = r.method;
  const body: Body = m === "GET" || m === "DELETE" ? {} : await r.json().catch(() => ({}));
  const A = () => actor(r);

  // sign-in and session
  if (p[0] === "meta") return json(await meta());
  if (p[0] === "me") { const u = await sessionUser(r); return json(u ? { user_id: u } : null); }
  if (p[0] === "sign-out") { const t = r.headers.get("x-compane-session"); if (t) await rows("DELETE FROM app_session WHERE token = ?", t); return json(ok); }
  if (p[0] === "demo-signin") {
    if (!DEMO_PEOPLE) throw new HttpError(403, "Sample people are switched off");
    return json({ session: await newSession(req(body, "user_id", "Person")) });
  }
  if (p[0] === "do") {
    const fn = p[1] ?? "";
    if (!/^[a-z_]{2,60}$/.test(fn)) throw new HttpError(404, "Unknown action");
    if (fn === "app_config") return json({ demo_people: DEMO_PEOPLE, codes_by_email: !!(RESEND_KEY && RESEND_FROM) });
    if (!(await one("SELECT EXISTS (SELECT 1 FROM pg_proc WHERE proname = ?)", "api_" + fn))) throw new HttpError(404, "Unknown action");
    const open = ["request_code", "access", "sign_in", "create_user", "entity_name_free"].includes(fn);
    const who = open ? await sessionUser(r) : await A();
    const out = await one(`SELECT api_${fn}(?::uuid, ?::text::jsonb)::text`, who, js(body)) as string;
    if (fn === "request_code" && RESEND_KEY && RESEND_FROM) {
      const purpose = text(body, "purpose") ?? "";
      const to = purpose === "mobile" ? text(body, "email") : text(body, "target");
      if (!to) throw bad("Enter your email first; the mobile code comes there until SMS is connected");
      await sendCode(to.trim(), JSON.parse(out).demo_code, purpose);
      return json({ sent: true, by_email: true, to: to.trim() });
    }
    if (fn === "sign_in" || fn === "create_user" || fn === "access") {
      const res = JSON.parse(out);
      return json(res.user_id ? { ...res, session: await newSession(res.user_id) } : res);
    }
    return json(out);
  }

  // reading
  if (p[0] === "home") return json(raw(await one("SELECT home_json(?::uuid)::text", await A())));
  if (p[0] === "calendar") return json(raw(await one("SELECT calendar_json(?::uuid, ?::date, ?::date)::text", await A(), isoDate(url.searchParams.get("from"), "From"), isoDate(url.searchParams.get("to"), "To"))));
  if (p[0] === "runs" && m === "GET" && p.length === 1) return json(raw(await one("SELECT runs_json(?::uuid)::text", await A())));
  if (p[0] === "runs" && m === "GET" && p.length === 2) {
    const t = await one("SELECT run_tree(?::uuid, ?::uuid)::text", uuid(p[1], "Run"), await A());
    if (!t) throw new HttpError(403, "You are not seated in any room of this run");
    return json(raw(t));
  }
  if (p[0] === "runs" && p[2] === "audit") {
    const t = await one("SELECT audit_json(?::uuid, ?::uuid)::text", uuid(p[1], "Run"), await A());
    if (!t) throw new HttpError(403, "History and audit is for the Requestor/Conductor and the super-user");
    return json(raw(t));
  }
  if (p[0] === "console") return json(raw(await one("SELECT console_json(?::uuid)::text", await A())));
  if (p[0] === "catalogue" && m === "GET" && p.length === 1) return json(raw(await one("SELECT catalogue_json(?::uuid)::text", await A())));
  if (p[0] === "business") return json(raw(await one("SELECT business_json(?::uuid)::text", await A())));
  if (p[0] === "entity" && p.length === 3) {
    if (p[2] === "catalogue" && m === "POST") {
      return json({ item_id: await one("SELECT create_catalogue_item(?::uuid, ?::uuid, ?::text::jsonb)::text", uuid(p[1], "Entity"), await A(), js(body)) });
    }
    const fn = ({ home: "entity_home_json", tasks: "tasks_json", vendors: "vendors_json", catalogue: "entity_catalogue_json" } as Record<string, string>)[p[2]];
    if (!fn) throw new HttpError(404, "Unknown view");
    return json(raw(await one(`SELECT ${fn}(?::uuid, ?::uuid)::text`, await A(), uuid(p[1], "Entity"))));
  }
  if (p[0] === "capabilities") return json(raw(await one("SELECT capabilities_json()::text")));
  if (p[0] === "journey-kramas") return json(raw(await one("SELECT journey_kramas_json(?::uuid, ?::uuid)::text", await A(), uuid(p[1], "Entity"))));
  if (p[0] === "rooms" && m === "GET") {
    const t = await one("SELECT room_json(?::uuid, ?::uuid)::text", uuid(p[1], "Room"), await A());
    if (!t) throw new HttpError(403, "You are not seated in this room");
    return json(raw(t));
  }
  if (p[0] === "personal" && p[1] === "tasks" && m === "GET") return json(raw(await one("SELECT personal_tasks_json(?::uuid)::text", await A())));

  // Krama lifecycle
  if (p[0] === "krama" && p[2] === "status") { await one("SELECT set_krama_status(?::uuid, ?::uuid, ?)", uuid(p[1], "Krama"), await A(), text(body, "status")); return json(ok); }
  if (p[0] === "krama" && p[2] === "new-version") return json({ krama_id: await one("SELECT new_version(?::uuid, ?::uuid, ?)::text", uuid(p[1], "Krama"), await A(), text(body, "what_changed")) });
  if (p[0] === "krama" && p[2] === "import") return json({ krama_id: await one("SELECT import_krama(?::uuid, ?::uuid, ?::uuid)::text", uuid(p[1], "Krama"), req(body, "entity_id", "Entity"), await A()) });
  if (p[0] === "krama" && p[2] === "capabilities") {
    await one("SELECT add_capability(?::uuid, ?::uuid, ?, ?::uuid, ?::uuid, ?::uuid, ?)", uuid(p[1], "Krama"), await A(), text(body, "code"),
      opt(body, "stage_id", "Stage"), opt(body, "topic_id", "Topic"), opt(body, "question_id", "Question"), text(body, "note"));
    return json(ok);
  }
  if (p[0] === "capability-uses") { await one("SELECT remove_capability(?::uuid, ?::uuid)", uuid(p[1], "Capability"), await A()); return json(ok); }

  // catalogue
  if (p[0] === "catalogue" && p[1] === "items" && m === "POST") {
    return json({ item_id: await one("SELECT add_catalogue_item(?::uuid, ?::uuid, ?::uuid, ?)::text", req(body, "krama_id", "Krama"), req(body, "entity_id", "Entity"), await A(), text(body, "name")) });
  }
  if (p[0] === "catalogue" && p[2] === "resolve") {
    await A();
    const cp = url.searchParams.get("counterparty");
    return json(raw(await one("SELECT resolve_json(?::uuid, ?, ?::uuid)::text", uuid(p[1], "Catalogue item"), url.searchParams.get("relationship"), cp ? uuid(cp, "Counterparty") : null)));
  }
  if (p[0] === "catalogue" && p[2] === "activate") {
    return json({ run_id: await one("SELECT activate(?::uuid, ?::uuid, ?::uuid, ?, ?::uuid)::text", uuid(p[1], "Catalogue item"), await A(),
      opt(body, "counterparty", "Counterparty"), text(body, "relationship"), opt(body, "krama_id", "Krama")) });
  }
  if (p[0] === "catalogue" && p[2] === "assign") { await one("SELECT assign_krama(?::uuid, ?::uuid, ?::uuid)", uuid(p[1], "Catalogue item"), req(body, "krama_id", "Krama"), await A()); return json(ok); }
  if (p[0] === "catalogue" && p[2] === "sections") {
    const id = await one("SELECT save_catalogue_section(?::uuid, ?::uuid, ?, ?::text::jsonb)::text", uuid(p[1], "Catalogue item"), await A(), p[3], js(body));
    return json(id ? { ok: true, id } : ok);
  }
  if (p[0] === "catalogue" && m === "GET" && p.length === 2) {
    const t = await one("SELECT catalogue_item_json(?::uuid, ?::uuid)::text", await A(), uuid(p[1], "Catalogue item"));
    if (!t) throw new HttpError(404, "Catalogue item not found");
    return json(raw(t));
  }
  if (p[0] === "catalogue" && m === "PUT" && p.length === 2) {
    const s = text(body, "seats");
    await one("SELECT update_catalogue_item(?::uuid, ?::uuid, ?, ?::uuid, ?, ?, ?, ?::int, ?::uuid, ?::uuid)", uuid(p[1], "Catalogue item"), await A(),
      text(body, "name"), opt(body, "library_item_id", "Library item"), text(body, "variants"), text(body, "pricing"), text(body, "visibility"),
      s === null ? null : parseInt(s, 10), opt(body, "offering_dept_bu_id", "Dept/BU"), opt(body, "buying_dept_bu_id", "Dept/BU"));
    return json(ok);
  }

  // conduct
  if (p[0] === "runs" && p[2] === "seats") { await one("SELECT seat_person(?::uuid, ?::uuid, ?, ?::uuid, ?::uuid)", uuid(p[1], "Run"), req(body, "stage_id", "Stage"), text(body, "seat"), req(body, "person_id", "Person"), await A()); return json(ok); }
  if (p[0] === "seats" && m === "DELETE") { await one("SELECT unseat(?::uuid, ?::uuid)", uuid(p[1], "Seat"), await A()); return json(ok); }
  if (p[0] === "runs" && p[2] === "amend") { await one("SELECT amend_run(?::uuid, ?::uuid)", uuid(p[1], "Run"), await A()); return json(ok); }
  if (p[0] === "runs" && p[2] === "estimates") {
    await one("SELECT add_estimate_line(?::uuid, ?::uuid, ?, ?, ?::uuid, ?, ?::numeric, ?::numeric, ?::numeric)", uuid(p[1], "Run"), await A(),
      text(body, "item"), text(body, "source"), opt(body, "vendor_id", "Vendor"), text(body, "vendor_name"), num(body, "est_cost"), num(body, "est_price"), num(body, "est_days"));
    return json(ok);
  }
  if (p[0] === "runs" && p[2] === "rooms") {
    return json({ room_id: await one("SELECT add_room(?::uuid, ?::uuid, ?, ?, ?::uuid, ?::uuid)::text", uuid(p[1], "Run"), await A(), text(body, "kind"), text(body, "name"),
      opt(body, "with_entity", "Entity"), opt(body, "parent_room_id", "Room")) });
  }
  if (p[0] === "estimates") { await one("SELECT set_actuals(?::uuid, ?::uuid, ?::numeric, ?::numeric, ?::numeric)", uuid(p[1], "Line"), await A(), num(body, "act_cost"), num(body, "act_price"), num(body, "act_days")); return json(ok); }
  if (p[0] === "split-lines") { await one("SELECT settle_split_line(?::uuid, ?::uuid, ?)", uuid(p[1], "Line"), await A(), text(body, "note")); return json(ok); }
  if (p[0] === "questions") {
    const qr = uuid(p[1], "Question"), who = await A(), a = p[2];
    const Q: Record<string, [string, unknown[]]> = {
      submit: ["SELECT submit_answer(?::uuid, ?::uuid, ?, ?, ?::text::jsonb)", [qr, who, text(body, "answer"), text(body, "source"), js(body.data)]],
      "accept-removal": ["SELECT accept_removal(?::uuid, ?::uuid)", [qr, who]],
      "third-party": ["SELECT third_party_request(?::uuid, ?::uuid, ?, ?)", [qr, who, text(body, "party"), text(body, "email")]],
      "third-party-reply": ["SELECT third_party_reply(?::uuid, ?::uuid, ?)", [qr, who, text(body, "reply")]],
      "call-in": ["SELECT call_in_split(?::uuid, ?::uuid, ?::uuid, string_to_array(?, E'\\n'), string_to_array(NULLIF(?, ''), ',')::int[])",
        [qr, who, req(body, "room_id", "Room"), text(body, "lines"), text(body, "discuss")]],
      review: ["SELECT review_answer(?::uuid, ?::uuid)", [qr, who]],
      agree: ["SELECT agree_answer(?::uuid, ?::uuid)", [qr, who]],
      contest: ["SELECT contest_answer(?::uuid, ?::uuid, ?, ?)", [qr, who, text(body, "reason"), text(body, "explanation")]],
      deadlock: ["SELECT deadlock_answer(?::uuid, ?::uuid, ?)", [qr, who, text(body, "explanation")]],
      cancel: ["SELECT cancel_question(?::uuid, ?::uuid, ?)", [qr, who, text(body, "explanation")]],
      reopen: ["SELECT reopen_question(?::uuid, ?::uuid)", [qr, who]],
      quadrant: ["SELECT set_quadrant(?::uuid, ?::uuid, ?)", [qr, who, text(body, "quadrant")]],
    };
    if (!Q[a]) throw new HttpError(404, "Unknown action");
    await one(Q[a][0], ...Q[a][1]);
    return json(ok);
  }
  if (p[0] === "rooms" && m === "POST") {
    const room = uuid(p[1], "Room"), who = await A();
    const R: Record<string, [string, unknown[]]> = {
      grant: ["SELECT grant_room(?::uuid, ?::uuid)", [room, who]],
      members: ["SELECT add_room_member(?::uuid, ?::uuid, ?::uuid, ?)", [room, req(body, "person_id", "Person"), who, body.spoc === true]],
      topics: ["SELECT set_room_topic(?::uuid, ?::uuid, ?, ?::uuid)", [room, req(body, "topic_id", "Topic"), body.retain === true, who]],
      registries: ["SELECT add_registry(?::uuid, ?::uuid, ?, ?, ?)", [room, who, text(body, "name"), text(body, "description"), text(body, "holds")]],
      messages: ["SELECT post_message(?::uuid, ?::uuid, ?, ?::uuid)", [room, who, text(body, "body"), opt(body, "mention_qr", "Question")]],
    };
    if (!R[p[2]]) throw new HttpError(404, "Unknown action");
    await one(R[p[2]][0], ...R[p[2]][1]);
    return json(ok);
  }
  if (p[0] === "registries") {
    await one("SELECT add_registry_entry(?::uuid, ?::uuid, ?, ?, ?::date, ?::uuid, ?)", uuid(p[1], "Registry"), await A(), text(body, "kind"), text(body, "title"),
      text(body, "on_date") === null ? null : isoDate(body.on_date, "Date"), opt(body, "stage_id", "Stage"), text(body, "status"));
    return json(ok);
  }
  if (p[0] === "entries") { await one("SELECT set_entry_status(?::uuid, ?::uuid, ?)", uuid(p[1], "Entry"), await A(), text(body, "status")); return json(ok); }

  // Standalone and personal tasks
  if (p[0] === "standalone" && m === "POST" && p.length === 1) {
    return json({ task_id: await one("SELECT create_standalone(?::uuid, ?::uuid, ?, ?, ?::date, ?)::text", await A(), req(body, "entity_id", "Entity"),
      text(body, "title"), text(body, "notes"), date(body, "due_date"), text(body, "quadrant")) });
  }
  if (p[0] === "standalone" && m === "PUT") { await one("SELECT update_standalone(?::uuid, ?::uuid, ?, ?, ?::date, ?)", uuid(p[1], "Task"), await A(), text(body, "title"), text(body, "notes"), date(body, "due_date"), text(body, "quadrant")); return json(ok); }
  if (p[0] === "standalone" && p[2] === "done") { await one("SELECT mark_done(?::uuid, ?::uuid)", uuid(p[1], "Task"), await A()); return json(ok); }
  if (p[0] === "personal" && p[1] === "tasks" && m === "POST" && p.length === 2) {
    return json({ task_id: await one("SELECT personal_task_act(NULL, ?::uuid, 'create', ?, ?::date, ?)::text", await A(), text(body, "title"), date(body, "due_date"), text(body, "quadrant")) });
  }
  if (p[0] === "personal" && p[1] === "tasks" && m === "POST") {
    if (!["done", "consent", "delete", "restore", "quadrant"].includes(p[3])) throw new HttpError(404, "Unknown action");
    await one("SELECT personal_task_act(?::uuid, ?::uuid, ?, NULL, NULL, ?)::text", uuid(p[2], "Task"), await A(), p[3], text(body, "quadrant"));
    return json(ok);
  }

  // the table API (Masters and Krama design rows)
  if (p.length >= 1 && p.length <= 2) return await crud(r, m, p[0], p[1] ?? null, body);
  throw new HttpError(404, "Not found");
}

Deno.serve(async (r) => {
  if (r.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });
  try {
    return await route(r);
  } catch (e) {
    if (e instanceof HttpError) return json({ message: e.message }, e.status);
    const msg = String((e as { message?: string })?.message ?? e).split("\n")[0].replace(/^ERROR:\s*/, "");
    return json({ message: msg || "Database error" }, 400);
  }
});
