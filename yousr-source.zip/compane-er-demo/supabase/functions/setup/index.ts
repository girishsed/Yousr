// One-time loader: fills an empty Yousr database from the .sql files published next to the screens.
// It refuses once the database is loaded, so it cannot be used to overwrite anything.
import postgres from "npm:postgres@3.4.5";

const FILES = ["01_schema.sql", "02_persona_types.sql", "03_krama.sql", "04_seed.sql", "05_views.sql", "06_platform.sql", "08_personas.sql", "09_persona_profiles.sql", "10_more_samples.sql", "11_stage_context.sql", "12_profile_fields.sql", "13_profiles_modules_controls.sql", "14_expertise.sql", "15_journeys.sql", "16_connected_vendors.sql", "17_reachable_entities.sql", "99_hosted.sql"];
const CORS = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "content-type", "Access-Control-Allow-Methods": "POST, OPTIONS" };
const out = (d: unknown, s = 200) => new Response(JSON.stringify(d), { status: s, headers: { ...CORS, "Content-Type": "application/json" } });

Deno.serve(async (r) => {
  if (r.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });
  const { from } = await r.json().catch(() => ({ from: "" }));
  if (!/^https:\/\/[a-z0-9.-]+(\/.*)?$/i.test(String(from ?? ""))) return out({ message: "Open this from your Yousr web address." }, 400);
  const sql = postgres(Deno.env.get("SUPABASE_DB_URL")!, { prepare: false, max: 1 });
  try {
    const [{ loaded }] = await sql`SELECT to_regclass('public.krama') IS NOT NULL AS loaded`;
    if (loaded) return out({ done: true, message: "The database is already loaded. Nothing was changed." });
    const base = String(from).replace(/\/+$/, "");
    const texts: string[] = [];
    for (const f of FILES) {
      const res = await fetch(`${base}/setup/${f}`);
      if (!res.ok) return out({ message: `Could not read ${f} from ${base}/setup (${res.status}).` }, 400);
      texts.push(await res.text());
    }
    for (let i = 0; i < FILES.length; i++) await sql.unsafe(texts[i]);
    return out({ done: true, message: "The database is loaded. You can sign in now." });
  } catch (e) {
    return out({ message: String((e as Error).message ?? e).split("\n")[0] }, 400);
  } finally {
    await sql.end({ timeout: 5 });
  }
});
