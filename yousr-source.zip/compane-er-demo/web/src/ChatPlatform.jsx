import { useEffect, useState } from 'react';
import { api, setSession, hosted } from './api.js';
import Brand from './Brand.jsx';
import Icon from './Icon.jsx';
import Catalogue from './Catalogue.jsx';
import Console from './Console.jsx';
import { WorkPersonas, EntityPersona as EntityPersonaFull, DomainPersonas, PersonPersona, Responsibilities } from './Personas.jsx';

const Chips = ({ list, on, set }) => (
  <div className="cu-chips">{list.map(([k, l]) => <button key={k} className={on === k ? 'on' : ''} onClick={() => set(k)}>{l}</button>)}</div>
);
const useLoad = (fn, deps) => {
  const [d, setD] = useState(null);
  const [err, setErr] = useState('');
  const load = () => fn().then((x) => { setD(x); setErr(''); }).catch((e) => setErr(e.message));
  useEffect(() => { load(); }, deps); // eslint-disable-line react-hooks/exhaustive-deps
  return [d, load, err];
};
const Err = ({ m }) => (m ? <p className="error">{m}</p> : null);

// A field that sends a one-time code and takes it back. When email sending is off, the code is shown on screen.
export function CodeField({ target, purpose, value, onChange, label = 'Code', email }) {
  const [demo, setDemo] = useState('');
  const [err, setErr] = useState('');
  const send = async () => {
    setErr(''); setDemo('');
    try {
      const r = await api.do('request_code', { target, purpose, email });
      setDemo(r.demo_code ? `Test mode: your code is ${r.demo_code}` : `Code sent to ${r.to || target}. Check your email.`);
    } catch (e) { setErr(e.message); }
  };
  return (
    <div className="cu-actions">
      <button className="quiet" disabled={!target} onClick={send}>Send code</button>
      <input placeholder={label} value={value} onChange={(e) => onChange(e.target.value)} aria-label={label} style={{ width: 120 }} />
      {demo && <span className="sub">{demo}</span>}
      <Err m={err} />
    </div>
  );
}

// ---------- Access (Yousr): one door to sign in or create an account ----------
// Step 1 email -> step 2 the code (signs you in if you have an account) -> for a new account: name and mobile,
// the mobile code, then your Compane ID. No passwords anywhere.
function CodeBoxes({ value, onChange, onDone }) {
  const refs = Array.from({ length: 6 }, () => null);
  const set = (i, ch) => {
    const d = value.split('');
    d[i] = ch;
    const v = d.join('').slice(0, 6);
    onChange(v);
    if (ch && i < 5) refs[i + 1]?.focus();
    if (v.replace(/\D/g, '').length === 6) onDone && onDone(v);
  };
  return (
    <div className="ac-boxes" onPaste={(e) => { const t = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 6); if (t) { e.preventDefault(); onChange(t); if (t.length === 6) onDone && onDone(t); } }}>
      {Array.from({ length: 6 }).map((_, i) => (
        <input key={i} ref={(el) => { refs[i] = el; }} inputMode="numeric" maxLength={1} aria-label={`Digit ${i + 1}`} value={value[i] || ''}
          onChange={(e) => set(i, e.target.value.replace(/\D/g, '').slice(-1))}
          onKeyDown={(e) => { if (e.key === 'Backspace' && !value[i] && i > 0) refs[i - 1]?.focus(); }} autoFocus={i === 0} />
      ))}
    </div>
  );
}

export function SignIn({ people: people0, onSignedIn }) {
  const [step, setStep] = useState('email');
  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [token, setToken] = useState('');
  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');
  const [mcode, setMcode] = useState('');
  const [note, setNote] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [wait, setWait] = useState(0);
  const [made, setMade] = useState(null);
  const [cfg, setCfg] = useState({ demo_people: false });
  const [people, setPeople] = useState(people0 || []);
  useEffect(() => {
    api.do('app_config', {}).then((c) => {
      setCfg(c);
      if (c.demo_people && !(people0 || []).length) api.list('users').then((u) => setPeople(u.filter((x) => x.user_type === 'Individual'))).catch(() => {});
    }).catch(() => {});
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { if (wait <= 0) return undefined; const t = setTimeout(() => setWait(wait - 1), 1000); return () => clearTimeout(t); }, [wait]);

  const run = async (fn) => { setErr(''); setBusy(true); try { await fn(); } catch (e) { setErr(e.message); } finally { setBusy(false); } };
  const sendEmailCode = () => run(async () => {
    const r = await api.do('request_code', { target: email.trim(), purpose: 'access' });
    setNote(r.demo_code ? `Test mode: your code is ${r.demo_code}` : `We sent a 6-digit code to ${email.trim()}.`);
    setCode(''); setWait(30); setStep('code');
  });
  const checkCode = (c = code) => run(async () => {
    const r = await api.do('access', { email: email.trim(), code: c });
    if (r.created) { if (r.session) setSession(r.session); setName(r.name || ''); setMade(r); setStep('welcome'); return; }
    if (r.user_id) { if (r.session) setSession(r.session); onSignedIn(r.user_id); return; }
    setToken(r.token); setStep('details');
  });
  const sendMobileCode = () => run(async () => {
    if (!name.trim()) throw new Error('Enter your name');
    if (!mobile.trim()) throw new Error('Enter your mobile');
    const r = await api.do('request_code', { target: mobile.trim(), purpose: 'mobile', email: email.trim() });
    setNote(r.demo_code ? `Test mode: your mobile code is ${r.demo_code}` : `We sent a code for ${mobile.trim()} (by email until SMS is connected).`);
    setMcode(''); setWait(30); setStep('mobile');
  });
  const create = (c = mcode) => run(async () => {
    const r = await api.do('create_user', { name: name.trim(), email: email.trim(), token, mobile: mobile.trim(), mobile_code: c });
    if (r.session) setSession(r.session);
    setMade(r); setStep('welcome');
  });

  return (
    <div className="cu-page cu-login ac">
      <div className="ac-card">
        <Brand name="Yousr" height={34} />
        {step === 'email' && <>
          <h1 className="serif">Welcome to Yousr</h1>
          <p className="sub">Register or sign in with your personal email. No password needed.</p>
          <input type="email" autoFocus placeholder="you@gmail.com" value={email} onChange={(e) => setEmail(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && email.trim() && sendEmailCode()} aria-label="Personal email" />
          <button className="primary ac-go" disabled={busy || !email.trim()} onClick={sendEmailCode}>{busy ? 'Sending…' : 'Continue'}</button>
        </>}
        {step === 'code' && <>
          <h1 className="serif">Check your email</h1>
          <p className="sub">{note}</p>
          <CodeBoxes value={code} onChange={setCode} onDone={(v) => checkCode(v)} />
          <button className="primary ac-go" disabled={busy || code.length < 6} onClick={() => checkCode()}>{busy ? 'Checking…' : 'Continue'}</button>
          <div className="ac-links">
            <button className="cu-link" onClick={() => { setStep('email'); setErr(''); }}>Use a different email</button>
            <button className="cu-link" disabled={wait > 0 || busy} onClick={sendEmailCode}>{wait > 0 ? `Send again in ${wait}s` : 'Send the code again'}</button>
          </div>
        </>}
        {step === 'details' && <>
          <h1 className="serif">Create your account</h1>
          <p className="sub">{email} is new to Yousr. Two more details.</p>
          <input autoFocus placeholder="Your full name" value={name} onChange={(e) => setName(e.target.value)} aria-label="Name" />
          <input type="tel" placeholder="Mobile, e.g. +91 98450 12345" value={mobile} onChange={(e) => setMobile(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && sendMobileCode()} aria-label="Mobile" />
          <button className="primary ac-go" disabled={busy} onClick={sendMobileCode}>{busy ? 'Sending…' : 'Continue'}</button>
        </>}
        {step === 'mobile' && <>
          <h1 className="serif">Confirm your mobile</h1>
          <p className="sub">{note}</p>
          <CodeBoxes value={mcode} onChange={setMcode} onDone={(v) => create(v)} />
          <button className="primary ac-go" disabled={busy || mcode.length < 6} onClick={() => create()}>{busy ? 'Creating…' : 'Create account'}</button>
          <div className="ac-links">
            <button className="cu-link" onClick={() => { setStep('details'); setErr(''); }}>Change mobile</button>
            <button className="cu-link" disabled={wait > 0 || busy} onClick={sendMobileCode}>{wait > 0 ? `Send again in ${wait}s` : 'Send the code again'}</button>
          </div>
        </>}
        {step === 'welcome' && made && <>
          <h1 className="serif">You're in, {name.split(' ')[0]}</h1>
          <p className="sub">Your Compane ID</p>
          <p className="ac-id">{made.compane_id}</p>
          <p className="sub">Only this ID is ever shown to others. A task on your Personal page asks you to complete your profile (name and photo).</p>
          <button className="primary ac-go" onClick={() => onSignedIn(made.user_id, true)}>Go to Yousr</button>
        </>}
        {err && <p className="error">{err}</p>}
      </div>
      {cfg.demo_people && step === 'email' && (
        <details className="cu-demo-people"><summary>Sample people</summary>
          {people.map((p) => <button key={p.user_id} onClick={async () => { await api.demoSignin(p.user_id); onSignedIn(p.user_id); }}>{p.name}</button>)}
        </details>
      )}
    </div>
  );
}

// ---------- Create Entity: five steps, then setup ----------
export function CreateEntityCard({ me, ctx }) {
  const [f, setF] = useState({ country: 'India', legal_type: '', name: '', work_email: '', work_code: '', personal_email: me.personal_email || '', personal_code: '' });
  const [free, setFree] = useState(null);
  const [made, setMade] = useState(null);
  const [s, setS] = useState({ category: '', sub_category: '', size: '', business_model: '', corporate_doc: '' });
  const [types, setTypes] = useState([]);
  const [ptype, setPtype] = useState('');
  useEffect(() => { if (s.category) api.do('entity_personas', { category: s.category, legal_type: f.legal_type, size: s.size }).then(setTypes).catch(() => {}); }, [s.category, s.size]); // eslint-disable-line react-hooks/exhaustive-deps
  const [err, setErr] = useState('');
  const [done, setDone] = useState(false);
  const set = (k, v) => setF((x) => ({ ...x, [k]: v }));
  const SUB = { Services: ['Consulting', 'Accounting', 'IT services', 'Others'], Trading: ['Distribution', 'Retail', 'Import and export', 'Others'], Manufacturing: ['Food', 'Textiles', 'Engineering', 'Others'] };
  if (done) return <div className="cu-card done">{made.name} is set up. Choose it from the menu to work in compane.</div>;
  if (made) {
    return (
      <div className="cu-card cu-form">
        <b>Set up {made.name}</b>
        <div className="cu-actions">
          <select value={s.category} onChange={(e) => setS({ ...s, category: e.target.value, sub_category: '' })} aria-label="Category"><option value="">Category…</option>{Object.keys(SUB).map((x) => <option key={x}>{x}</option>)}</select>
          {s.category && <select value={s.sub_category} onChange={(e) => setS({ ...s, sub_category: e.target.value })} aria-label="Sub-category"><option value="">Sub-category…</option>{SUB[s.category].map((x) => <option key={x}>{x}</option>)}</select>}
          <select value={s.size} onChange={(e) => setS({ ...s, size: e.target.value })} aria-label="Size"><option value="">Size (people)…</option><option value="Micro">Micro · up to 10</option><option value="Small">Small · 11–50</option><option value="Medium">Medium · 51–250</option><option value="Large">Large · 250+</option></select>
          <select value={s.business_model} onChange={(e) => setS({ ...s, business_model: e.target.value })} aria-label="Business model"><option value="">Business model…</option><option value="Functional">Function based</option><option value="Business Unit">Business Unit based</option></select>
        </div>
        {s.category && <select value={ptype} onChange={(e) => setPtype(e.target.value)} aria-label="Entity Persona"><option value="">Entity Persona (what kind of {s.category.toLowerCase()} business)…</option>
          {types.map((t) => <option key={t.persona_type_id} value={t.persona_type_id}>{t.path}</option>)}</select>}
        <input placeholder="Corporate document (file name; can be assigned later)" value={s.corporate_doc} onChange={(e) => setS({ ...s, corporate_doc: e.target.value })} aria-label="Corporate document" />
        <Err m={err} />
        <div className="cu-actions"><button className="primary" onClick={async () => { setErr(''); try { await api.do('entity_setup', { ...s, entity_id: made.entity_id }); if (ptype) await api.do('set_entity_persona', { entity_id: made.entity_id, persona_type_id: ptype }); setDone(true); ctx.refreshEntities(); } catch (e) { setErr(e.message); } }}>Save setup</button></div>
      </div>
    );
  }
  return (
    <div className="cu-card cu-form">
      <b>Create an entity</b>
      <p className="sub">Step 1 · Country</p>
      <select value={f.country} onChange={(e) => set('country', e.target.value)} aria-label="Country"><option>India</option><option>United Arab Emirates</option><option>Singapore</option><option>United Kingdom</option><option>United States</option></select>
      <p className="sub">Step 2 · Legal type</p>
      <select value={f.legal_type} onChange={(e) => set('legal_type', e.target.value)} aria-label="Legal type"><option value="">Pick…</option>{['Sole proprietor', 'Partnership firm', 'Pvt Ltd', 'LLP', 'Public Ltd', 'Trust'].map((x) => <option key={x}>{x}</option>)}</select>
      <p className="sub">Step 3 · Entity name</p>
      <div className="cu-actions">
        <input value={f.name} onChange={(e) => { set('name', e.target.value); setFree(null); }} aria-label="Entity name" />
        <button className="quiet" disabled={!f.name} onClick={async () => setFree((await api.do('entity_name_free', { name: f.name })).free)}>Check</button>
        {free !== null && <span className={free ? 'sub' : 'ink'}>{free ? 'Available' : 'Taken'}</span>}
      </div>
      <p className="sub">Step 4 · Work email (a business domain)</p>
      <input value={f.work_email} onChange={(e) => set('work_email', e.target.value)} aria-label="Work email" />
      <CodeField target={f.work_email} purpose="work_email" value={f.work_code} onChange={(v) => set('work_code', v)} />
      {f.work_code && <>
        <p className="sub">Step 5 · Personal email</p>
        <input value={f.personal_email} onChange={(e) => set('personal_email', e.target.value)} aria-label="Personal email" />
        <CodeField target={f.personal_email} purpose="create_entity_personal" value={f.personal_code} onChange={(v) => set('personal_code', v)} />
      </>}
      <Err m={err} />
      <div className="cu-actions"><button className="primary" disabled={!f.work_code || !f.personal_code} onClick={async () => { setErr(''); try { setMade(await api.do('create_entity', f)); } catch (e) { setErr(e.message); } }}>Create entity</button></div>
    </div>
  );
}

// ---------- Invites waiting for me (Connect User Entity, the joining side) ----------
export function InvitesCard({ ctx }) {
  const [work, setWork] = useState('');
  const [rows, load, err] = useLoad(() => api.do('my_invites', { work_email: work }), [work]);
  const [code, setCode] = useState({});
  const [msg, setMsg] = useState('');
  return (
    <div className="cu-card">
      <div className="cu-actions"><input placeholder="Your work email, to find its invite" value={work} onChange={(e) => setWork(e.target.value)} aria-label="Work email" /></div>
      {(rows || []).length === 0 && <p className="sub">No invites waiting.</p>}
      {(rows || []).map((i) => (
        <div key={i.invite_id} className="cu-confirm">
          <p><b>{i.entity}</b> invites you as {i.designation || 'a member'} <span className="sub">· {i.work_email} · from {i.from}</span></p>
          <CodeField target={i.work_email} purpose="join_work" value={code[i.invite_id] || ''} onChange={(v) => setCode({ ...code, [i.invite_id]: v })} label="Work-email code" />
          <div className="cu-actions">
            <button className="primary" onClick={async () => { setMsg(''); try { await api.do('join_entity', { invite_id: i.invite_id, code: code[i.invite_id] }); setMsg(`Connected to ${i.entity}.`); load(); ctx.refreshEntities(); } catch (e) { setMsg(e.message); } }}>Join</button>
            <button className="quiet" onClick={async () => { await api.do('invite_action', { invite_id: i.invite_id, action: 'decline' }); load(); }}>Decline</button>
          </div>
        </div>
      ))}
      <Err m={err} />{msg && <p className="sub">{msg}</p>}
    </div>
  );
}

// ---------- My ID and Profile (personal) ----------
export function MyIdCard() {
  const [d, load, err] = useLoad(() => api.do('my_id', {}), []);
  if (!d) return <div className="cu-card"><Err m={err} /></div>;
  return (
    <div className="cu-card">
      <p><span className="sub">Compane ID</span> <b>{d.compane_id}</b> {d.verified && <span className="sub">· identity verified</span>}</p>
      {d.documents.map((x) => (
        <div key={x.doc_id} className="cu-line"><span>{x.kind} <span className="sub">· {x.status}{x.at ? ` · ${x.at}` : ''}</span></span>
          {x.status !== 'Verified' && <button className="cu-link" onClick={async () => { await api.do('my_id', { verify: x.doc_id }); load(); }}>Connect DigiLocker</button>}</div>
      ))}
      <p className="sub">Documents are verified through DigiLocker only. Only your Compane ID is ever shown to others.</p>
    </div>
  );
}

export function ProfileCard({ onSaved }) {
  const [d, load] = useLoad(() => api.do('profile', {}), []);
  const [f, setF] = useState(null);
  useEffect(() => { if (d) setF({ name: d.name, photo: d.photo || '' }); }, [d]);
  if (!d || !f) return <div className="cu-card"><p className="sub">Loading…</p></div>;
  return (
    <div className="cu-card cu-form">
      <b>Profile</b>
      <input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} aria-label="Name" />
      <input placeholder="Photo (file name)" value={f.photo} onChange={(e) => setF({ ...f, photo: e.target.value })} aria-label="Photo" />
      <p className="sub">Signed in with {d.personal_email} · mobile {d.mobile} · {d.compane_id}</p>
      <div className="cu-actions"><button className="primary" onClick={async () => { await api.do('profile', f); load(); onSaved && onSaved(); }}>Save</button></div>
      <PersonPersona />
    </div>
  );
}

// ---------- Files, Search, Email, Chat (tools) ----------
export function FilesCard({ entity }) {
  const [rows, , err] = useLoad(() => api.do('files', { entity_id: entity?.entity_id || '' }), [entity?.entity_id]);
  return (
    <div className="cu-card">
      {(rows || []).length === 0 && <p className="sub">No files yet.</p>}
      {(rows || []).map((f, i) => <div key={i} className="cu-line"><span><b>{f.file}</b> <span className="sub">· {f.from}{f.room ? ` · ${f.room}` : ''}</span></span><span className="sub">{[f.mobility, f.status].filter(Boolean).join(' · ')}</span></div>)}
      <Err m={err} />
    </div>
  );
}

export function SearchCard({ entity, ctx, q0 = '' }) {
  const [q, setQ] = useState(q0);
  const [rows, setRows] = useState(null);
  const run = async (v) => setRows(await api.do('search', { entity_id: entity?.entity_id || '', q: v }));
  useEffect(() => { if (q0) run(q0); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <div className="cu-card">
      <div className="cu-actions"><input placeholder={`Search ${entity ? entity.name : 'your personal space'}`} value={q} onChange={(e) => setQ(e.target.value)}
        onKeyDown={(e) => e.key === 'Enter' && run(q)} aria-label="Search" /><button className="quiet" onClick={() => run(q)}>Search</button></div>
      {rows && rows.length === 0 && <p className="sub">Nothing found in this space.</p>}
      {(rows || []).map((r, i) => (
        <div key={i} className="cu-line"><span><span className="sub">{r.kind}</span> <b>{r.title}</b> <span className="sub">{r.sub}</span></span>
          {r.run_id && <button className="cu-link" onClick={() => ctx.openTaskCard(r.run_id, r.qr_id)}>Open</button>}
          {r.item_id && <button className="cu-link" onClick={() => ctx.addCard({ kind: 'item', itemId: r.item_id })}>Open</button>}</div>
      ))}
    </div>
  );
}

export function EmailCard({ entity, surface }) {
  const [d, load, err] = useLoad(() => api.do('email', { entity_id: entity?.entity_id || '' }), [entity?.entity_id]);
  const [folder, setFolder] = useState(surface ? 'Work' : 'Inbox');
  const [open, setOpen] = useState(null);
  const [c, setC] = useState(null);
  const [msg, setMsg] = useState('');
  if (!d) return <div className="cu-card"><Err m={err} /></div>;
  const list = d.mails.filter((m) => m.folder === folder);
  const work = d.mails.filter((m) => m.work);
  const MENU = [['Work', 'briefcase'], ['Inbox', 'inbox'], ['Sent', 'send'], ['Drafts', 'draft'], ['Outbox', 'send'], ['All mail', 'mail'], ['Spam', 'spam'], ['Trash', 'trash']];
  if (surface) {
    const shown = folder === 'Work' ? work : folder === 'All mail' ? d.mails : d.mails.filter((m) => m.folder === folder);
    return (
      <div className="cf-mail">
        <nav className="cf-mail-menu">
          {MENU.map(([k, ic]) => <button key={k} className={folder === k ? 'on' : ''} onClick={() => { setFolder(k); setOpen(null); }}><Icon name={ic} size={16} />{k}</button>)}
        </nav>
        <div className="cf-mail-list">
          <p className="cu-gh">{folder}</p>
          <p className="sub">{folder === 'Work' ? 'Outcomes from email' : d.address}</p>
          {shown.map((m) => (
            <div key={m.mail_id} className="cu-line" onClick={() => setOpen(open === m.mail_id ? null : m.mail_id)} style={{ cursor: 'pointer' }}>
              <span>{folder === 'Work' && <span className="ink">{m.work} </span>}<b>{m.subject}</b> <span className="sub">· {m.folder === 'Inbox' ? m.from : m.to} · {m.at}</span>{open === m.mail_id && <p>{m.body}</p>}</span>
            </div>
          ))}
          {shown.length === 0 && <p className="sub">Nothing in {folder}.</p>}
          {!c ? <div className="cu-actions"><button className="quiet" onClick={() => setC({ to: '', subject: '', body: '' })}>Write email</button></div> : (
            <div className="cu-confirm cu-form">
              <input placeholder="To" value={c.to} onChange={(e) => setC({ ...c, to: e.target.value })} aria-label="To" />
              <input placeholder="Subject" value={c.subject} onChange={(e) => setC({ ...c, subject: e.target.value })} aria-label="Subject" />
              <textarea rows={3} placeholder="Message" value={c.body} onChange={(e) => setC({ ...c, body: e.target.value })} aria-label="Body" />
              <div className="cu-actions">
                <button className="primary" onClick={async () => { setMsg(''); try { await api.do('email', { entity_id: entity?.entity_id || '', ...c }); setC(null); setFolder('Sent'); load(); } catch (e) { setMsg(e.message); } }}>Send</button>
                <button className="quiet" onClick={async () => { try { await api.do('email', { entity_id: entity?.entity_id || '', ...c, folder: 'Drafts' }); setC(null); setFolder('Drafts'); load(); } catch (e) { setMsg(e.message); } }}>Save draft</button>
                <span className="sub">Emails are kept here; sending is not connected yet.</span>
              </div>
              <Err m={msg} />
            </div>
          )}
        </div>
      </div>
    );
  }
  return (
    <div className="cu-card wide">
      <p className="sub">{d.address}</p>
      {work.length > 0 && <div className="cu-topic"><p className="strong">Work</p>{work.map((m) => <p key={m.mail_id} className="sub">{m.work} ← {m.subject}</p>)}</div>}
      <Chips list={[['Inbox', 'Inbox'], ['Sent', 'Sent'], ['Drafts', 'Drafts']]} on={folder} set={(x) => { setFolder(x); setOpen(null); }} />
      {list.map((m) => (
        <div key={m.mail_id} className="cu-line" onClick={() => setOpen(open === m.mail_id ? null : m.mail_id)} style={{ cursor: 'pointer' }}>
          <span><b>{m.subject}</b> <span className="sub">· {folder === 'Inbox' ? m.from : m.to} · {m.at}</span>{open === m.mail_id && <p>{m.body}</p>}</span>
          {m.work && <span className="qc">Work</span>}
        </div>
      ))}
      {list.length === 0 && <p className="sub">Nothing in {folder}.</p>}
      {!c ? <div className="cu-actions"><button className="quiet" onClick={() => setC({ to: '', subject: '', body: '' })}>Write email</button></div> : (
        <div className="cu-confirm cu-form">
          <input placeholder="To" value={c.to} onChange={(e) => setC({ ...c, to: e.target.value })} aria-label="To" />
          <input placeholder="Subject" value={c.subject} onChange={(e) => setC({ ...c, subject: e.target.value })} aria-label="Subject" />
          <textarea rows={3} placeholder="Message" value={c.body} onChange={(e) => setC({ ...c, body: e.target.value })} aria-label="Body" />
          <div className="cu-actions">
            <button className="primary" onClick={async () => { setMsg(''); try { await api.do('email', { entity_id: entity?.entity_id || '', ...c }); setC(null); setFolder('Sent'); load(); } catch (e) { setMsg(e.message); } }}>Send</button>
            <button className="quiet" onClick={async () => { try { await api.do('email', { entity_id: entity?.entity_id || '', ...c, folder: 'Drafts' }); setC(null); setFolder('Drafts'); load(); } catch (e) { setMsg(e.message); } }}>Save draft</button>
            <span className="sub">Emails are kept here; sending is not connected yet.</span>
          </div>
          <Err m={msg} />
        </div>
      )}
    </div>
  );
}

export function ChatToolCard({ entity }) {
  const [withId, setWith] = useState('');
  const [d, load, err] = useLoad(() => api.do('chat', { entity_id: entity?.entity_id || '', with: withId }), [entity?.entity_id, withId]);
  const [body, setBody] = useState('');
  if (!d) return <div className="cu-card"><Err m={err} /></div>;
  const ents = d.contacts.filter((x) => x.kind === 'Company');
  const ppl = d.contacts.filter((x) => x.kind !== 'Company');
  return (
    <div className="cu-card wide">
      {ents.length > 0 && <><p className="cu-gh">Entities</p><div className="cu-chips">{ents.map((x) => <button key={x.user_id} className={withId === x.user_id ? 'on' : ''} onClick={() => setWith(x.user_id)}>{x.name}</button>)}</div></>}
      {ppl.length > 0 && <><p className="cu-gh">People</p><div className="cu-chips">{ppl.map((x) => <button key={x.user_id} className={withId === x.user_id ? 'on' : ''} onClick={() => setWith(x.user_id)}>{x.name}</button>)}</div></>}
      {ents.length + ppl.length === 0 && <p className="sub">{entity ? 'No conversations yet. Connected entities and your colleagues appear here.' : 'Personal chat: no conversations yet.'}</p>}
      {withId && <>
        <div className="cu-msgs">{d.messages.map((m, i) => <div key={i} className={m.mine ? 'msg mine' : 'msg'}><span className="sub">{m.by} · {m.at}</span><p>{m.body}</p></div>)}
          {d.messages.length === 0 && <p className="sub">No messages yet.</p>}</div>
        <div className="cu-actions"><input placeholder="Message" value={body} onChange={(e) => setBody(e.target.value)} onKeyDown={async (e) => { if (e.key === 'Enter' && body.trim()) { await api.do('chat', { entity_id: entity?.entity_id || '', with: withId, body }); setBody(''); load(); } }} aria-label="Chat message" style={{ flex: 1 }} />
          <button className="primary" disabled={!body.trim()} onClick={async () => { await api.do('chat', { entity_id: entity?.entity_id || '', with: withId, body }); setBody(''); load(); }}>Send</button></div>
      </>}
    </div>
  );
}

// ---------- Connections (Connect Entity Entity) and Discover and Connect ----------
export function ConnectionsCard({ entity, ctx, to0 }) {
  const [rows, load, err] = useLoad(() => api.do('connections', { entity_id: entity.entity_id }), [entity.entity_id]);
  const [f, setF] = useState(to0 ? { to_entity: to0, relationship: 'Vendor', code: '', to_name: '' } : null);
  const [found, setFound] = useState([]);
  const [q, setQ] = useState('');
  const [codes, setCodes] = useState({});
  const [msg, setMsg] = useState('');
  const [mine, setMine] = useState('');
  const [info, setInfo] = useState('');
  useEffect(() => { api.do('settings', { entity_id: entity.entity_id }).then((s) => setMine((s.users.find((u) => u.name === ctx.me.name) || {}).work_email || '')).catch(() => {}); }, [entity.entity_id]); // eslint-disable-line react-hooks/exhaustive-deps
  const go = async (fn) => { setMsg(''); try { await fn(); await load(); } catch (e) { setMsg(e.message); } };
  return (
    <div className="cu-card wide">
      {(rows || []).map((c) => (
        <div key={c.connection_id} className="cu-line">
          <span><b>{c.other}</b> <span className="sub">· {c.relationship}</span> <span className={c.state === 'Connected' ? 'qc' : 'sub'}>{c.state}</span>
            {c.failure && <span className="ink"> · {c.failure} · resent {c.resent}/5</span>}</span>
          <span className="cu-actions">
            {c.can_accept && <><input placeholder="Your code" value={codes[c.connection_id] || ''} onChange={(e) => setCodes({ ...codes, [c.connection_id]: e.target.value })} style={{ width: 100 }} aria-label="Accept code" />
              <button className="quiet" onClick={async () => { const r = await api.do('request_code', { target: mine, purpose: 'connect_accept' }); setInfo(r.demo_code ? `Test mode: the code for ${mine} is ${r.demo_code}` : `Code sent to ${mine}. Check your email.`); }}>Send code</button>
              <button className="primary" onClick={() => go(() => api.do('connect_accept', { connection_id: c.connection_id, code: codes[c.connection_id] }))}>Validate</button></>}
            {c.mine && c.state === 'Pending' && !c.failure && <button className="cu-link" onClick={() => go(() => api.do('connect_action', { connection_id: c.connection_id, action: 'cancel' }))}>Cancel</button>}
            {c.mine && c.state === 'Pending' && !c.failure && <button className="cu-link" onClick={() => go(() => api.do('connect_action', { connection_id: c.connection_id, action: 'expire' }))}>Mark expired</button>}
            {c.mine && c.failure && <button className="cu-link" onClick={() => go(() => api.do('connect_action', { connection_id: c.connection_id, action: 'resend' }))}>Resend</button>}
            {c.state === 'Connected' && c.mine && <button className="cu-link" onClick={() => go(() => api.do('connect_action', { connection_id: c.connection_id, action: 'disconnect' }))}>Disconnect</button>}
          </span>
        </div>
      ))}
      {!f ? <div className="cu-actions"><button className="quiet" onClick={() => setF({ to_entity: '', to_name: '', relationship: 'Vendor', code: '' })}>+ Connect</button></div> : (
        <div className="cu-confirm cu-form">
          <div className="cu-actions"><input placeholder="Search entities on Compane" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Find entity" />
            <button className="quiet" onClick={async () => setFound(await api.do('discover', { entity_id: entity.entity_id, q }))}>Search</button></div>
          {found.map((x) => <button key={x.entity_id} className={f.to_entity === x.entity_id ? 'cu-pick on' : 'cu-pick'} onClick={() => setF({ ...f, to_entity: x.entity_id, to_name: x.name })}>{x.name} <span className="sub">{x.persona || ''}</span></button>)}
          {!f.to_entity && <input placeholder="Not found? Their entity name (they create it on Compane, then connect)" value={f.to_name} onChange={(e) => setF({ ...f, to_name: e.target.value })} aria-label="Entity name" />}
          <select value={f.relationship} onChange={(e) => setF({ ...f, relationship: e.target.value })} aria-label="Relationship">{['Pre-client', 'Client', 'Pre-vendor', 'Vendor'].map((x) => <option key={x}>{x}</option>)}</select>
          <CodeField target={mine} purpose="connect_inviter" value={f.code} onChange={(v) => setF({ ...f, code: v })} label="Your work-email code" />
          <div className="cu-actions"><button className="primary" onClick={() => go(async () => { await api.do('connect_invite', { entity_id: entity.entity_id, ...f }); setF(null); })}>Send invite</button><button className="quiet" onClick={() => setF(null)}>Cancel</button></div>
        </div>
      )}
      {info && <p className="sub">{info}</p>}
      <Err m={err || msg} />
    </div>
  );
}

export function DiscoverCard({ entity, ctx }) {
  const [q, setQ] = useState('');
  const [rows, setRows] = useState(null);
  const run = async () => setRows(await api.do('discover', { entity_id: entity?.entity_id || '', q }));
  useEffect(() => { run(); }, [entity?.entity_id]); // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <div className="cu-card wide">
      <div className="cu-actions"><input placeholder="Find entities, products or services" value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && run()} aria-label="Discover" style={{ flex: 1 }} /><button className="quiet" onClick={run}>Search</button></div>
      {(rows || []).map((x) => (
        <div key={x.entity_id} className="cu-line">
          <span><b>{x.name}</b> <span className="sub">· {x.persona || '—'}{x.items.length ? ` · ${x.items.map((i) => i.name).join(', ')}` : ''}</span></span>
          {entity ? (x.connection ? <span className="sub">{x.connection}</span> : <button className="cu-link" onClick={() => ctx.addCard({ kind: 'connections', to: x.entity_id })}>Connect</button>) : null}
        </div>
      ))}
    </div>
  );
}

// ---------- Revenue, Compliance, Tools ----------
export function RevenueCard({ entity, ctx }) {
  const [d, , err] = useLoad(() => api.do('revenue', { entity_id: entity.entity_id }), [entity.entity_id]);
  if (!d) return <div className="cu-card"><Err m={err} /></div>;
  const money = (v) => (v == null ? '—' : `₹${Number(v).toLocaleString('en-IN')}`);
  return (
    <div className="cu-card wide">
      <p className="cu-gh">Sell side · Opportunities and orders</p>
      {d.sell.length === 0 && <p className="sub">No sell-side tasks yet.</p>}
      {d.sell.map((r) => <div key={r.run_id} className="cu-line"><span><b>{r.item}</b> <span className="sub">· {r.label} · {r.client} · {r.result || r.status} · price {money(r.price)} · cost {money(r.cost)}</span></span><button className="cu-link" onClick={() => ctx.openTaskCard(r.run_id)}>Open</button></div>)}
      <p className="cu-gh">Selling to clients who buy from you</p>
      {d.buy_for_others.length === 0 && <p className="sub">None.</p>}
      {d.buy_for_others.map((r) => <div key={r.run_id} className="cu-line"><span><b>{r.item}</b> <span className="sub">· {r.label} · {r.client} · {r.status}</span></span><button className="cu-link" onClick={() => ctx.openTaskCard(r.run_id)}>Open</button></div>)}
    </div>
  );
}

export function ComplianceCard({ entity, ctx }) {
  const [rows, , err] = useLoad(() => api.do('compliance', { entity_id: entity.entity_id }), [entity.entity_id]);
  return (
    <div className="cu-card wide">
      {(rows || []).length === 0 && <p className="sub">No Compliance items in the catalogue yet. Set an item's Overview to Compliance to see it here.</p>}
      {(rows || []).map((x) => (
        <div key={x.item_id} className="cu-topic"><p className="strong">{x.name} <span className="sub">· {x.domain} · {x.persona}</span></p>
          {x.runs.map((r) => <div key={r.run_id} className="cu-line"><span className="sub">{r.label} · {r.fy} · {r.result || r.status}</span><button className="cu-link" onClick={() => ctx.openTaskCard(r.run_id)}>Open</button></div>)}
          <button className="cu-link" style={{ alignSelf: 'flex-start' }} onClick={() => ctx.addCard({ kind: 'item', itemId: x.item_id })}>Open item</button></div>
      ))}
      <Err m={err} />
    </div>
  );
}

export function ToolsCard({ onTool }) {
  return (
    <div className="cu-card">
      {['Calendar', 'Email', 'Chat', 'Files', 'Search'].map((t) => <div key={t} className="cu-line"><b>{t}</b><button className="cu-link" onClick={() => onTool(t)}>Open</button></div>)}
    </div>
  );
}

// ---------- Settings, in full ----------
const SETTINGS_TABS = {
  Entity: [['entity', 'Entity'], ['persona', 'Entity Persona'], ['seats', 'Authority seats'], ['responsibility', 'Responsibilities'], ['hub', 'Connection Hub'], ['krama', 'Krama'], ['ui', 'User Interface']],
  'User and Access': [['access', 'People'], ['org', 'Dept/BU and Work Personas'], ['permission', 'Permission']],
  'Plan and Usage': [['plan', 'Plan and Usage']],
  'Entity Data': [['data', 'Entity Data']],
};
export function FullSettingsCard({ entity, ctx, group }) {
  const [d, load, err] = useLoad(() => api.do('settings', { entity_id: entity.entity_id }), [entity.entity_id]);
  const tabs = group ? SETTINGS_TABS[group] : Object.values(SETTINGS_TABS).flat();
  const [sec, setSec] = useState(tabs[0][0]);
  const [f, setF] = useState({});
  const [msg, setMsg] = useState('');
  const [exported, setExported] = useState(null);
  if (!d) return <div className="cu-card"><Err m={err} /></div>;
  const admin = d.is_admin;
  const me = d.users.find((u) => u.name === ctx.me.name) || {};
  const go = async (fn, ok) => { setMsg(''); try { await fn(); await load(); if (ok) setMsg(ok); } catch (e) { setMsg(e.message); } };
  const set = (k, v) => setF((x) => ({ ...x, [k]: v }));
  const personas = d.dept_bus.flatMap((x) => x.personas.map((p) => ({ ...p, dept: x.name }))).concat(d.exceptions.map((p) => ({ ...p, dept: 'Above Dept/BU' })));
  return (
    <div className="cu-card wide">
      {tabs.length > 1 && <Chips list={tabs} on={sec} set={(x) => { setSec(x); setMsg(''); setF({}); }} />}
      {sec === 'persona' && <EntityPersonaFull entity={entity} admin={!!(ctx.access?.admin || ctx.isSuper)} />}
      {sec === 'responsibility' && <Responsibilities entity={entity} />}
      {sec === 'permission' && <WorkPersonas entity={entity} />}
      {sec === 'seats' && <SpineCard entity={entity} />}

      {sec === 'entity' && <div className="cu-sec">
        <p><span className="sub">Name</span> {d.entity.name}</p><p><span className="sub">Country</span> {d.entity.country}</p><p><span className="sub">Legal type</span> {d.entity.legal_type}</p>
        <p><span className="sub">Category</span> {d.entity.category} › {d.entity.sub_category} · {d.entity.size}</p>
        {admin ? <div className="cu-actions">
          <input placeholder="Authorised email" defaultValue={d.entity.authorised_email || ''} onChange={(e) => set('authorised_email', e.target.value)} aria-label="Authorised email" />
          <input placeholder="Mobile" defaultValue={d.entity.mobile || ''} onChange={(e) => set('mobile', e.target.value)} aria-label="Entity mobile" />
          <button className="quiet" onClick={() => go(() => api.do('save_entity_details', { entity_id: entity.entity_id, authorised_email: f.authorised_email ?? d.entity.authorised_email, mobile: f.mobile ?? d.entity.mobile }), 'Saved')}>Save</button>
        </div> : <p><span className="sub">Authorised email</span> {d.entity.authorised_email || '—'}</p>}
        <p className="cu-gh">Business Model</p>
        <p>{d.entity.business_model === 'Business Unit' ? 'Business Unit based: Departments and Business Units.' : 'Function based: Departments only.'}</p>
        {admin && <><div className="cu-actions"><select value={f.model || ''} onChange={(e) => set('model', e.target.value)} aria-label="New model"><option value="">Change to…</option><option value="Functional">Function based</option><option value="Business Unit">Business Unit based</option></select></div>
          {f.model && <><CodeField target={me.work_email} purpose="business_model" value={f.code || ''} onChange={(v) => set('code', v)} label="Code to your work email" />
            <div className="cu-actions"><button className="primary" onClick={() => go(() => api.do('change_business_model', { entity_id: entity.entity_id, model: f.model, code: f.code }), 'Business Model changed')}>Confirm change</button></div></>}</>}
      </div>}

      {sec === 'org' && <div className="cu-sec">
        {d.dept_bus.map((x) => (
          <div key={x.dept_bu_id} className="cu-topic">
            <p className="strong">{x.name}</p>
            <p className="sub">Grades: {x.grades.map((g) => g.name).join(' › ') || '—'}</p>
            <p className="sub">Designations: {x.designations.map((g) => `${g.name}${g.grade ? ` (${g.grade})` : ''}`).join(', ') || '—'}</p>
            {x.personas.map((p) => <PersonaRow key={p.persona_id} p={p} admin={admin} entity={entity} onDone={load} />)}
            {admin && <div className="cu-actions">
              <select value={f[`k${x.dept_bu_id}`] || 'Grade'} onChange={(e) => set(`k${x.dept_bu_id}`, e.target.value)} aria-label="Add"><option>Grade</option><option>Designation</option><option>Work Persona</option><option>Exception</option></select>
              <input placeholder="Name" value={f[`n${x.dept_bu_id}`] || ''} onChange={(e) => set(`n${x.dept_bu_id}`, e.target.value)} aria-label="Name" />
              {['Designation', 'Work Persona'].includes(f[`k${x.dept_bu_id}`]) && <select value={f[`g${x.dept_bu_id}`] || ''} onChange={(e) => set(`g${x.dept_bu_id}`, e.target.value)} aria-label="Grade"><option value="">Grade…</option>{x.grades.map((g) => <option key={g.grade_id}>{g.name}</option>)}</select>}
              {['Work Persona', 'Exception'].includes(f[`k${x.dept_bu_id}`]) && <select value={f[`r${x.dept_bu_id}`] || ''} onChange={(e) => set(`r${x.dept_bu_id}`, e.target.value)} aria-label="Reports to"><option value="">Reports to…</option>{personas.map((p) => <option key={p.persona_id} value={p.persona_id}>{p.name}</option>)}</select>}
              {f[`k${x.dept_bu_id}`] === 'Work Persona' && <label className="check"><input type="checkbox" checked={!!f[`m${x.dept_bu_id}`]} onChange={(e) => set(`m${x.dept_bu_id}`, e.target.checked)} />Krama</label>}
              <button className="quiet" onClick={() => go(() => api.do('add_org', { entity_id: entity.entity_id, dept_bu_id: x.dept_bu_id, kind: f[`k${x.dept_bu_id}`] || 'Grade', name: f[`n${x.dept_bu_id}`], grade: f[`g${x.dept_bu_id}`], reports_to: f[`r${x.dept_bu_id}`], krama: !!f[`m${x.dept_bu_id}`] }).then(() => set(`n${x.dept_bu_id}`, '')))}>Add</button>
            </div>}
          </div>
        ))}
        {admin && <div className="cu-actions"><input placeholder={d.entity.business_model === 'Business Unit' ? 'New Department or Business Unit' : 'New Department'} value={f.newdept || ''} onChange={(e) => set('newdept', e.target.value)} aria-label="New Dept/BU" />
          <button className="quiet" onClick={() => go(() => api.do('add_org', { entity_id: entity.entity_id, kind: 'Dept/BU', name: f.newdept }).then(() => set('newdept', '')))}>Add Dept/BU</button></div>}
      </div>}

      {sec === 'access' && <div className="cu-sec">
        {d.users.map((u) => (
          <div key={u.link_id} className="cu-line"><span><b>{u.name}</b> <span className="sub">· {u.work_email} · {u.designation || '—'} · {u.dept_bu || 'entity level'}{u.persona ? ` · ${u.persona}` : ''}{u.admin ? ' · admin' : ''}</span></span>
            {admin && <span className="cu-actions">
              <select value={u.persona_id || ''} onChange={(e) => go(() => api.do('member_action', { link_id: u.link_id, action: 'edit', dept_bu_id: u.dept_bu_id || '', designation: u.designation, admin: u.admin, persona_id: e.target.value }))} aria-label="Work Persona">
                <option value="">Work Persona…</option>{personas.map((p) => <option key={p.persona_id} value={p.persona_id}>{p.name} · {p.dept}</option>)}</select>
              {u.name !== ctx.me.name && <button className="cu-link" onClick={() => go(() => api.do('member_action', { link_id: u.link_id, action: 'disconnect' }), `${u.name} disconnected`)}>Disconnect</button>}
            </span>}</div>
        ))}
        {d.invites.length > 0 && <p className="cu-gh">Invites</p>}
        {d.invites.map((i) => <div key={i.invite_id} className="cu-line"><span>{i.name} <span className="sub">· {i.work_email} · {i.sits} · {i.status}</span></span>
          {admin && i.status === 'Pending' && <span className="cu-actions"><button className="cu-link" onClick={() => go(() => api.do('invite_action', { invite_id: i.invite_id, action: 'resend' }), 'Resent')}>Resend</button><button className="cu-link" onClick={() => go(() => api.do('invite_action', { invite_id: i.invite_id, action: 'cancel' }))}>Cancel</button></span>}</div>)}
        {admin && <div className="cu-confirm cu-form"><b>Invite a person</b>
          <div className="cu-actions">
            <input placeholder="Work email" value={f.work_email || ''} onChange={(e) => set('work_email', e.target.value)} aria-label="Invite work email" />
            <input placeholder="Name" value={f.name || ''} onChange={(e) => set('name', e.target.value)} aria-label="Invite name" />
            <input placeholder="Mobile" value={f.mobile || ''} onChange={(e) => set('mobile', e.target.value)} aria-label="Invite mobile" />
            <input placeholder="Designation" value={f.designation || ''} onChange={(e) => set('designation', e.target.value)} aria-label="Invite designation" />
          </div>
          <div className="cu-actions">
            <select value={f.dept_bu_id || ''} onChange={(e) => set('dept_bu_id', e.target.value)} aria-label="Invite Dept/BU"><option value="">Department or BU…</option>{d.dept_bus.map((x) => <option key={x.dept_bu_id} value={x.dept_bu_id}>{x.name}</option>)}</select>
            <select value={f.sits || ''} onChange={(e) => set('sits', e.target.value)} aria-label="Where do they sit"><option value="">Where do they sit?</option><option>Admin above Dept/BU head</option><option>Dept/BU head or below</option></select>
          </div>
          <CodeField target={me.work_email} purpose="invite_sender" value={f.sender_code || ''} onChange={(v) => set('sender_code', v)} label="Your work-email code" />
          <div className="cu-actions"><button className="primary" onClick={() => go(() => api.do('invite', { entity_id: entity.entity_id, ...f }).then(() => setF({})), 'Invite sent')}>Send invite</button></div>
        </div>}
      </div>}

      {sec === 'hub' && (() => {
        const hub = { named: [], shared: [], website: { domain: '' }, invoice: 'Accounting module', ...(d.connection_hub || {}) };
        const save = (h) => go(() => api.do('save_connection_hub', { entity_id: entity.entity_id, hub: h }), 'Saved');
        return <div className="cu-sec">
          <p className="cu-gh">Email Settings</p>
          <p><span className="sub">Named Email</span> {(hub.named || []).join(', ') || '—'}</p>
          <p><span className="sub">Shared Email</span> {(hub.shared || []).join(', ') || '—'}</p>
          {admin && <div className="cu-actions"><input placeholder="Mailbox address" value={f.mail || ''} onChange={(e) => set('mail', e.target.value)} aria-label="Mailbox" />
            <button className="quiet" onClick={() => save({ ...hub, named: [...(hub.named || []), f.mail] })}>Add Named</button>
            <button className="quiet" onClick={() => save({ ...hub, shared: [...(hub.shared || []), f.mail] })}>Add Shared</button></div>}
          <p className="sub">Only connection status is ever shown; passwords are never displayed.</p>
          <p className="cu-gh">Website Settings</p>
          <p><span className="sub">Custom domain</span> {hub.website?.domain || '—'}</p>
          {admin && <div className="cu-actions"><input placeholder="Custom domain" value={f.domain || ''} onChange={(e) => set('domain', e.target.value)} aria-label="Domain" />
            <button className="quiet" onClick={() => save({ ...hub, website: { ...(hub.website || {}), domain: f.domain } })}>Save domain</button></div>}
          <p className="cu-gh">Invoice</p><p>{hub.invoice}</p>
          <p className="cu-gh">Integrations</p><p className="sub">Google, Microsoft, WhatsApp: not connected yet.</p>
        </div>;
      })()}

      {sec === 'krama' && <div className="cu-sec"><Catalogue entityId={entity.entity_id} onStarted={(runId) => ctx.openTaskCard(runId)} /><Console meta={ctx.meta} /></div>}

      {sec === 'ui' && <div className="cu-sec">
        <p><span className="sub">Screen variant</span> {d.ui.variant}</p>
        <p className="sub">Derived from the entity's size and Business Model; it changes when the model changes.</p>
        <p><span className="sub">Brand</span> Yousr on personal pages; compane from the entity onwards.</p>
      </div>}

      {sec === 'plan' && <div className="cu-sec">
        <div className="cu-focus"><span><b>{d.plan.plan}</b></span><span><b>{d.plan.seats_used}</b> of {d.plan.seats} seats</span><span><b>{d.plan.ai_questions_this_month}</b> AI uses</span></div>
      </div>}

      {sec === 'data' && <div className="cu-sec">
        {admin && <div className="cu-actions"><button className="quiet" onClick={async () => setExported(await api.do('entity_data', { entity_id: entity.entity_id, action: 'export' }))}>Export Data</button>
          {exported && <a className="cu-link" href={`data:application/json;charset=utf-8,${encodeURIComponent(JSON.stringify(exported, null, 2))}`} download={`${entity.name}-export.json`}>Download the export</a>}</div>}
        {d.delete_requested_at
          ? <><p className="ink">Deletion requested. The entity is deleted on {d.delete_on} unless cancelled.</p>
              {admin && <button className="quiet" onClick={() => go(() => api.do('entity_data', { entity_id: entity.entity_id, action: 'cancel_delete' }))}>Cancel deletion</button>}</>
          : admin && <><p className="sub">Delete Data deletes everything after a 30-day notice. Export your data first; an email confirms the request.</p>
              <button className="quiet" onClick={() => go(() => api.do('entity_data', { entity_id: entity.entity_id, action: 'delete' }))}>Delete Data</button></>}
      </div>}
      {msg && <p className="sub">{msg}</p>}
    </div>
  );
}

// ---------- Krama Phase 4: Report and Analytics, Modules, components ----------
export function ReportsCard({ entity }) {
  const [rows, , err] = useLoad(() => api.do('reports', { entity_id: entity.entity_id }), [entity.entity_id]);
  return (
    <div className="cu-card wide">
      {(rows || []).length === 0 && <p className="sub">No reports yet.</p>}
      {(rows || []).map((r, i) => {
        const vals = r.answer || [];
        const max = Math.max(1, ...vals.map((v) => Number(v.value) || 0));
        return (
          <div key={i} className="cu-topic">
            <p className="strong">{r.report} <span className="sub">· {r.krama} · {r.kind}{r.standalone ? ' · standalone' : ''}</span></p>
            <p className="sub">{r.question}</p>
            {vals.length === 0 && <p className="sub">Nothing to show yet.</p>}
            {vals.map((v, j) => (
              <div key={j} className="cu-bar"><span className="cu-bar-l">{v.label}</span><span className="cu-bar-t"><span style={{ width: `${(100 * (Number(v.value) || 0)) / max}%` }} /></span><span className="cu-bar-v">{Number(v.value || 0).toLocaleString('en-IN')}</span></div>
            ))}
          </div>
        );
      })}
      <Err m={err} />
    </div>
  );
}

export function KindsCard({ entity }) {
  const [rows, load, err] = useLoad(() => api.do('kinds', { entity_id: entity.entity_id }), [entity.entity_id]);
  const [open, setOpen] = useState(null);
  const [mod, setMod] = useState(null);
  const [f, setF] = useState({ kind: 'Module', name: '', standalone: true });
  const [r, setR] = useState({ name: '', question_text: '', metric: 'questions_by_state' });
  const [msg, setMsg] = useState('');
  const openIt = async (k) => { setOpen(k.krama_id); setMod(k.kind === 'Module' ? await api.do('module', { module_id: k.krama_id }) : null); };
  const go = async (fn) => { setMsg(''); try { await fn(); await load(); } catch (e) { setMsg(e.message); } };
  return (
    <div className="cu-card wide">
      {(rows || []).map((k) => (
        <div key={k.krama_id} className="cu-topic">
          <div className="cu-line"><span><b>{k.name}</b> <span className="sub">· {k.kind}{k.standalone ? ' · standalone' : ''} · {k.status} · {k.owner}</span></span>
            <button className="cu-link" onClick={() => (open === k.krama_id ? setOpen(null) : openIt(k))}>{open === k.krama_id ? 'Close' : 'Open'}</button></div>
          {open === k.krama_id && k.kind === 'Module' && mod && <>
            <p className="sub">Made of:</p>
            {mod.members.map((m) => <div key={m.krama_id} className="cu-line"><span>{m.name} v{m.version} <span className="sub">· {m.kind}</span></span>
              {k.can_design && k.status !== 'Published' && <button className="cu-link" onClick={async () => setMod(await api.do('module', { module_id: k.krama_id, remove: m.krama_id }))}>Remove</button>}</div>)}
            {k.can_design && k.status !== 'Published' && <div className="cu-actions"><select onChange={async (e) => { if (e.target.value) { try { setMod(await api.do('module', { module_id: k.krama_id, add: e.target.value })); } catch (x) { setMsg(x.message); } } }} value="" aria-label="Add to module">
              <option value="">Add a Published Krama…</option>{mod.available.map((m) => <option key={m.krama_id} value={m.krama_id}>{m.name} v{m.version} · {m.kind}</option>)}</select></div>}
            <p className="sub">Settings is the fixed part of every module.</p>
          </>}
          {open === k.krama_id && k.kind === 'Report and Analytics' && <>
            {k.reports.map((x, i) => <p key={i}>{x.name} <span className="sub">· {x.question_text}</span></p>)}
            {k.can_design && k.status !== 'Published' && <div className="cu-actions">
              <input placeholder="Report name" value={r.name} onChange={(e) => setR({ ...r, name: e.target.value })} aria-label="Report name" />
              <input placeholder="The question it answers" value={r.question_text} onChange={(e) => setR({ ...r, question_text: e.target.value })} aria-label="Report question" />
              <select value={r.metric} onChange={(e) => setR({ ...r, metric: e.target.value })} aria-label="Reads"><option value="runs_by_status">Tasks by status</option><option value="questions_by_state">Answers by state</option><option value="overdue_questions">Overdue questions</option><option value="runs_by_item">Tasks by item</option><option value="estimate_totals">Estimates</option></select>
              <button className="quiet" onClick={() => go(() => api.do('add_report', { krama_id: k.krama_id, ...r }).then(() => setR({ name: '', question_text: '', metric: 'questions_by_state' })))}>Add report</button></div>}
          </>}
        </div>
      ))}
      <div className="cu-confirm cu-form"><b>New</b>
        <div className="cu-actions">
          <select value={f.kind} onChange={(e) => setF({ ...f, kind: e.target.value })} aria-label="Kind"><option>Module</option><option>Report and Analytics</option></select>
          <input placeholder="Name" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} aria-label="New name" />
          {f.kind === 'Report and Analytics' && <label className="check"><input type="checkbox" checked={f.standalone} onChange={(e) => setF({ ...f, standalone: e.target.checked })} />Standalone</label>}
          <button className="quiet" onClick={() => go(() => api.do('new_krama', { entity_id: entity.entity_id, ...f }).then(() => setF({ ...f, name: '' })))}>Create</button>
        </div>
      </div>
      <Err m={err || msg} />
    </div>
  );
}

export function ComponentsCard({ entity }) {
  const [rows] = useLoad(() => api.do('components', {}), []);
  const [kramas, setKramas] = useState([]);
  const [pick, setPick] = useState({});
  const [msg, setMsg] = useState('');
  useEffect(() => { api.console().then((c) => setKramas(c.kramas.filter((k) => k.can_design && k.status !== 'Published' && k.owner_entity === entity.entity_id))).catch(() => {}); }, [entity.entity_id]);
  const k = kramas.find((x) => x.krama_id === pick.krama_id);
  return (
    <div className="cu-card wide">
      {(rows || []).map((c) => (
        <div key={c.component_id} className="cu-topic">
          <p className="strong">{c.name} <span className="sub">· {c.level} · Platform built · Platform owned</span></p>
          <p className="sub">{c.description}</p>
          <div className="cu-actions">
            <select value={pick.component_id === c.component_id ? pick.krama_id || '' : ''} onChange={(e) => setPick({ component_id: c.component_id, krama_id: e.target.value })} aria-label="Into Krama">
              <option value="">Insert into a Krama being designed…</option>{kramas.map((x) => <option key={x.krama_id} value={x.krama_id}>{x.name} v{x.version}</option>)}</select>
            {pick.component_id === c.component_id && k && c.level === 'Topic' && <select value={pick.stage_id || ''} onChange={(e) => setPick({ ...pick, stage_id: e.target.value })} aria-label="Stage"><option value="">Stage…</option>{k.stages.map((s) => <option key={s.stage_id} value={s.stage_id}>{s.name}</option>)}</select>}
            {pick.component_id === c.component_id && k && c.level === 'Question' && <select value={pick.topic_id || ''} onChange={(e) => setPick({ ...pick, topic_id: e.target.value })} aria-label="Topic"><option value="">Topic…</option>{k.stages.flatMap((s) => s.topics.map((t) => <option key={t.topic_id} value={t.topic_id}>{s.name} › {t.name}</option>))}</select>}
            {pick.component_id === c.component_id && pick.krama_id && <button className="quiet" onClick={async () => { setMsg(''); try { await api.do('insert_component', pick); setMsg(`${c.name} inserted into ${k.name}.`); } catch (e) { setMsg(e.message); } }}>Insert</button>}
          </div>
        </div>
      ))}
      {kramas.length === 0 && <p className="sub">No Krama of yours is being designed right now; components go into a Krama before it is Published.</p>}
      {msg && <p className="sub">{msg}</p>}
    </div>
  );
}

// ---------- Personas ----------
// Entity Persona: the type, what it applies to, and the obligatory and non-obligatory forks inherited down its path
export function EntityPersonaCard({ entity, ctx }) {
  const [d, load, err] = useLoad(() => api.do('entity_persona', { entity_id: entity.entity_id }), [entity.entity_id]);
  const [types, setTypes] = useState(null);
  const [pick, setPick] = useState('');
  const [msg, setMsg] = useState('');
  if (!d) return <div className="cu-card"><Err m={err} /></div>;
  const admin = ctx.access?.admin || ctx.isSuper;
  return (
    <div className="cu-card">
      <p><span className="sub">Entity Persona</span> <b>{d.path || 'Not set'}</b></p>
      {d.description && <p className="sub">{d.description}</p>}
      <p><span className="sub">Applies to legal forms</span> {(d.legal_forms || []).join(', ') || 'Any'}</p>
      <p><span className="sub">Applies to sizes</span> {(d.size_bands || []).join(', ') || 'Any'}</p>
      <p className="cu-gh">Obligatory</p>
      {(d.obligatory || []).length ? <p>{d.obligatory.join(' · ')}</p> : <p className="sub">None defined for this persona yet.</p>}
      <p className="cu-gh">Non-obligatory</p>
      {(d.non_obligatory || []).length ? <p>{d.non_obligatory.join(' · ')}</p> : <p className="sub">None defined for this persona yet.</p>}
      {admin && (types === null
        ? <div className="cu-actions"><button className="quiet" onClick={async () => setTypes(await api.do('entity_personas', {}))}>Change Entity Persona</button></div>
        : <div className="cu-actions">
            <select value={pick} onChange={(e) => setPick(e.target.value)} aria-label="Entity Persona"><option value="">Pick a persona type…</option>
              {types.map((t) => <option key={t.persona_type_id} value={t.persona_type_id}>{t.path}</option>)}</select>
            <button className="primary" disabled={!pick} onClick={async () => { setMsg(''); try { await api.do('set_entity_persona', { entity_id: entity.entity_id, persona_type_id: pick }); setTypes(null); load(); } catch (e) { setMsg(e.message); } }}>Save</button>
          </div>)}
      <Err m={msg} />
    </div>
  );
}

// Authority seats: set by the legal form, filled through the Work Personas attached to them
export function SpineCard({ entity }) {
  const [rows, , err] = useLoad(() => api.do('spine', { entity_id: entity.entity_id }), [entity.entity_id]);
  return (
    <div className="cu-card">
      {(rows || []).length === 0 && <p className="sub">No authority seats for this legal form.</p>}
      {(rows || []).map((s) => (
        <div key={s.seat_id} className="cu-line">
          <span><b>{s.seat}</b> <span className="sub">· {s.min}{s.max ? `–${s.max}` : '+'} by law · personas: {s.personas.join(', ') || 'none attached'}{s.people.length ? ` · ${s.people.join(', ')}` : ''}</span></span>
          <span className={s.filled < s.min ? 'ink' : 'sub'}>{s.filled} filled{s.filled < s.min ? ` · ${s.min - s.filled} short` : ''}</span>
        </div>
      ))}
      <p className="sub">A Work Persona attaches to one of these seats; it never creates a seat. Set it in Settings › Dept/BU and Work Personas.</p>
      <Err m={err} />
    </div>
  );
}

// Domain personas: defined requirements, permissible and not permissible, and seats; the platform super-user maintains them
export function DomainPersonasCard({ ctx }) {
  return <div className="cu-card wide"><DomainPersonas isSuper={ctx.isSuper} /></div>;
}
export function DomainPersonasCardOld({ ctx }) {
  const [rows, load, err] = useLoad(() => api.do('domain_personas', {}), []);
  const [f, setF] = useState(null);
  const [msg, setMsg] = useState('');
  return (
    <div className="cu-card wide">
      {(rows || []).map((d) => (
        <div key={d.domain_persona_id} className="cu-topic">
          <div className="cu-line"><b>{d.domain} › {d.name}</b><span className="sub">{d.catalogue} · {d.obligatory ? 'Obligatory' : 'Non-obligatory'}</span></div>
          {d.requirements && <p>{d.requirements}</p>}
          <p className="sub">Permissible: {d.permissible.join(', ') || '—'} · Not permissible: {d.not_permissible.join(', ') || '—'} · Seats: {d.seats.join(', ')}</p>
          {ctx.isSuper && <button className="cu-link" style={{ alignSelf: 'flex-start' }} onClick={() => setF({ ...d, permissible: d.permissible.join('\n'), not_permissible: d.not_permissible.join('\n') })}>Edit</button>}
        </div>
      ))}
      {ctx.isSuper && !f && <div className="cu-actions"><button className="quiet" onClick={() => setF({ catalogue: 'Business › Commercial', domain: '', name: '', obligatory: false, requirements: '', permissible: '', not_permissible: '', seats: ['Fulfiller'] })}>+ Domain persona</button></div>}
      {f && (
        <div className="cu-confirm cu-form">
          <div className="cu-actions">
            <select value={f.catalogue} onChange={(e) => setF({ ...f, catalogue: e.target.value })} aria-label="Catalogue">{['Compliance', 'Business › Process', 'Business › Commercial'].map((x) => <option key={x}>{x}</option>)}</select>
            <input placeholder="Domain" value={f.domain} onChange={(e) => setF({ ...f, domain: e.target.value })} aria-label="Domain" />
            <input placeholder="Domain persona" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} aria-label="Domain persona name" />
            <label className="check"><input type="checkbox" checked={!!f.obligatory} onChange={(e) => setF({ ...f, obligatory: e.target.checked })} />Obligatory</label>
          </div>
          <textarea rows={2} placeholder="Requirements" value={f.requirements || ''} onChange={(e) => setF({ ...f, requirements: e.target.value })} aria-label="Requirements" />
          <div className="cu-actions">
            <textarea rows={3} placeholder="Permissible, one per line" value={f.permissible} onChange={(e) => setF({ ...f, permissible: e.target.value })} aria-label="Permissible" />
            <textarea rows={3} placeholder="Not permissible, one per line" value={f.not_permissible} onChange={(e) => setF({ ...f, not_permissible: e.target.value })} aria-label="Not permissible" />
          </div>
          <div className="cu-actions">{['Fulfiller', 'Auditor', 'Representation'].map((x) => (
            <label key={x} className="check"><input type="checkbox" checked={f.seats.includes(x)} onChange={(e) => setF({ ...f, seats: e.target.checked ? [...f.seats, x] : f.seats.filter((y) => y !== x) })} />{x}</label>))}</div>
          <div className="cu-actions">
            <button className="primary" onClick={async () => { setMsg(''); try { await api.do('save_domain_persona', f); setF(null); load(); } catch (e) { setMsg(e.message); } }}>Save</button>
            <button className="quiet" onClick={() => setF(null)}>Cancel</button>
          </div>
        </div>
      )}
      <Err m={err || msg} />
    </div>
  );
}

const MODULES = ['WOM', 'Krama', 'Catalogue', 'Vendors', 'Connections', 'Revenue', 'Compliance', 'Reports'];
function PersonaRow({ p, admin, entity, onDone }) {
  const [edit, setEdit] = useState(null);
  const [seats, setSeats] = useState([]);
  const [msg, setMsg] = useState('');
  const open = async () => {
    const sp = await api.do('spine', { entity_id: entity.entity_id });
    setSeats(sp);
    const mine = sp.find((x) => x.personas.includes(p.name));
    setEdit({ modules: p.modules, actions: p.actions || ['View'], seat_id: mine ? mine.seat_id : '' });
  };
  const toggle = (k, v) => setEdit((e) => ({ ...e, [k]: e[k].includes(v) ? e[k].filter((x) => x !== v) : [...e[k], v] }));
  return (
    <div>
      <p>{p.name} <span className="sub">· {p.grade || '—'}{p.reports_to ? ` · reports to ${p.reports_to}` : ''} · sees {p.modules.join(', ')} · can {(p.actions || ['View']).join(', ')}</span>
        {admin && !edit && <button className="cu-link" onClick={open}> Edit</button>}</p>
      {edit && (
        <div className="cu-confirm cu-form">
          <div className="cu-checks"><span className="sub">Sees</span>{MODULES.map((m) => <label key={m} className="check"><input type="checkbox" checked={edit.modules.includes(m)} onChange={() => toggle('modules', m)} />{m}</label>)}</div>
          <div className="cu-checks"><span className="sub">Can</span>{['View', 'Approve', 'Sign'].map((a) => <label key={a} className="check"><input type="checkbox" checked={edit.actions.includes(a)} onChange={() => toggle('actions', a)} />{a}</label>)}</div>
          <div className="cu-actions"><span className="sub">Attaches to seat</span>
            <select value={edit.seat_id} onChange={(e) => setEdit({ ...edit, seat_id: e.target.value })} aria-label="Seat"><option value="">No authority seat</option>
              {seats.map((x) => <option key={x.seat_id} value={x.seat_id}>{x.seat} ({x.min}{x.max ? `–${x.max}` : '+'})</option>)}</select></div>
          <div className="cu-actions">
            <button className="primary" onClick={async () => { setMsg(''); try { await api.do('persona_edit', { persona_id: p.persona_id, ...edit }); setEdit(null); onDone(); } catch (e) { setMsg(e.message); } }}>Save</button>
            <button className="quiet" onClick={() => setEdit(null)}>Cancel</button>
          </div>
          <Err m={msg} />
        </div>
      )}
    </div>
  );
}
