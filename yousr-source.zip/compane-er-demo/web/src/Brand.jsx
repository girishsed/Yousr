// The approved logo (28 Oct 2026): two-arc circle mark + lowercase spaced wordmark, one unit, never separated.
// Same mark for both brands; only the wordmark changes: Compane (business side), Yousr (personal side).
export default function Brand({ name = 'compane', height = 40 }) {
  const yousr = name === 'Yousr';
  return (
    <svg height={height} viewBox="40 70 900 220" role="img" aria-label={yousr ? 'Yousr' : 'compane'} className="brand-logo">
      <path d="M 146.81 261.23 A 92 92 0 0 1 209.13 90.01" stroke="#D9573F" strokeWidth="22" fill="none" strokeLinecap="round" />
      <path d="M 233.19 98.77 A 92 92 0 0 1 170.87 269.99" stroke="#939BA4" strokeWidth="22" fill="none" strokeLinecap="round" />
      {yousr
        ? <text x="340" y="212" fontFamily="'Source Serif 4', Georgia, serif" fontWeight="500" fontSize="112" letterSpacing="10" fill="#2F3B4A">Yousr</text>
        : <text x="340" y="212" fontFamily="'Source Serif 4', Georgia, serif" fontWeight="400" fontSize="104" letterSpacing="22" fill="#E07A62">compane</text>}
    </svg>
  );
}

// The mark alone, at icon size, for side-menu items (locked 29 Oct 2026: mark kept, word in menu style)
export function Mark({ size = 18 }) {
  return (
    <svg width={size} height={size} viewBox="40 70 270 220" aria-hidden="true">
      <path d="M 146.81 261.23 A 92 92 0 0 1 209.13 90.01" stroke="#D9573F" strokeWidth="26" fill="none" strokeLinecap="round" />
      <path d="M 233.19 98.77 A 92 92 0 0 1 170.87 269.99" stroke="#939BA4" strokeWidth="26" fill="none" strokeLinecap="round" />
    </svg>
  );
}
