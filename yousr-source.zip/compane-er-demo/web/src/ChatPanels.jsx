import { useEffect, useState } from 'react';
import { api } from './api.js';
import { Question, Seats } from './Runs.jsx';
import { AddRoom, Members, Registry, Chat as RoomChat, Reports } from './TaskDetail.jsx';
import AuditReport from './AuditReport.jsx';
import TaskContext, { TaskControls } from './TaskContext.jsx';
import Console from './Console.jsx';
import Catalogue from './Catalogue.jsx';
import TableScreen from './TableScreen.jsx';
import Calendar from './Calendar.jsx';
import { PersonalTasks, QUADRANTS } from './Screens.jsx';

const QCODE = { 'Do now': 'DN', 'Do later': 'DL', Delegate: 'DG', Delete: 'DX' };
const KIND_RANK = { PR: 1, IR: 2, ER: 3 };
const PATH_RANK = { 'PR only': 1, 'PR → IR': 2, 'PR → IR → ER': 3 };
const Chips = ({ list, on, set }) => (
  <div className="cu-chips">{list.map(([k, l]) => <button key={k} className={on === k ? 'on' : ''} onClick={() => set(k)}>{l}</button>)}</div>
);

// Entity home, by quadrant: questions and Standalone tasks that involve you
export function HomeCard({ entity, ctx }) {
  const [rows, setRows] = useState(null);
  const [scope, setScope] = useState('with');
  const load = () => api.entityView(entity.entity_id, 'home').then(setRows).catch((e) => ctx.say(e.message));
  useEffect(() => { load(); }, [entity.entity_id]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!rows) return <div className="cu-card"><p className="sub">Loading…</p></div>;
  const shown = rows.filter((r) => scope === 'all' || (scope === 'with' ? r.with_me : !r.with_me));
  return (
    <div className="cu-card wide">
      <Chips list={[['with', 'With me'], ['others', 'With others'], ['all', 'All']]} on={scope} set={setScope} />
      {QUADRANTS.map((q) => {
        const list = shown.filter((r) => r.quadrant === q);
        if (!list.length) return null;
        return (
          <div key={q} className="cu-group">
            <p className="cu-gh"><span className="qc">{QCODE[q]}</span> {q}</p>
            {list.map((r) => (
              <div key={r.id} className="cu-line">
                <span><b>{r.title}</b> <span className="sub">{[r.ref, r.context, r.state, r.room, r.due_date && `due ${r.due_date}`].filter(Boolean).join(' · ')}</span></span>
                {r.kind === 'question'
                  ? <button className="cu-link" onClick={() => ctx.openTaskCard(r.run_id, r.id)}>Open</button>
                  : <button className="cu-link" onClick={() => ctx.addCard({ kind: 'standalone', id: r.id })}>Open</button>}
              </div>
            ))}
          </div>
        );
      })}
      {shown.length === 0 && <p className="sub">Nothing here.</p>}
      <div className="cu-actions"><button className="quiet" onClick={() => ctx.addCard({ kind: 'standalone' })}>New Standalone task</button></div>
    </div>
  );
}

// Standalone task: one person's own task, closed only when they mark it Done
export function StandaloneCard({ entity, id, ctx }) {
  const [t, setT] = useState(null);
  const [f, setF] = useState({ title: '', notes: '', due_date: '', quadrant: 'Do later' });
  const [msg, setMsg] = useState('');
  const [saved, setSaved] = useState('');
  useEffect(() => {
    if (!id) return;
    api.entityView(entity.entity_id, 'tasks').then((rows) => {
      const r = rows.find((x) => x.id === id); setT(r);
      if (r) setF({ title: r.title, notes: r.notes || '', due_date: r.next_due || '', quadrant: r.quadrant });
    });
  }, [id, entity.entity_id]);
  const done = t && t.status === 'Closed';
  const go = async (fn, word) => { setMsg(''); try { await fn(); setSaved(word); } catch (e) { setMsg(e.message); } };
  if (saved) return <div className="cu-card done">{saved}: {f.title}</div>;
  return (
    <div className="cu-card">
      <b>{id ? 'Standalone task' : 'New Standalone task'}</b>
      <input placeholder="Title" disabled={done} value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} aria-label="Title" />
      <textarea rows={2} placeholder="Notes" disabled={done} value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} aria-label="Notes" />
      <div className="cu-actions">
        <input type="date" disabled={done} value={f.due_date} onChange={(e) => setF({ ...f, due_date: e.target.value })} aria-label="Due date" />
        <select disabled={done} value={f.quadrant} onChange={(e) => setF({ ...f, quadrant: e.target.value })} aria-label="Quadrant">{QUADRANTS.map((q) => <option key={q}>{q}</option>)}</select>
      </div>
      {msg && <p className="error">{msg}</p>}
      <div className="cu-actions">
        {!id && <button className="primary" disabled={!f.title.trim()} onClick={() => go(() => api.createStandalone({ ...f, entity_id: entity.entity_id }), 'Created')}>Create</button>}
        {id && !done && <button className="quiet" onClick={() => go(() => api.updateStandalone(id, f), 'Saved')}>Save</button>}
        {id && !done && <button className="primary" onClick={() => go(() => api.doneStandalone(id), 'Done')}>Mark Done</button>}
        {done && <span className="sub">Done · conserved</span>}
      </div>
    </div>
  );
}

// A task (Krama run), whole: questions by room, rooms (topics, registry, members, room chat), seats, reports, history
export function TaskCard({ runId, focusQr, ctx }) {
  const [tree, setTree] = useState(null);
  const [part, setPart] = useState('questions');
  const [roomId, setRoomId] = useState(null);
  const [roomTab, setRoomTab] = useState('topics');
  const [roomData, setRoomData] = useState(null);
  const [adding, setAdding] = useState(false);
  const [msg, setMsg] = useState('');
  const load = async () => { try { const t = await api.run(runId); setTree(t); return t; } catch (e) { setMsg(e.message); return null; } };
  const loadRoom = async (id = roomId) => { if (!id) return; try { setRoomData(await api.room(id)); } catch { setRoomData(null); } };
  useEffect(() => { load().then((t) => {
    if (!t) return;
    let first = t.rooms.find((r) => r.member || t.is_super);
    if (focusQr) for (const s of t.stages) for (const tp of s.topics) for (const q of tp.questions) if (q.qr_id === focusQr && q.room_id) first = t.rooms.find((r) => r.room_id === q.room_id) || first;
    if (first) setRoomId(first.room_id);
  }); }, [runId]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { loadRoom(); }, [roomId]); // eslint-disable-line react-hooks/exhaustive-deps
  if (msg) return <div className="cu-card"><p className="error">{msg}</p></div>;
  if (!tree) return <div className="cu-card"><p className="sub">Loading…</p></div>;
  const reload = async () => { await load(); await loadRoom(); };
  const act = async (fn) => { try { await fn(); await reload(); } catch (e) { ctx.say(e.message); } };
  const rooms = tree.rooms.filter((r) => r.member || tree.is_super || r.can_grant);
  const room = tree.rooms.find((r) => r.room_id === roomId);
  const retains = (t) => room && room.topics.includes(t.topic_id);
  const inRoom = (t, q) => room && (q.room_id === room.room_id || (q.state === 'Agreed' && retains(t)));
  const roomName = (r) => (r.kind === 'PR' ? 'PR · Private' : `${r.kind} · ${r.name}`) + (r.with_name && r.kind === 'ER' ? ` with ${r.with_name}` : '') + (r.permission === 'Requested' ? ' · awaiting permission' : '');
  const blocked = room && room.permission === 'Requested';
  const notRetained = room ? tree.stages.flatMap((s) => s.topics.filter((t) => !retains(t) && KIND_RANK[room.kind] <= PATH_RANK[t.path])) : [];
  return (
    <div className="cu-card wide">
      <div className="cu-line"><b>{tree.item} · {tree.label}</b><span className="sub">{tree.locked ? `Conserved · ${tree.result}` : tree.status}</span></div>
      <p className="sub">{[tree.relationship, tree.counterparty_name, tree.fy, `${tree.krama} v${tree.version}`].filter(Boolean).join(' · ')}</p>
      <TaskContext runId={tree.run_id} />
      <TaskControls runId={tree.run_id} onDone={reload} />
      <Chips list={[['questions', 'Questions'], ['rooms', 'Rooms'], ['seats', 'Seats'], ['reports', 'Reports'], ...(tree.is_requestor || tree.is_super ? [['history', 'History and audit']] : [])]} on={part} set={setPart} />
      {tree.is_requestor && tree.locked && (
        <div className="cu-actions">
          <button className="primary" onClick={() => act(() => api.amend(tree.run_id))}>Amend</button>
          {tree.result === 'Unfulfilled' && <button className="quiet" onClick={async () => { try { const r = await api.do('start_again', { run_id: tree.run_id }); ctx.openTaskCard(r.run_id); } catch (e) { ctx.say(e.message); } }}>Start again as a new instance</button>}
        </div>
      )}

      {(part === 'questions' || part === 'rooms') && (
        <div className="cu-chips sub-chips">
          {rooms.map((r) => <button key={r.room_id} className={r.room_id === roomId ? 'on' : ''} onClick={() => { setRoomId(r.room_id); setRoomTab('topics'); }}>{roomName(r)}</button>)}
          {part === 'rooms' && tree.is_requestor && !tree.locked && <button onClick={() => setAdding(!adding)}>+ Room</button>}
        </div>
      )}
      {adding && part === 'rooms' && <AddRoom tree={tree} companies={ctx.companies} onDone={async (id) => { setAdding(false); await load(); if (id) setRoomId(id); }} />}

      {part === 'questions' && room && (blocked ? <p className="sub">This room waits for permission from the other party in {room.parent_name}.</p> : (
        <div className="cu-qs">
          {tree.stages.map((s) => {
            const topics = s.topics.filter((t) => retains(t)).map((t) => ({ t, qs: t.questions.filter((q) => inRoom(t, q)) })).filter((x) => x.qs.length);
            if (!topics.length) return null;
            return (
              <div key={s.stage_id}>
                <p className="cu-gh">{s.name} <span className="sub">· {s.path} · {s.status}{s.my_seats.length ? ` · your seat: ${s.my_seats.join(', ')}` : ''}</span></p>
                {topics.map(({ t, qs }) => (
                  <div key={t.topic_id} className="cu-topic">
                    <p className="strong">{t.name} <span className="sub">· {t.status}</span></p>
                    {qs.map((q) => <Question key={q.qr_id} q={q} stage={s} tree={tree} room={room} meta={ctx.meta} onDone={reload} highlight={q.qr_id === focusQr} />)}
                  </div>
                ))}
              </div>
            );
          })}
          {(tree.split || []).filter((g) => g.room_id === room.room_id).map((g) => (
            <div key={g.source_qr} className="cu-topic">
              <p className="strong">Called in: {g.question}</p>
              {g.lines.map((l) => (
                <div key={l.line_id} className="cu-line"><span>{l.text}</span>
                  <span>{l.state === 'Agreed' ? <span className="sub">Agreed</span> : <button className="cu-link" onClick={() => act(() => api.settleLine(l.line_id, window.prompt('How was it settled?') || ''))}>Settle</button>}</span></div>
              ))}
            </div>
          ))}
        </div>
      ))}

      {part === 'rooms' && room && (blocked ? (
        <div className="cu-confirm"><p>This child room waits for permission from the other party in {room.parent_name}.</p>
          {room.can_grant && <div className="cu-actions"><button className="primary" onClick={() => act(() => api.roomAct(room.room_id, 'grant'))}>Give permission</button></div>}</div>
      ) : (
        <>
          <Chips list={[['topics', 'Topics'], ['registry', 'Registry'], ['members', 'Members'], ['chat', 'Room chat']]} on={roomTab} set={setRoomTab} />
          {roomTab === 'topics' && (
            <div>
              {tree.stages.flatMap((s) => s.topics.filter((t) => retains(t)).map((t) => (
                <div key={t.topic_id} className="cu-line"><span>{t.name} <span className="sub">· {s.name} · {t.path}</span></span>
                  {tree.is_requestor && !tree.locked && room.kind !== 'PR' && <button className="cu-link" onClick={() => act(() => api.roomAct(room.room_id, 'topics', { topic_id: t.topic_id, retain: false }))}>Delete from room</button>}</div>
              )))}
              {tree.is_requestor && !tree.locked && notRetained.map((t) => (
                <div key={t.topic_id} className="cu-line"><span className="sub">{t.name} · deleted from this room</span>
                  <button className="cu-link" onClick={() => act(() => api.roomAct(room.room_id, 'topics', { topic_id: t.topic_id, retain: true }))}>Retain</button></div>
              ))}
            </div>
          )}
          {roomTab === 'registry' && <Registry data={roomData} tree={tree} onDone={loadRoom} />}
          {roomTab === 'members' && <Members room={room} tree={tree} people={ctx.people} onDone={reload} />}
          {roomTab === 'chat' && roomData && <div className="cu-roomchat"><RoomChat data={roomData} room={room} tree={tree} onDone={loadRoom} /></div>}
        </>
      ))}

      {part === 'seats' && <Seats tree={tree} people={ctx.people} meta={ctx.meta} onDone={reload} />}
      {part === 'reports' && <Reports tree={tree} companies={ctx.companies} act={act} />}
      {part === 'history' && <AuditReport runId={tree.run_id} onBack={() => setPart('questions')} />}
    </div>
  );
}

// Whole sections embedded as cards
export function SettingsCard({ entity, ctx }) {
  const [tab, setTab] = useState('krama');
  return (
    <div className="cu-card wide">
      <Chips list={[['krama', 'Krama'], ['console', 'Krama console']]} on={tab} set={setTab} />
      {tab === 'krama' ? <Catalogue entityId={entity.entity_id} onStarted={(runId) => ctx.openTaskCard(runId)} /> : <Console meta={ctx.meta} />}
    </div>
  );
}

export function MastersCard({ ctx }) {
  const tables = (ctx.meta?.entities || []);
  const [key, setKey] = useState('');
  const e = tables.find((t) => t.key === key);
  return (
    <div className="cu-card wide">
      <div className="cu-chips">{tables.map((t) => <button key={t.key} className={t.key === key ? 'on' : ''} onClick={() => setKey(t.key)}>{t.label}</button>)}</div>
      {e && <TableScreen key={e.key} ent={e} byKey={ctx.byKey} meta={ctx.meta} canWrite={ctx.isSuper && !e.readOnly}
        note={e.readOnly ? `${e.label} change only through actions.` : e.design ? 'Design rows of a Published Krama are frozen; use New version in the Krama console.' : ''} />}
    </div>
  );
}

export function CalendarCard({ ctx }) {
  return <div className="cu-card wide"><Calendar onOpen={(runId, qrId) => runId && ctx.openTaskCard(runId, qrId)} onPickDay={() => ctx.full && ctx.exitFull()} /></div>;
}

export function PersonalTasksCard() {
  return <div className="cu-card wide cu-embed"><PersonalTasks /></div>;
}

export function EntitiesCard({ entities, ctx }) {
  return (
    <div className="cu-card">
      {entities.map((e) => (
        <div key={e.entity_id} className="cu-line"><b>{e.name}</b><button className="cu-link" onClick={() => ctx.switchEntity(e)}>Work here</button></div>
      ))}
    </div>
  );
}

// ---------- Catalogue item: its own pages, one chip each ----------
const SECTIONS = [['overview', 'Overview'], ['visibility', 'Visibility'], ['variants', 'Variants'], ['content', 'Content'],
  ['ra', 'Report and Analytics'], ['marketing', 'Marketing'], ['journey', 'Journey & Dependencies'], ['seats', 'Seats']];
const PRICING = ['Fixed', 'Per unit', 'Per hour', 'Per sprint', 'Package', 'Request quote'];
const SEATS = ['Buyer', 'Seller', 'Fulfiller', 'Assurer', 'Representation'];
const VARIANT_NAMES = { SKU: ['Standard', 'Pack', 'Bulk'], SDU: ['Basic', 'Standard', 'Premium'], Services: ['Basic', 'Standard', 'Premium', 'Retainer'] };

function F({ label, children }) { return <label className="cu-f"><span>{label}</span>{children}</label>; }

export function ItemPanel({ itemId, ctx }) {
  const [it, setIt] = useState(null);
  const [sec, setSec] = useState('overview');
  const [edit, setEdit] = useState(false);
  const [draft, setDraft] = useState(null);
  const [kramas, setKramas] = useState([]);
  const [dps, setDps] = useState([]);
  useEffect(() => { api.do('domain_personas', {}).then(setDps).catch(() => {}); }, []);
  const [msg, setMsg] = useState('');
  const load = () => api.catalogue().then((c) => setIt(c.items.find((x) => x.item_id === itemId))).catch((e) => setMsg(e.message));
  useEffect(() => { load(); }, [itemId]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { if (it) api.journeyKramas(it.entity_id).then(setKramas).catch(() => {}); }, [it?.entity_id]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!it) return <div className="cu-card">{msg ? <p className="error">{msg}</p> : <p className="sub">Loading…</p>}</div>;
  const d = it.detail || {};
  const ov = d.overview || {};
  const vis = d.visibility || {};
  const variants = (d.variants && d.variants.list) || [];
  const store = sec === 'journey' ? 'variants' : sec;
  const startEdit = () => { setMsg(''); setDraft(JSON.parse(JSON.stringify(store === 'variants' ? { list: variants } : (d[store] || {})))); setEdit(true); };
  const save = async () => { setMsg(''); try { await api.saveSection(it.item_id, store, draft); setEdit(false); await load(); } catch (e) { setMsg(e.message); } };
  const set = (k, v) => setDraft((x) => ({ ...x, [k]: v }));
  const side = vis.scope === 'Internal' ? 'internal' : vis.reach === 'Vendor' ? 'buy' : 'sell';
  const journeyLabel = side === 'buy' ? 'Deal' : side === 'sell' ? 'Opportunity' : 'Process';
  const deptNames = (it.dept_bus || []).map((x) => x.name);
  const editable = it.can_edit && sec !== 'ra';

  return (
    <div className="cu-card wide">
      <div className="cu-line"><b>{it.name}</b><span className="sub">{it.catalogue_code || 'Catalogue ID on first save'} · {ov.release || 'Alpha'}</span></div>
      <div className="cu-chips">{SECTIONS.map(([k, l]) => <button key={k} className={sec === k ? 'on' : ''} onClick={() => { setSec(k); setEdit(false); }}>{l}</button>)}</div>

      {!edit && (
        <div className="cu-sec">
          {sec === 'overview' && (ov.catalogue ? <>
            <p><span className="sub">Catalogue</span> {ov.catalogue}</p><p><span className="sub">Item type</span> {ov.item_type}</p>
            <p><span className="sub">Domain</span> {ov.domain}</p><p><span className="sub">Domain persona</span> {ov.domain_persona}</p>
            <p><span className="sub">Release</span> {ov.release || 'Alpha'}</p>
            {(() => { const dp = dps.find((x) => x.domain === ov.domain && x.name === ov.domain_persona); return dp ? (
              <div className="cu-topic"><p className="strong">Domain persona: {dp.name} <span className="sub">· {dp.obligatory ? 'Obligatory' : 'Non-obligatory'}</span></p>
                {dp.requirements && <p>{dp.requirements}</p>}
                <p className="sub">Permissible: {dp.permissible.join(', ') || '—'} · Not permissible: {dp.not_permissible.join(', ') || '—'} · Seats: {dp.seats.join(', ')}</p></div>
            ) : <p className="sub">This domain persona has no definition yet.</p>; })()}
          </> : <p className="sub">Not set up yet.</p>)}
          {sec === 'visibility' && (vis.scope ? (vis.scope === 'External'
            ? <p>External → {vis.reach}{vis.reach !== 'Discover and Connect' ? ` → ${vis.mode}${vis.mode === 'Customised' ? `: ${(vis.names || []).join(', ')}` : ''}` : ''}
                <span className="sub"> · {vis.reach === 'Vendor' ? 'buy side' : 'sell side'}</span></p>
            : <p>Internal → Host {vis.host} → {vis.use}{vis.use === 'Internal client' ? `: ${(vis.clients || []).join(', ')}` : ''}</p>) : <p className="sub">Not set up yet.</p>)}
          {sec === 'variants' && (variants.length ? variants.map((v, i) => (
            <div key={i} className="cu-topic">
              <p className="strong">{v.name}</p>
              <p className="sub">{v.pricing_type}{v.price ? ` · ₹${Number(v.price).toLocaleString('en-IN')}` : ''} · {v.tax || 'Plus tax'}{v.hsn ? ` · HSN/SAC ${v.hsn}` : ''}{v.gst ? ` · GST ${v.gst}%` : ''}</p>
              {(v.quote_wording || v.invoice_wording) && <p className="sub">Quotation: {v.quote_wording || '—'} · Invoice: {v.invoice_wording || '—'}</p>}
              <p className="sub">Offer: {v.offer_amount ? `${v.offer_amount} for ${v.offer_for || 'everyone'}${v.offer_until ? ` until ${v.offer_until}` : ''}` : 'none'} · Promo: {v.promo || '—'}</p>
            </div>
          )) : <p className="sub">No variants yet.</p>)}
          {sec === 'content' && (d.content ? <>
            <p><span className="sub">Title</span> {d.content.title}</p><p><span className="sub">Catalogue ID</span> {it.catalogue_code}</p>
            <p><span className="sub">Main image</span> {d.content.main_image || '—'}</p>
            {(d.content.blocks || []).map((b, i) => <p key={i}><span className="sub">{b.kind}</span> {b.value}</p>)}
          </> : <p className="sub">No content yet.</p>)}
          {sec === 'ra' && <>
            <div className="cu-focus"><span><b>{it.runs_count}</b> runs</span><span><b>{it.runs_open}</b> open</span><span><b>{it.runs_count - it.runs_open}</b> closed</span></div>
            {it.reports.length === 0 && <p className="sub">The item's Kramas have no reports yet.</p>}
            {it.reports.map((r, i) => <p key={i}><b>{r.name}</b> <span className="sub">· {r.question_text} · from {r.krama}</span></p>)}
            {it.runs_count === 0 && <p className="sub">No live data yet; reports show a sample preview.</p>}
          </>}
          {sec === 'marketing' && (d.marketing ? <>
            <p><span className="sub">Brand</span> {d.marketing.brand} · {d.marketing.category} › {d.marketing.sub_category}</p>
            <p><span className="sub">Landing page</span> {d.marketing.landing || 'Not generated yet'}</p>
            {(d.marketing.competitors || []).map((c, i) => <p key={i}><span className="sub">Competitor</span> {c.brand} · {c.business} · {c.website}</p>)}
          </> : <p className="sub">Not set up yet.</p>)}
          {sec === 'journey' && (variants.length ? variants.map((v, i) => (
            <div key={i} className="cu-topic">
              <p className="strong">{v.name}</p>
              <p>{side === 'internal' ? `Process: ${v.journey?.process || '—'}` : `${journeyLabel}: ${v.journey?.[side === 'buy' ? 'deal' : 'opportunity'] || '—'} → Order management: ${v.journey?.order || '—'}`}</p>
              {(v.dependencies || []).map((x, j) => <p key={j} className="sub">Depends on {x.fork === 'Catalogue' ? 'item' : 'Krama'} {x.target} · {x.when}{x.outside ? ' · done outside the platform' : ''}</p>)}
            </div>
          )) : <p className="sub">Add variants first; each variant has its own journey.</p>)}
          {sec === 'seats' && SEATS.map((s) => {
            const x = (d.seats || {})[s] || {};
            return <p key={s}><span className="sub">{s}</span> {x.who ? `${x.who} (${x.side})` : '—'}{s === 'Fulfiller' && x.who ? <span className="sub"> · owner: {x.side === 'External' ? 'vendor' : 'entity'}</span> : ''}</p>;
          })}
          {editable && <div className="cu-actions"><button className="quiet" onClick={startEdit}>Edit</button></div>}
        </div>
      )}

      {edit && draft && (
        <div className="cu-sec cu-form">
          {sec === 'overview' && <>
            <F label="Catalogue"><select value={draft.catalogue || ''} onChange={(e) => set('catalogue', e.target.value)}><option value="">Pick…</option>{['Compliance', 'Business › Process', 'Business › Commercial'].map((x) => <option key={x}>{x}</option>)}</select></F>
            <F label="Item type"><select value={draft.item_type || ''} onChange={(e) => set('item_type', e.target.value)}><option value="">Pick…</option>{['SKU', 'SDU', 'Services'].map((x) => <option key={x}>{x}</option>)}</select></F>
            <F label="Domain persona (defined)"><select value={dps.find((x) => x.domain === draft.domain && x.name === draft.domain_persona)?.domain_persona_id || ''}
              onChange={(e) => { const dp = dps.find((x) => x.domain_persona_id === e.target.value); if (dp) setDraft((x) => ({ ...x, domain: dp.domain, domain_persona: dp.name })); }}>
              <option value="">Pick from the defined domain personas…</option>
              {dps.filter((x) => !draft.catalogue || x.catalogue === draft.catalogue).map((x) => <option key={x.domain_persona_id} value={x.domain_persona_id}>{x.domain} › {x.name}</option>)}</select></F>
            <F label="Domain"><input value={draft.domain || ''} onChange={(e) => set('domain', e.target.value)} /></F>
            <F label="Domain persona"><input value={draft.domain_persona || ''} onChange={(e) => set('domain_persona', e.target.value)} /></F>
            <F label="Release"><select value={draft.release || 'Alpha'} onChange={(e) => set('release', e.target.value)}>{['Alpha', 'Pilot', 'Beta', 'General Availability'].map((x) => <option key={x}>{x}</option>)}</select></F>
          </>}
          {sec === 'visibility' && <>
            <F label="Scope"><select value={draft.scope || ''} onChange={(e) => set('scope', e.target.value)}><option value="">Pick…</option><option>External</option><option>Internal</option></select></F>
            {draft.scope === 'External' && <>
              <F label="Reach"><select value={draft.reach || ''} onChange={(e) => set('reach', e.target.value)}><option value="">Pick…</option><option>Discover and Connect</option><option value="Client">Client (sell side)</option><option value="Vendor">Vendor (buy side)</option></select></F>
              {draft.reach && draft.reach !== 'Discover and Connect' && <F label="Who sees it"><select value={draft.mode || ''} onChange={(e) => set('mode', e.target.value)}><option value="">Pick…</option><option>Generic</option><option>Customised</option></select></F>}
              {draft.mode === 'Customised' && <F label="Named (including pre-clients and pre-vendors)"><div className="cu-checks">{ctx.companies.filter((c) => c.user_id !== it.entity_id).map((c) => (
                <label key={c.user_id} className="check"><input type="checkbox" checked={(draft.names || []).includes(c.name)}
                  onChange={(e) => set('names', e.target.checked ? [...(draft.names || []), c.name] : (draft.names || []).filter((n) => n !== c.name))} />{c.name}</label>))}</div></F>}
            </>}
            {draft.scope === 'Internal' && <>
              <F label="Host (the Dept/BU that owns it)"><select value={draft.host || ''} onChange={(e) => set('host', e.target.value)}><option value="">Pick…</option>{deptNames.map((x) => <option key={x}>{x}</option>)}</select></F>
              <F label="Used by"><select value={draft.use || ''} onChange={(e) => set('use', e.target.value)}><option value="">Pick…</option><option>Internal client</option><option>Self</option></select></F>
              {draft.use === 'Internal client' && <F label="Internal client: one, some or all Dept/BUs"><div className="cu-checks">{deptNames.filter((x) => x !== draft.host).map((x) => (
                <label key={x} className="check"><input type="checkbox" checked={(draft.clients || []).includes(x)}
                  onChange={(e) => set('clients', e.target.checked ? [...(draft.clients || []), x] : (draft.clients || []).filter((n) => n !== x))} />{x}</label>))}</div></F>}
            </>}
          </>}
          {(sec === 'variants' || sec === 'journey') && <>
            {(draft.list || []).map((v, i) => {
              const up = (k, val) => set('list', draft.list.map((x, j) => (j === i ? { ...x, [k]: val } : x)));
              const upJ = (k, val) => up('journey', { ...(v.journey || {}), [k]: val });
              return (
                <div key={i} className="cu-topic cu-form">
                  <div className="cu-line"><input value={v.name || ''} placeholder="Variant name" onChange={(e) => up('name', e.target.value)} aria-label="Variant name" />
                    <button className="cu-link" onClick={() => set('list', draft.list.filter((_, j) => j !== i))}>Remove</button></div>
                  {sec === 'variants' ? <>
                    <div className="cu-actions">
                      <select value={v.pricing_type || ''} onChange={(e) => up('pricing_type', e.target.value)} aria-label="Pricing type"><option value="">Pricing type…</option>{PRICING.map((x) => <option key={x}>{x}</option>)}</select>
                      {v.pricing_type !== 'Request quote' && <input value={v.price || ''} placeholder="Price" onChange={(e) => up('price', e.target.value)} aria-label="Price" />}
                      <select value={v.tax || 'Plus tax'} onChange={(e) => up('tax', e.target.value)} aria-label="Tax"><option>Plus tax</option><option>Tax included</option></select>
                      <input value={v.hsn || ''} placeholder="HSN/SAC" onChange={(e) => up('hsn', e.target.value)} aria-label="HSN/SAC" />
                      <input value={v.gst || ''} placeholder="GST %" onChange={(e) => up('gst', e.target.value)} aria-label="GST rate" />
                    </div>
                    <div className="cu-actions">
                      <input value={v.quote_wording || ''} placeholder="Quotation wording" onChange={(e) => up('quote_wording', e.target.value)} aria-label="Quotation wording" />
                      <input value={v.invoice_wording || ''} placeholder="Invoice wording" onChange={(e) => up('invoice_wording', e.target.value)} aria-label="Invoice wording" />
                    </div>
                    <div className="cu-actions">
                      <input value={v.offer_amount || ''} placeholder="Offer (% or amount)" onChange={(e) => up('offer_amount', e.target.value)} aria-label="Offer" />
                      <input value={v.offer_for || ''} placeholder="For (everyone or names)" onChange={(e) => up('offer_for', e.target.value)} aria-label="Offer for" />
                      <input type="date" value={v.offer_until || ''} onChange={(e) => up('offer_until', e.target.value)} aria-label="Offer until" />
                      <input value={v.promo || ''} placeholder="Promo, or Not applicable" onChange={(e) => up('promo', e.target.value)} aria-label="Promo" />
                    </div>
                  </> : <>
                    {side === 'internal'
                      ? <select value={v.journey?.process || ''} onChange={(e) => upJ('process', e.target.value)} aria-label="Process"><option value="">Process Krama…</option>{kramas.map((k) => <option key={k.krama_id}>{k.name}</option>)}</select>
                      : <div className="cu-actions">
                          <select value={v.journey?.[side === 'buy' ? 'deal' : 'opportunity'] || ''} onChange={(e) => upJ(side === 'buy' ? 'deal' : 'opportunity', e.target.value)} aria-label={journeyLabel}>
                            <option value="">{journeyLabel} Krama…</option>{kramas.map((k) => <option key={k.krama_id}>{k.name}</option>)}</select>
                          <select value={v.journey?.order || ''} onChange={(e) => upJ('order', e.target.value)} aria-label="Order management"><option value="">Order management Krama…</option>{kramas.map((k) => <option key={k.krama_id}>{k.name}</option>)}</select>
                        </div>}
                    {(v.dependencies || []).map((x, j) => (
                      <div key={j} className="cu-actions">
                        <select value={x.fork} onChange={(e) => up('dependencies', v.dependencies.map((y, n) => (n === j ? { ...y, fork: e.target.value } : y)))} aria-label="Fork"><option>Krama</option><option>Catalogue</option></select>
                        <input value={x.target} placeholder={x.fork === 'Catalogue' ? 'Catalogue item' : 'Krama'} onChange={(e) => up('dependencies', v.dependencies.map((y, n) => (n === j ? { ...y, target: e.target.value } : y)))} aria-label="Depends on" />
                        <select value={x.when} onChange={(e) => up('dependencies', v.dependencies.map((y, n) => (n === j ? { ...y, when: e.target.value } : y)))} aria-label="When"><option>Before</option><option>After</option></select>
                        <label className="check"><input type="checkbox" checked={!!x.outside} onChange={(e) => up('dependencies', v.dependencies.map((y, n) => (n === j ? { ...y, outside: e.target.checked } : y)))} />Done outside the platform</label>
                      </div>
                    ))}
                    <button className="cu-link" style={{ alignSelf: 'flex-start' }} onClick={() => up('dependencies', [...(v.dependencies || []), { fork: 'Krama', target: '', when: 'Before', outside: false }])}>+ Dependency</button>
                  </>}
                </div>
              );
            })}
            {sec === 'variants' && (
              <div className="cu-actions">
                {(VARIANT_NAMES[ov.item_type] || ['Standard']).map((n) => <button key={n} className="quiet" onClick={() => set('list', [...(draft.list || []), { name: n, pricing_type: '', tax: 'Plus tax' }])}>+ {n}</button>)}
                {(draft.list || []).length > 0 && <button className="quiet" onClick={() => { const src = draft.list[draft.list.length - 1]; set('list', [...draft.list, { ...JSON.parse(JSON.stringify(src)), name: `${src.name} copy` }]); }}>Copy last variant</button>}
              </div>
            )}
          </>}
          {sec === 'content' && <>
            <F label="Title"><input value={draft.title || ''} onChange={(e) => set('title', e.target.value)} /></F>
            <F label="Main image"><input value={draft.main_image || ''} placeholder="File name" onChange={(e) => set('main_image', e.target.value)} /></F>
            {(draft.blocks || []).map((b, i) => (
              <div key={i} className="cu-actions"><span className="sub">{b.kind}</span>
                <input value={b.value} onChange={(e) => set('blocks', draft.blocks.map((x, j) => (j === i ? { ...x, value: e.target.value } : x)))} aria-label={b.kind} />
                <button className="cu-link" onClick={() => set('blocks', draft.blocks.filter((_, j) => j !== i))}>Remove</button></div>
            ))}
            <div className="cu-actions">{['Text', 'Image', 'Video'].map((k) => <button key={k} className="quiet" onClick={() => set('blocks', [...(draft.blocks || []), { kind: k, value: '' }])}>+ {k}</button>)}</div>
          </>}
          {sec === 'marketing' && <>
            <div className="cu-actions">
              <input value={draft.brand || ''} placeholder="Brand name" onChange={(e) => set('brand', e.target.value)} aria-label="Brand" />
              <input value={draft.category || ''} placeholder="Category" onChange={(e) => set('category', e.target.value)} aria-label="Category" />
              <input value={draft.sub_category || ''} placeholder="Sub-category" onChange={(e) => set('sub_category', e.target.value)} aria-label="Sub-category" />
            </div>
            <div className="cu-actions">
              <button className="quiet" onClick={() => set('landing', `compane.ai/${(it.entity_name || '').toLowerCase().replace(/\s+/g, '-')}/${it.name.toLowerCase().replace(/\s+/g, '-')}`)}>Generate landing page</button>
              <input value={draft.landing || ''} placeholder="Or the address of a page built outside" onChange={(e) => set('landing', e.target.value)} aria-label="Landing page" />
            </div>
            {(draft.competitors || []).map((c, i) => {
              const up = (k, v) => set('competitors', draft.competitors.map((x, j) => (j === i ? { ...x, [k]: v } : x)));
              return <div key={i} className="cu-actions"><input value={c.brand} placeholder="Brand" onChange={(e) => up('brand', e.target.value)} aria-label="Competitor brand" />
                <input value={c.business} placeholder="Business name" onChange={(e) => up('business', e.target.value)} aria-label="Business name" />
                <input value={c.website} placeholder="Website" onChange={(e) => up('website', e.target.value)} aria-label="Website" />
                <button className="cu-link" onClick={() => set('competitors', draft.competitors.filter((_, j) => j !== i))}>Remove</button></div>;
            })}
            <button className="cu-link" style={{ alignSelf: 'flex-start' }} onClick={() => set('competitors', [...(draft.competitors || []), { brand: '', business: '', website: '' }])}>+ Competitor</button>
          </>}
          {sec === 'seats' && SEATS.map((s) => {
            const x = draft[s] || { side: '', who: '' };
            return (
              <div key={s} className="cu-actions"><span className="cu-seat">{s}</span>
                <select value={x.side} onChange={(e) => set(s, { side: e.target.value, who: '' })} aria-label={`${s} side`}><option value="">Not seated</option><option>Internal</option><option>External</option></select>
                {x.side === 'Internal' && <select value={x.who} onChange={(e) => set(s, { ...x, who: e.target.value })} aria-label={`${s} Dept/BU`}><option value="">Dept/BU…</option>{deptNames.map((n) => <option key={n}>{n}</option>)}</select>}
                {x.side === 'External' && <select value={x.who} onChange={(e) => set(s, { ...x, who: e.target.value })} aria-label={`${s} entity`}><option value="">Client or vendor…</option>{ctx.companies.filter((c) => c.user_id !== it.entity_id).map((c) => <option key={c.user_id}>{c.name}</option>)}</select>}
              </div>
            );
          })}
          {msg && <p className="error">{msg}</p>}
          <div className="cu-actions"><button className="primary" onClick={save}>Save</button><button className="quiet" onClick={() => setEdit(false)}>Cancel</button></div>
        </div>
      )}
    </div>
  );
}
