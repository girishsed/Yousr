import { useEffect, useState } from 'react';
import { api } from './api.js';
import Calendar from './Calendar.jsx';

export default function Home({ onOpen }) {
  const [h, setH] = useState(null);
  const [msg, setMsg] = useState('');
  const [tick, setTick] = useState(0);
  const load = () => api.home().then((d) => { setH(d); setTick((t) => t + 1); }).catch((e) => setMsg(e.message));
  useEffect(() => { load(); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  if (msg) return <p className="error" role="alert">{msg}</p>;
  if (!h) return <p className="hint">Loading…</p>;

  const list = (items, empty, extra) => (
    items.length === 0 ? <p className="hint">{empty}</p> : items.map((t) => (
      <button key={t.qr_id} className="task" onClick={() => onOpen(t.run_id, t.qr_id)}>
        <span className="task-title">{t.question}</span>
        <span className="run-meta">{t.item} · {t.label}</span>
        {extra(t)}
        {t.due_date && <span className="due-ink">Due {t.due_date}</span>}
      </button>
    ))
  );

  return (
    <div className="dash">
      <div className="dash-grid three">
        <section className="dash-col" aria-label="To answer">
          <h2>To answer <span className="dash-count">{h.to_answer.length}</span></h2>
          <p className="hint">Questions where you are the Doer</p>
          {list(h.to_answer, 'Nothing to answer.', (t) => t.state === 'Contested' && <span className="task-detail">Contested — answer again</span>)}
        </section>
        <Standalone h={h} reload={load} />
        <section className="dash-col" aria-label="To decide">
          <h2>To decide <span className="dash-count">{h.to_decide.length}</span></h2>
          <p className="hint">Answers waiting for you to review, agree or contest</p>
          {list(h.to_decide, 'Nothing to decide.', (t) => t.from && <span className="task-detail">Answered by {t.from}</span>)}
        </section>
      </div>
      <div className="dash-lower">
        <Calendar key={tick} onOpen={(runId, qrId) => runId && onOpen(runId, qrId)} />
        <section className="dash-col" aria-label="Conserved">
          <h2>Conserved <span className="dash-count">{h.conserved.length + h.standalone.filter((t) => t.status === 'Done').length}</span></h2>
          <p className="hint">Locked runs and done Standalone tasks, kept under their FY</p>
          {h.conserved.length === 0 && h.standalone.every((t) => t.status !== 'Done') && <p className="hint">Nothing conserved yet.</p>}
          {h.standalone.filter((t) => t.status === 'Done').map((t) => (
            <div key={t.task_id} className="task static">
              <span className="task-title">{t.title}</span>
              <span className="run-meta">Standalone · {t.entity_name} · {t.fy}</span>
              <span className="oc">Done {t.done_on}</span>
            </div>
          ))}
          {h.conserved.map((r) => (
            <button key={r.run_id} className="task" onClick={() => onOpen(r.run_id)}>
              <span className="task-title">{r.item}</span>
              <span className="run-meta">{r.label} · {r.fy}</span>
              <span className={`oc oc-${r.result}`}>{r.result}</span>
            </button>
          ))}
        </section>
      </div>
    </div>
  );
}

const QUADRANTS = ['Do now', 'Do later', 'Delegate', 'Delete'];

function Standalone({ h, reload }) {
  const blank = { entity_id: h.entities[0]?.entity_id || '', title: '', notes: '', due_date: '', quadrant: 'Do later' };
  const [f, setF] = useState(blank);
  const [adding, setAdding] = useState(false);
  const [msg, setMsg] = useState('');
  const open = h.standalone.filter((t) => t.status === 'Open');
  const go = async (fn) => { setMsg(''); try { await fn(); await reload(); } catch (e) { setMsg(e.message); } };
  return (
    <section className="dash-col" aria-label="Standalone">
      <h2>Standalone <span className="dash-count">{open.length}</span></h2>
      <p className="hint">Your own tasks; only you can mark them Done</p>
      {h.entities.length > 0 && !adding && <button className="quiet add-btn" onClick={() => { setF(blank); setAdding(true); }}>+ Standalone</button>}
      {adding && (
        <div className="mini-form">
          <label>Title<input value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></label>
          <label>Notes<textarea rows={2} value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} /></label>
          <div className="grid2">
            <label>Due date<input type="date" value={f.due_date} onChange={(e) => setF({ ...f, due_date: e.target.value })} /></label>
            <label>Quadrant<select value={f.quadrant} onChange={(e) => setF({ ...f, quadrant: e.target.value })}>{QUADRANTS.map((q) => <option key={q}>{q}</option>)}</select></label>
          </div>
          {h.entities.length > 1 && (
            <label>Entity<select value={f.entity_id} onChange={(e) => setF({ ...f, entity_id: e.target.value })}>
              {h.entities.map((e) => <option key={e.entity_id} value={e.entity_id}>{e.name}</option>)}</select></label>
          )}
          <div className="inline">
            <button className="primary" disabled={!f.title.trim()} onClick={() => go(() => api.createStandalone(f).then(() => setAdding(false)))}>Create</button>
            <button className="quiet" onClick={() => setAdding(false)}>Cancel</button>
          </div>
        </div>
      )}
      {open.length === 0 && !adding && <p className="hint">No open Standalone tasks.</p>}
      {open.map((t) => (
        <div key={t.task_id} className="task static">
          <span className="task-title">{t.title}</span>
          {t.notes && <span className="task-detail">{t.notes}</span>}
          <span className="run-meta">{t.entity_name}</span>
          <div className="inline">
            <select value={t.quadrant} aria-label="Quadrant"
              onChange={(e) => go(() => api.updateStandalone(t.task_id, { ...t, quadrant: e.target.value }))}>
              {QUADRANTS.map((q) => <option key={q}>{q}</option>)}
            </select>
            {t.due_date && <span className="due-ink">Due {t.due_date}</span>}
            <button className="primary" onClick={() => go(() => api.doneStandalone(t.task_id))}>Mark Done</button>
          </div>
        </div>
      ))}
      {msg && <p className="error" role="alert">{msg}</p>}
    </section>
  );
}
