import { useEffect, useState } from 'react';
import { api } from './api.js';

const STATUSES = ['All', 'Created', 'Learning and Training', 'Testing', 'Published'];
const NEXT = { Created: 'Learning and Training', 'Learning and Training': 'Testing', Testing: 'Published' };

export default function Console({ meta }) {
  const [c, setC] = useState(null);
  const [sel, setSel] = useState('');
  const [filter, setFilter] = useState('All');
  const [msg, setMsg] = useState('');
  const [adding, setAdding] = useState(false);

  const load = async (keep) => {
    const d = await api.console();
    setC(d);
    if (keep) setSel(keep);
    else if (!sel && d.kramas.length) setSel(d.kramas[0].krama_id);
  };
  useEffect(() => { load().catch((e) => setMsg(e.message)); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  async function act(fn) {
    setMsg('');
    try { const r = await fn(); await load(r?.krama_id); } catch (e) { setMsg(e.message); }
  }

  if (!c) return msg ? <p className="error">{msg}</p> : <p className="hint">Loading…</p>;
  const list = c.kramas.filter((k) => filter === 'All' || k.status === filter);
  const k = c.kramas.find((x) => x.krama_id === sel);

  return (
    <div className="runs">
      <div className="run-list">
        <div className="filter-tabs">
          {STATUSES.map((s) => <button key={s} className={filter === s ? 'tab on' : 'tab'} onClick={() => setFilter(s)}>{s}</button>)}
        </div>
        <button className="primary" onClick={() => setAdding(!adding)}>+ Add</button>
        {adding && <AddKrama c={c} meta={meta} onDone={async (r) => { setAdding(false); await load(r?.krama_id); }} />}
        {list.length === 0 && <p className="hint">No Kramas here.</p>}
        {list.map((x) => (
          <button key={x.krama_id} className={x.krama_id === sel ? 'run-card on' : 'run-card'} onClick={() => setSel(x.krama_id)}>
            <span className="run-title">{x.name} v{x.version}</span>
            <span className="run-meta">{x.owner_name || 'Platform'} · {x.pool_mark || x.ownership_type}</span>
            <span className="tag"><span className="st">{x.status}</span>{x.newer_platform_version && <span className="badge">Newer version available</span>}</span>
          </button>
        ))}
      </div>
      <div className="tree">
        {msg && <p className="error" role="alert">{msg}</p>}
        {k && <KramaDetail k={k} c={c} meta={meta} act={act} />}
      </div>
    </div>
  );
}

function AddKrama({ c, meta, onDone }) {
  const [mode, setMode] = useState('Create');
  const [f, setF] = useState({ code: '', name: '', owner_entity: c.is_super ? '' : (c.entities[0]?.entity_id || ''),
    ownership_type: 'Platform Built Entity Owned', tag_kind: 'Business', tag_domain: '' });
  const [imp, setImp] = useState({ krama_id: c.importable[0]?.krama_id || '', entity_id: c.entities[0]?.entity_id || '' });
  const [msg, setMsg] = useState('');
  const set = (k, v) => setF((x) => ({ ...x, [k]: v }));
  const go = async (fn) => { setMsg(''); try { onDone(await fn()); } catch (e) { setMsg(e.message); } };
  return (
    <div className="mini-form">
      <div className="inline">
        <button className={mode === 'Create' ? 'tab on' : 'tab'} onClick={() => setMode('Create')}>Create</button>
        {c.entities.length > 0 && <button className={mode === 'Platform built' ? 'tab on' : 'tab'} onClick={() => setMode('Platform built')}>Platform built</button>}
      </div>
      {mode === 'Create' ? (
        <>
          <label>Name<input value={f.name} onChange={(e) => set('name', e.target.value)} /></label>
          <label>Krama ID<input value={f.code} onChange={(e) => set('code', e.target.value)} /></label>
          <label>Built for
            <select value={f.owner_entity} onChange={(e) => set('owner_entity', e.target.value)}>
              {c.is_super && <option value="">Platform</option>}
              {c.entities.map((e) => <option key={e.entity_id} value={e.entity_id}>{e.name}</option>)}
            </select>
          </label>
          {!f.owner_entity && (
            <label>Ownership type
              <select value={f.ownership_type} onChange={(e) => set('ownership_type', e.target.value)}>
                <option>Platform Built Entity Owned</option><option>Platform Built Platform Owned</option>
              </select>
            </label>
          )}
          <label>Business or Compliance<select value={f.tag_kind} onChange={(e) => set('tag_kind', e.target.value)}><option>Business</option><option>Compliance</option></select></label>
          <label>Module<ModulePick value={f.tag_domain} onChange={(v) => set('tag_domain', v)} isSuper={c.is_super} /></label>
          <button className="primary" disabled={!f.name.trim() || !f.code.trim()}
            onClick={() => go(() => api.create('krama', { ...f, owner_entity: f.owner_entity || null }))}>Create</button>
        </>
      ) : (
        <>
          <label>Platform Krama
            <select value={imp.krama_id} onChange={(e) => setImp({ ...imp, krama_id: e.target.value })}>
              {c.importable.map((k) => <option key={k.krama_id} value={k.krama_id}>{k.name} v{k.version}</option>)}
            </select>
          </label>
          <label>Into the pool of
            <select value={imp.entity_id} onChange={(e) => setImp({ ...imp, entity_id: e.target.value })}>
              {c.entities.map((e) => <option key={e.entity_id} value={e.entity_id}>{e.name}</option>)}
            </select>
          </label>
          <button className="primary" disabled={!imp.krama_id} onClick={() => go(() => api.importKrama(imp.krama_id, imp.entity_id))}>Import</button>
        </>
      )}
      {msg && <p className="error" role="alert">{msg}</p>}
    </div>
  );
}

function KramaDetail({ k, c, meta, act }) {
  const [ctx, setCtx] = useState(null);
  const loadCtx = () => api.do('krama_context', { krama_id: k.krama_id }).then(setCtx).catch(() => {});
  useEffect(() => { loadCtx(); }, [k.krama_id]); // eslint-disable-line react-hooks/exhaustive-deps
  const editable = k.can_design && k.status !== 'Published';
  const allQuestions = k.stages.flatMap((s) => s.topics.flatMap((t) => t.questions));
  return (
    <div className="panel">
      <div className="run-head">
        <div>
          <h2>{k.name} <span className="run-meta">Krama ID {k.code} · v{k.version}</span></h2>
          <p className="run-meta">{k.owner_name || 'Platform'} · {k.ownership_type}{k.pool_mark ? ` · ${k.pool_mark}` : ''} · {[k.tag_kind, k.tag_domain, k.external ? 'External room' : 'Internal only'].filter(Boolean).join(' / ')}</p>
          <p className="tag"><span className="st">{k.status}</span></p>
          {k.newer_platform_version && <p className="badge">Newer version available on the platform (v{k.newer_platform_version})</p>}
          {k.what_changed && <p className="hint">What changed: {k.what_changed}</p>}
        </div>
        {k.can_design && (
          <div className="inline">
            {NEXT[k.status] && <button className="primary" onClick={() => act(() => api.setStatus(k.krama_id, NEXT[k.status]))}>Move to {NEXT[k.status]}</button>}
            {k.status === 'Published' && !k.has_next_version && (
              <button className="quiet" onClick={() => { const w = window.prompt('What will change in the new version?'); if (w !== null) act(() => api.newVersion(k.krama_id, w)); }}>New version</button>
            )}
          </div>
        )}
      </div>
      {k.status === 'Published' && <p className="note">Published Kramas are frozen. Use New version to change it; running work keeps this version.</p>}

      <Rows title="Rooms" items={k.rooms} editable={editable} act={act} entity="room-template"
        render={(r) => <><span className={`room-icon room-${r.kind}`}>{r.kind}</span> {r.label}</>}
        id="room_template_id" add={{ krama_id: k.krama_id }} fields={[['kind', 'Kind', meta.entities ? ['PR', 'IR', 'ER'] : []], ['label', 'Name']]} />

      <div className="section">
        <h4>Stages, topics and questions</h4>
        {k.stages.map((s) => (
          <div key={s.stage_id} className="node open">
            <EditRow entity="stage" row={s} id="stage_id" editable={editable} act={act}
              fields={[['name', 'Stage'], ['seq', 'Order', null, 'number'], ['path', 'Path', ['PR only', 'PR → IR', 'PR → IR → ER']]]} kind="Stage" />
            <div className="node-body">
              {s.expertise.length > 0 && <p className="hint">Expertise: {s.expertise.map((e) => `${e.name} (${e.mapped_as})`).join(', ')}</p>}
              {ctx && <StageContext s={s} ctx={ctx} editable={editable} onDone={loadCtx} />}
              <Caps where={{ stage_id: s.stage_id }} boundary="stage" list={s.capabilities} k={k} editable={editable} act={act} />
              {s.topics.map((t) => (
                <div key={t.topic_id} className="topic-block">
                  <EditRow entity="topic" row={t} id="topic_id" editable={editable} act={act}
                    fields={[['name', 'Topic'], ['seq', 'Order', null, 'number'], ['path', 'Path', ['PR only', 'PR → IR', 'PR → IR → ER']],
                      ['is_output', 'Output document', ['false', 'true']]]} kind="Topic" />
                  {t.is_output && <p className="hint">Output document: built from this topic's agreed answers.</p>}
                  {ctx && <DomainPick level="topic" id={t.topic_id} value={ctx.topics[t.topic_id]} ctx={ctx} editable={editable} onDone={loadCtx} label="Domain profile for this topic" />}
                  <Caps where={{ topic_id: t.topic_id }} boundary="topic" list={t.capabilities} k={k} editable={editable} act={act} />
                  {t.questions.map((q) => (
                    <div key={q.question_id} className="question">
                      <EditRow entity="question" row={q} id="question_id" editable={editable} act={act} kind="Question"
                        fields={[['text', 'Question'], ['seq', 'Order', null, 'number'], ['flow_option', 'Flow option', ['Decision', 'Input field', 'Choice list', 'Checklist', 'File drop', 'Assign', 'Table grid', 'Compare box', 'Finding control', 'Signature panel']],
                          ['ask_in', 'Asked in', ['PR', 'IR', 'ER']], ['due_days', 'Due in (days)', null, 'number'], ['rules', 'Rules', null, 'long'],
                          ['setup_options', 'Options, one per line', null, 'long', (v) => ['Choice list', 'Checklist'].includes(v.flow_option)],
                          ['setup_multi', 'Pick many', ['false', 'true'], null, (v) => v.flow_option === 'Choice list'],
                          ['setup_choices', 'Choices for each item, one per line', null, 'long', (v) => v.flow_option === 'Checklist'],
                          ['setup_columns', 'Columns, one per line', null, 'long', (v) => v.flow_option === 'Table grid'],
                          ['setup_limit', 'Allowed difference', null, 'number', (v) => v.flow_option === 'Compare box'],
                          ['also_needs', 'Also needs', ['', 'File drop', 'Finding control'], null,
                            (v) => ['Decision', 'Input field', 'Checklist', 'Table grid', 'Compare box'].includes(v.flow_option)]]} />
                      <Links q={q} all={allQuestions} editable={editable} act={act} />
                      {ctx && <DomainPick level="question" id={q.question_id} value={ctx.questions[q.question_id]} ctx={ctx} editable={editable} onDone={loadCtx} label="Domain profile for this question" />}
                      <Caps where={{ question_id: q.question_id }} boundary="question" list={q.capabilities} k={k} editable={editable} act={act} />
                    </div>
                  ))}
                  {editable && <AddButton label="Add question" act={act} entity="question" body={{ topic_id: t.topic_id, text: 'New question', seq: t.questions.length + 1, flow_option: 'Decision', ask_in: 'PR', due_days: 7 }} />}
                </div>
              ))}
              {editable && <AddButton label="Add topic" act={act} entity="topic" body={{ stage_id: s.stage_id, name: 'New topic', seq: s.topics.length + 1, path: 'PR only' }} />}
            </div>
          </div>
        ))}
        {editable && <AddButton label="Add stage" act={act} entity="stage" body={{ krama_id: k.krama_id, name: 'New stage', seq: k.stages.length + 1, path: 'PR only' }} />}
      </div>

      <div className="section">
        <h4>Relationship matrix</h4>
        {k.relationships.length === 0 && <p className="hint">{k.external ? 'Not mapped yet: no counterparty persona type will get this Krama.' : 'Internal Krama: runs under Department or Business Unit.'}</p>}
        {k.relationships.map((m) => (
          <div key={m.id} className="item"><span>{m.relationship}</span><span className="hint">{m.party_type} · {m.persona}{m.inherited ? ' (from the platform Krama)' : ''}</span></div>
        ))}
        <p className="hint">Maintained by the platform super-user under Krama design → Relationship matrix.</p>
      </div>

      <Rows title="Report and Analytics" items={k.reports} editable={editable} act={act} entity="report"
        render={(r) => <><strong>{r.name}</strong> <span className="hint">{r.question_text}</span></>}
        id="report_id" add={{ krama_id: k.krama_id }} fields={[['name', 'Name'], ['question_text', 'What it answers']]} />
    </div>
  );
}

function Rows({ title, items, editable, act, entity, render, id, add, fields }) {
  const blank = Object.fromEntries(fields.map(([n, , opts]) => [n, opts && opts.length ? opts[0] : '']));
  const [f, setF] = useState(blank);
  return (
    <div className="section">
      <h4>{title}</h4>
      {items.length === 0 && <p className="hint">None yet.</p>}
      {items.map((r) => (
        <div key={r[id]} className="item">{render(r)}
          {editable && <button className="danger" onClick={() => act(() => api.remove(entity, r[id]))}>Remove</button>}
        </div>
      ))}
      {editable && (
        <div className="inline">
          {fields.map(([n, label, opts]) => opts && opts.length
            ? <select key={n} value={f[n]} onChange={(e) => setF({ ...f, [n]: e.target.value })} aria-label={label}>{opts.map((o) => <option key={o}>{o}</option>)}</select>
            : <input key={n} value={f[n]} placeholder={label} onChange={(e) => setF({ ...f, [n]: e.target.value })} aria-label={label} />)}
          <button className="quiet" disabled={fields.some(([n]) => !String(f[n]).trim())}
            onClick={() => act(() => api.create(entity, { ...add, ...f }).then(() => setF(blank)))}>Add</button>
        </div>
      )}
    </div>
  );
}

function EditRow({ entity, row, id, editable, act, fields, kind }) {
  const [v, setV] = useState(Object.fromEntries(fields.map(([n]) => [n, typeof row[n] === 'boolean' ? String(row[n]) : (row[n] ?? '')])));
  const [open, setOpen] = useState(false);
  const label = row[fields[0][0]];
  const summary = fields.slice(1).filter(([, , , t]) => t !== 'long').map(([n]) => row[n]).filter((x) => x !== null && x !== '').join(' · ');
  return (
    <div>
      <button className="node-head" onClick={() => setOpen(!open)} aria-expanded={open}>
        <span className="kind">{kind}</span><span className="title">{label}</span><span className="run-meta">{summary}</span>
      </button>
      {open && (
        <div className="mini-form">
          {row.rules && !editable && <p className="hint">Rules: {row.rules}</p>}
          <div className="grid2">
            {fields.filter(([, , , , show]) => !show || show(v)).map(([n, l, opts, type]) => (
              <label key={n}>{l}
                {opts ? <select disabled={!editable} value={v[n]} onChange={(e) => setV({ ...v, [n]: e.target.value })}>{opts.map((o) => <option key={o}>{o}</option>)}</select>
                  : type === 'long' ? <textarea disabled={!editable} rows={2} value={v[n]} onChange={(e) => setV({ ...v, [n]: e.target.value })} />
                    : <input disabled={!editable} type={type === 'number' ? 'number' : 'text'} value={v[n]} onChange={(e) => setV({ ...v, [n]: e.target.value })} />}
              </label>
            ))}
          </div>
          {editable && (
            <div className="inline">
              <button className="primary" onClick={() => act(() => api.update(entity, row[id], Object.fromEntries(Object.entries(v).map(([k, x]) =>
                [k, x === 'true' ? true : x === 'false' ? false : x === '' && k !== 'rules' ? null : x]))))}>Save</button>
              <button className="danger" onClick={() => act(() => api.remove(entity, row[id]))}>Delete</button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function Links({ q, all, editable, act }) {
  const [pick, setPick] = useState('');
  const others = all.filter((x) => x.question_id !== q.question_id && !q.links.some((l) => l.predecessor_id === x.question_id));
  if (!editable && q.links.length === 0) return null;
  return (
    <div className="inline links">
      <span className="hint">Waits for:</span>
      {q.links.length === 0 && <span className="hint">nothing (runs concurrently)</span>}
      {q.links.map((l) => <span key={l.predecessor_id} className="badge">{l.text}</span>)}
      {editable && others.length > 0 && (
        <>
          <select value={pick} onChange={(e) => setPick(e.target.value)} aria-label="Add a predecessor">
            <option value="">Add…</option>
            {others.map((x) => <option key={x.question_id} value={x.question_id}>{x.text}</option>)}
          </select>
          <button className="quiet" disabled={!pick} onClick={() => act(() => api.create('question-link', { question_id: q.question_id, predecessor_id: pick }).then(() => setPick('')))}>Link</button>
        </>
      )}
    </div>
  );
}

function AddButton({ label, act, entity, body }) {
  return <button className="quiet add-btn" onClick={() => act(() => api.create(entity, body))}>{label}</button>;
}

// Capabilities applied at a stage, topic or question; the picker lists only those allowed at that boundary
let CAPS = null;
function Caps({ where, boundary, list, k, editable, act }) {
  const [all, setAll] = useState(CAPS || []);
  const [pick, setPick] = useState('');
  useEffect(() => { if (!CAPS) api.capabilities().then((c) => { CAPS = c; setAll(c); }).catch(() => {}); }, []);
  const allowed = all.filter((c) => c.boundaries.includes(boundary) && !list.some((u) => u.code === c.code));
  if (!editable && list.length === 0) return null;
  return (
    <div className="caps">
      {list.map((u) => (
        <span key={u.use_id} className="cap-chip" title={all.find((c) => c.code === u.code)?.what || ''}>
          {u.name}{editable && <button className="plink muted" aria-label={`Remove ${u.name}`} onClick={() => act(() => api.removeCapability(u.use_id))}>×</button>}
        </span>
      ))}
      {editable && (
        <span className="inline">
          <select value={pick} onChange={(e) => setPick(e.target.value)} aria-label={`Capability for this ${boundary}`}>
            <option value="">+ Capability…</option>{allowed.map((c) => <option key={c.code} value={c.code}>{c.name} — {c.what}</option>)}
          </select>
          {pick && <button className="quiet" onClick={() => act(() => api.addCapability(k.krama_id, { code: pick, ...where })).then(() => setPick(''))}>Apply</button>}
        </span>
      )}
    </div>
  );
}

// A stage names its domain profile and, per seat, the person persona needed (expertise and skills)
function DomainPick({ level, id, value, ctx, editable, onDone, label }) {
  const [msg, setMsg] = useState('');
  const name = ctx.domains.find((d) => d.domain_id === value)?.name;
  if (!editable && !value) return null;
  return (
    <div className="inline ctx-row">
      <span className="hint">{label}:</span>
      {editable
        ? <select value={value || ''} onChange={async (e) => { setMsg(''); try { await api.do('set_context', { level, id, domain_id: e.target.value }); onDone(); } catch (x) { setMsg(x.message); } }}>
            <option value="">{level === 'stage' ? 'None' : 'Same as above'}</option>{ctx.domains.map((d) => <option key={d.domain_id} value={d.domain_id}>{d.name}</option>)}</select>
        : <span className="hint">{name}</span>}
      {msg && <span className="error">{msg}</span>}
    </div>
  );
}
function StageContext({ s, ctx, editable, onDone }) {
  const sc = ctx.stages[s.stage_id] || {};
  const [open, setOpen] = useState(null);
  const [f, setF] = useState({ expertise_ids: [], skills: '' });
  const [msg, setMsg] = useState('');
  const needs = sc.needs || {};
  const xname = (id) => ctx.expertise.find((x) => x.expertise_id === id)?.name || '';
  return (
    <div className="ctx-box">
      <DomainPick level="stage" id={s.stage_id} value={sc.domain_id} ctx={ctx} editable={editable} onDone={onDone} label="Domain profile" />
      <p className="hint">Person persona needed: {['Doer', 'Reviewer', 'Approver'].map((seat) => {
        const n = needs[seat];
        const txt = n ? [...(n.expertise_ids || []).map(xname), ...(n.skills || [])].join(', ') : 'any';
        return <span key={seat}> {seat}: {txt}{editable && <button className="link-btn" onClick={() => { setOpen(seat); setF({ expertise_ids: n?.expertise_ids || [], skills: (n?.skills || []).join('\n') }); }}>Edit</button>} ·</span>;
      })}</p>
      {open && (
        <div className="mini-form">
          <p className="hint">{open}: areas of expertise and skills the person should have (a mismatch is flagged, not blocked)</p>
          <div className="inline">{ctx.expertise.map((x) => (
            <label key={x.expertise_id} className="check"><input type="checkbox" checked={f.expertise_ids.includes(x.expertise_id)}
              onChange={() => setF({ ...f, expertise_ids: f.expertise_ids.includes(x.expertise_id) ? f.expertise_ids.filter((y) => y !== x.expertise_id) : [...f.expertise_ids, x.expertise_id] })} />{x.name}</label>))}</div>
          <textarea rows={2} placeholder="Skills, one per line" value={f.skills} onChange={(e) => setF({ ...f, skills: e.target.value })} />
          <div className="inline">
            <button className="primary" onClick={async () => { setMsg(''); try { await api.do('set_seat_need', { stage_id: s.stage_id, seat: open, ...f }); setOpen(null); onDone(); } catch (x) { setMsg(x.message); } }}>Save</button>
            <button className="quiet" onClick={() => setOpen(null)}>Cancel</button>
          </div>
          {msg && <p className="error">{msg}</p>}
        </div>
      )}
    </div>
  );
}

// Module: picked from the defined list; the platform super-user can add to the list
function ModulePick({ value, onChange, isSuper }) {
  const [list, setList] = useState([]);
  const [adding, setAdding] = useState('');
  const [msg, setMsg] = useState('');
  useEffect(() => { api.do('krama_modules', {}).then(setList).catch(() => {}); }, []);
  const note = list.find((m) => m.name === value)?.note;
  return (
    <span className="module-pick">
      <select value={value || ''} onChange={(e) => onChange(e.target.value)}>
        <option value="">None</option>{list.map((m) => <option key={m.name} value={m.name}>{m.name}</option>)}
      </select>
      {note && <span className="hint"> {note}</span>}
      {isSuper && <span className="inline">
        <input placeholder="New module" value={adding} onChange={(e) => setAdding(e.target.value)} />
        <button type="button" className="quiet" disabled={!adding.trim()} onClick={async () => { setMsg(''); try { setList(await api.do('krama_modules', { add: adding.trim() })); onChange(adding.trim()); setAdding(''); } catch (x) { setMsg(x.message); } }}>Add</button>
      </span>}
      {msg && <span className="error">{msg}</span>}
    </span>
  );
}
