import { useEffect, useState } from 'react';
import { api } from './api.js';
import TaskContext, { TaskControls } from './TaskContext.jsx';
import { Question, Seats, PersonSelect } from './Runs.jsx';
import Icon from './Icon.jsx';

const ORDER = { 'Do now': 1, 'Do later': 2, Delegate: 3, Delete: 4 };
const KIND_RANK = { PR: 1, IR: 2, ER: 3 };
const PATH_RANK = { 'PR only': 1, 'PR → IR': 2, 'PR → IR → ER': 3 };

// Task detail (workflow lane), shaped like the Figma "task detail / workflow" and "topic" screens
export default function TaskDetail({ runId, focusQr, companies, meta, onBack, onAudit }) {
  const [tree, setTree] = useState(null);
  const [msg, setMsg] = useState('');
  const [tab, setTab] = useState('Topics');
  const [space, setSpace] = useState('internal');
  const [roomId, setRoomId] = useState(null);
  const [roomTab, setRoomTab] = useState('Topics');
  const [topicId, setTopicId] = useState(null);
  const [roomData, setRoomData] = useState(null);
  const [adding, setAdding] = useState(false);

  const load = async () => {
    try { const t = await api.run(runId); setTree(t); setMsg(''); return t; } catch (e) { setMsg(e.message); return null; }
  };
  const loadRoom = async (id = roomId) => {
    if (!id) return;
    try { setRoomData(await api.room(id)); } catch { setRoomData(null); }
  };
  useEffect(() => { load(); }, [runId]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (!tree) return;
    if (!roomId) {
      const first = tree.rooms.find((r) => (r.member || tree.is_super) && r.kind === 'PR') || tree.rooms.find((r) => r.member || tree.is_super);
      if (first) { setRoomId(first.room_id); setSpace(first.kind === 'ER' ? 'external' : 'internal'); }
    }
    if (focusQr) {
      for (const s of tree.stages) for (const t of s.topics) for (const q of t.questions) {
        if (q.qr_id === focusQr && q.room_id) { setRoomId(q.room_id); setSpace(q.ask_in === 'ER' ? 'external' : 'internal'); setTopicId(t.topic_id); }
      }
    }
  }, [tree]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { loadRoom(); }, [roomId]); // eslint-disable-line react-hooks/exhaustive-deps

  if (msg) return <div className="page"><button className="back-btn" onClick={onBack}><Icon name="back" size={14} /></button><p className="error">{msg}</p></div>;
  if (!tree) return <div className="page"><p className="sub">Loading…</p></div>;

  const reload = async () => { await load(); await loadRoom(); };
  const visibleRooms = tree.rooms.filter((r) => r.member || tree.is_super || r.can_grant);
  const internalRooms = visibleRooms.filter((r) => r.kind !== 'ER');
  const externalRooms = visibleRooms.filter((r) => r.kind === 'ER');
  const room = tree.rooms.find((r) => r.room_id === roomId);
  const retains = (t) => room && room.topics.includes(t.topic_id);
  const inRoom = (t, q) => room && (q.room_id === room.room_id || (q.state === 'Agreed' && retains(t)));

  const rows = room ? tree.stages.flatMap((s) => s.topics.filter((t) => retains(t)).map((t) => ({ s, t, qs: t.questions.filter((q) => inRoom(t, q)) }))) : [];
  const notRetained = room ? tree.stages.flatMap((s) => s.topics.filter((t) => !retains(t) && KIND_RANK[room.kind] <= PATH_RANK[t.path]).map((t) => ({ s, t }))) : [];
  const all = tree.stages.flatMap((s) => s.topics.flatMap((t) => t.questions.map((q) => ({ s, t, q }))));
  // tally: a topic retained in more than one room of the same kind
  const doubled = room ? rows.filter(({ t }) => tree.rooms.filter((r) => r.kind === room.kind && r.topics.includes(t.topic_id)).length > 1).map(({ t }) => t.name) : [];

  const topicRow = topicId && room && rows.find((r) => r.t.topic_id === topicId);
  const sub = [tree.label, tree.relationship, tree.counterparty_name, tree.fy].filter(Boolean).join(' · ');
  const roomLabel = (r) => (r.kind === 'PR' ? 'Private' : `Shared · ${r.kind === 'ER' ? (r.name || r.with_name) : r.name}`);
  const pickRoom = (r) => { setRoomId(r.room_id); setTopicId(null); setRoomTab('Topics'); };
  const blocked = room && room.permission === 'Requested';
  const act = async (fn) => { setMsg(''); try { await fn(); await reload(); } catch (e) { alert(e.message); } };

  return (
    <div className="page wide">
      <button className="back-btn" onClick={topicRow ? () => setTopicId(null) : onBack}><Icon name="back" size={14} /></button>
      <div className="card head-card">
        <div>
          <h1 className="serif">{tree.item}</h1>
          <p className="sub">{sub} · {tree.krama} v{tree.version} · Collaborative · workflow</p>
          <p className="sub">{tree.locked ? `Conserved · ${tree.result}` : tree.status}{tree.result && !tree.locked ? ` · ${tree.result}` : ''}</p>
          <TaskContext runId={tree.run_id} />
          <TaskControls runId={tree.run_id} onDone={reload} />
        </div>
        <div className="head-actions">
          <span className="badge-coral">Collaborative · workflow</span>
          {(tree.is_requestor || tree.is_super) && <button className="quiet" onClick={() => onAudit(tree.run_id)}>History and audit</button>}
          {tree.is_requestor && tree.locked && <button className="primary" onClick={() => act(() => api.amend(tree.run_id))}>Amend</button>}
        </div>
      </div>

      <div className={room && space !== 'setup' && !blocked ? 'room-layout' : ''}>
        <div>
          {topicRow ? (
            <TopicView row={topicRow} tree={tree} room={room} meta={meta} onDone={reload} focusQr={focusQr} />
          ) : (
            <>
              <div className="seg">
                {['Topics', 'Decision', 'Agreed', 'Reports', 'Files'].map((x) => <button key={x} className={x === tab ? 'seg-btn on' : 'seg-btn'} onClick={() => setTab(x)}>{x}</button>)}
              </div>

              {tab === 'Topics' && (
                <div className="card">
                  <div className="row-between">
                    <h3 className="serif">Task Access &amp; Workspace</h3>
                    {tree.is_requestor && !tree.locked && <button className="quiet" onClick={() => setAdding(!adding)}>+ Room</button>}
                  </div>
                  {adding && <AddRoom tree={tree} companies={companies} onDone={async (id) => { setAdding(false); await load(); if (id) pickRoom({ room_id: id }); }} />}
                  <div className="underline-tabs">
                    {[['setup', 'Setting up'], ['internal', 'Internal space'], ['external', 'External space']].map(([k, l]) => (
                      <button key={k} className={space === k ? 'u-tab on' : 'u-tab'}
                        onClick={() => { setSpace(k); const list = k === 'internal' ? internalRooms : k === 'external' ? externalRooms : []; if (list[0]) pickRoom(list[0]); }}>{l}</button>
                    ))}
                  </div>
                  {space === 'setup' ? (
                    <Seats tree={tree} meta={meta} onDone={reload} />
                  ) : (
                    <>
                      <div className="room-row">
                        {(space === 'internal' ? internalRooms : externalRooms).map((r) => (
                          <button key={r.room_id} className={r.room_id === roomId ? 'room-btn on' : 'room-btn'} onClick={() => pickRoom(r)}>
                            {roomLabel(r)}{r.parent_room_id ? ' · child' : ''}{r.permission === 'Requested' ? ' · awaiting permission' : ''}
                          </button>
                        ))}
                        {space === 'external' && externalRooms.length === 0 && <p className="sub">This task has no external space for you.</p>}
                      </div>
                      {room && (
                        <>
                          <p className="sub">
                            {room.with_name ? `With ${room.with_name}. ` : ''}{room.parent_name ? `Child of ${room.parent_name}. ` : ''}
                            In this room: {room.members.map((m) => m.name + (m.spoc ? ' (SPOC)' : '')).join(', ') || 'nobody yet'}
                          </p>
                          {blocked ? (
                            <div className="note-box">
                              <p>This child room waits for permission from the other party in {room.parent_name}.</p>
                              {room.can_grant && <button className="primary" onClick={() => act(() => api.roomAct(room.room_id, 'grant'))}>Give permission</button>}
                            </div>
                          ) : (
                            <>
                              <div className="chips">
                                {['Topics', 'Registry', 'Members'].map((x) => <button key={x} className={x === roomTab ? 'chip on' : 'chip'} onClick={() => setRoomTab(x)}>{x}</button>)}
                              </div>
                              {roomTab === 'Topics' && (
                                <>
                                  {doubled.length > 0 && <p className="ink small">Tally: {doubled.join(', ')} also sit in another {room.kind} room. Delete each from one room so every topic sits in one {room.kind} room.</p>}
                                  <table className="ftable">
                                    <thead><tr><th>Stage</th><th>Topic</th><th>Open</th><th>Dependency</th><th>Status</th><th>Priority</th>{tree.is_requestor && !tree.locked && <th />}</tr></thead>
                                    <tbody>
                                      {rows.map(({ s, t, qs }) => {
                                        const waits = qs.flatMap((q) => q.waits_for);
                                        const top = qs.filter((q) => q.status === 'Open').sort((a, b) => ORDER[a.quadrant] - ORDER[b.quadrant])[0];
                                        return (
                                          <tr key={t.topic_id} onClick={() => setTopicId(t.topic_id)}>
                                            <td><span className="ink">{s.name}</span><br /><span className="sub">{s.path}</span></td>
                                            <td className="strong serif">{t.name}<br /><span className="sub">{qs.length} question{qs.length === 1 ? '' : 's'} here</span></td>
                                            <td>{qs.filter((q) => q.status === 'Open').length}</td>
                                            <td>{waits.length ? <span className="ink">Waits for {waits.join(', ')}</span> : 'No dependency'}</td>
                                            <td>{t.status}</td>
                                            <td><span className={top?.quadrant === 'Do now' ? 'dot ink' : 'dot'}>{top ? `• ${top.quadrant}` : '-'}</span></td>
                                            {tree.is_requestor && !tree.locked && room.kind !== 'PR' && (
                                              <td><button className="plink muted" onClick={(e) => { e.stopPropagation(); act(() => api.roomAct(room.room_id, 'topics', { topic_id: t.topic_id, retain: false })); }}>Delete from room</button></td>
                                            )}
                                          </tr>
                                        );
                                      })}
                                      {rows.length === 0 && <tr><td colSpan={7} className="sub">No topics in this room.</td></tr>}
                                    </tbody>
                                  </table>
                                  {(tree.split || []).filter((g) => g.room_id === room.room_id).map((g) => (
                                    <div key={g.source_qr} className="reg-block">
                                      <h4 className="serif">Called in: {g.question}</h4>
                                      <table className="ans-table"><tbody>
                                        {g.lines.map((l) => (
                                          <tr key={l.line_id}><td>{l.text}</td><td className={l.state === 'Agreed' ? 'sub' : 'ink'}>{l.state}{l.note ? ` — ${l.note}` : ''}</td>
                                            <td>{l.state !== 'Agreed' && room.member && <button className="plink ink" onClick={() => { const n = window.prompt('How was it settled?') || ''; act(() => api.settleLine(l.line_id, n)); }}>Settle as Agreed</button>}</td></tr>
                                        ))}
                                      </tbody></table>
                                    </div>
                                  ))}
                                  {tree.is_requestor && !tree.locked && notRetained.length > 0 && (
                                    <div className="inline small">
                                      <span className="sub">Deleted from this room:</span>
                                      {notRetained.map(({ t }) => (
                                        <button key={t.topic_id} className="plink ink" onClick={() => act(() => api.roomAct(room.room_id, 'topics', { topic_id: t.topic_id, retain: true }))}>Retain {t.name}</button>
                                      ))}
                                    </div>
                                  )}
                                </>
                              )}
                              {roomTab === 'Registry' && <Registry data={roomData} tree={tree} onDone={loadRoom} />}
                              {roomTab === 'Members' && <Members room={room} tree={tree} onDone={reload} />}
                            </>
                          )}
                        </>
                      )}
                    </>
                  )}
                </div>
              )}

              {tab === 'Decision' && (
                <div className="card">
                  <h3 className="serif">Waiting for a decision</h3>
                  {all.filter(({ q }) => q.state === 'Submitted').map(({ s, t, q }) => (
                    <button key={q.qr_id} className="list-row" onClick={() => { if (q.room_id) setRoomId(q.room_id); setSpace(q.ask_in === 'ER' ? 'external' : 'internal'); setTab('Topics'); setTopicId(t.topic_id); }}>
                      <span className="strong">{q.text}</span><span className="sub">{s.name} · {t.name} · {q.ask_in}</span><span className="pill">Submitted</span>
                    </button>
                  ))}
                  {all.every(({ q }) => q.state !== 'Submitted') && <p className="sub">Nothing is waiting for a decision.</p>}
                </div>
              )}

              {tab === 'Agreed' && (
                <div className="card">
                  <h3 className="serif">Agreed</h3>
                  {all.filter(({ q }) => q.state === 'Agreed').map(({ t, q }) => (
                    <div key={q.qr_id} className="list-row static"><span className="strong">{q.text}</span><span className="sub">{t.name}</span><span>{q.answer}</span></div>
                  ))}
                  {all.every(({ q }) => q.state !== 'Agreed') && <p className="sub">Nothing agreed yet.</p>}
                </div>
              )}

              {tab === 'Reports' && <Reports tree={tree} companies={companies} act={act} />}

              {tab === 'Files' && <div className="card empty-card"><p>Files are in the Figma, but not part of the demo. Files attached in answers show in each room's Registry.</p></div>}
            </>
          )}
        </div>
        {room && space !== 'setup' && !blocked && roomData && (
          <Chat data={roomData} room={room} tree={tree} onDone={loadRoom} />
        )}
      </div>
    </div>
  );
}

export function AddRoom({ tree, companies, onDone }) {
  const hasER = tree.rooms.some((r) => r.kind === 'ER');
  const [f, setF] = useState({ kind: 'IR', name: '', with_entity: '', parent_room_id: '' });
  const [msg, setMsg] = useState('');
  const ers = tree.rooms.filter((r) => r.kind === 'ER');
  return (
    <div className="mini-form">
      <div className="inline">
        <select value={f.kind} onChange={(e) => setF({ ...f, kind: e.target.value })} aria-label="Kind">
          <option value="IR">Internal room</option>{hasER && <option value="ER">External room</option>}
        </select>
        <input placeholder="Room name" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} aria-label="Room name" />
        {f.kind === 'ER' && (
          <>
            <select value={f.with_entity} onChange={(e) => setF({ ...f, with_entity: e.target.value })} aria-label="With">
              <option value="">With {tree.counterparty_name || 'the counterparty'}</option>
              {companies.filter((c) => c.user_id !== tree.counterparty).map((c) => <option key={c.user_id} value={c.user_id}>With {c.name}</option>)}
            </select>
            <select value={f.parent_room_id} onChange={(e) => setF({ ...f, parent_room_id: e.target.value })} aria-label="Child of">
              <option value="">Not a child room</option>{ers.map((r) => <option key={r.room_id} value={r.room_id}>Child of {r.name}</option>)}
            </select>
          </>
        )}
        <button className="primary" disabled={!f.name.trim()} onClick={async () => {
          setMsg('');
          try { const r = await api.addRoom(tree.run_id, { ...f, with_entity: f.with_entity || null, parent_room_id: f.parent_room_id || null }); onDone(r.room_id); } catch (e) { setMsg(e.message); }
        }}>Add room</button>
      </div>
      {f.parent_room_id && <p className="sub">A child room opens once the other party in its parent room gives permission.</p>}
      {msg && <p className="error">{msg}</p>}
    </div>
  );
}

export function Members({ room, tree, onDone }) {
  const [p, setP] = useState('');
  const [spoc, setSpoc] = useState(false);
  const [msg, setMsg] = useState('');
  return (
    <div>
      {room.members.map((m) => <p key={m.name}>{m.name}{m.spoc ? <span className="sub"> · SPOC</span> : ''}</p>)}
      {tree.is_requestor && !tree.locked && (
        <div className="inline">
          <PersonSelect value={p} onChange={setP} options={room.candidates} placeholder="Add a person…"
            empty={room.kind === 'ER' ? 'Everyone here is already in this room' : "All of this entity's people are already in this room"} />
          <label className="check"><input type="checkbox" checked={spoc} onChange={(e) => setSpoc(e.target.checked)} />SPOC</label>
          <button className="quiet" disabled={!p} onClick={async () => { setMsg(''); try { await api.roomAct(room.room_id, 'members', { person_id: p, spoc }); setP(''); onDone(); } catch (e) { setMsg(e.message); } }}>Add</button>
        </div>
      )}
      {msg && <p className="error">{msg}</p>}
    </div>
  );
}

export function Registry({ data, tree, onDone }) {
  const [f, setF] = useState({ kind: 'Event', title: '', on_date: '', stage_id: '', status: 'Open' });
  const [nr, setNr] = useState({ name: '', description: '', holds: 'Both' });
  const [msg, setMsg] = useState('');
  if (!data) return <p className="sub">Loading…</p>;
  const go = async (fn) => { setMsg(''); try { await fn(); await onDone(); } catch (e) { setMsg(e.message); } };
  return (
    <div className="registry">
      {data.registries.map((g) => (
        <div key={g.registry_id} className="reg-block">
          <h4 className="serif">{g.name} <span className="sub">· holds {g.holds.toLowerCase()}</span></h4>
          {g.description && <p className="sub">{g.description}</p>}
          <table className="ans-table">
            <thead><tr><th>Entry</th><th>Kind</th><th>Date</th><th>Stage</th><th>Status</th><th>Source of truth</th></tr></thead>
            <tbody>
              {g.entries.map((e) => (
                <tr key={e.entry_id}><td>{e.title}</td><td>{e.kind}</td><td>{e.on_date || '—'}</td><td>{e.stage || '—'}</td>
                  <td><select value={e.status} onChange={(x) => go(() => api.entryStatus(e.entry_id, x.target.value))} aria-label="Status">
                    <option>Open</option><option>Closed</option><option>Approved</option></select></td><td>{e.source}</td></tr>
              ))}
              {g.entries.length === 0 && <tr><td colSpan={6} className="sub">No entries yet.</td></tr>}
            </tbody>
          </table>
          <div className="inline">
            <select value={f.kind} onChange={(e) => setF({ ...f, kind: e.target.value })} aria-label="Kind"><option>Event</option><option>File</option></select>
            <input placeholder="Title" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} aria-label="Title" />
            <input type="date" value={f.on_date} onChange={(e) => setF({ ...f, on_date: e.target.value })} aria-label="Date" />
            <select value={f.stage_id} onChange={(e) => setF({ ...f, stage_id: e.target.value })} aria-label="Stage">
              <option value="">Stage…</option>{tree.stages.map((s) => <option key={s.stage_id} value={s.stage_id}>{s.name}</option>)}</select>
            <button className="quiet" disabled={!f.title.trim()} onClick={() => go(() => api.addEntry(g.registry_id, { ...f, on_date: f.on_date || null, stage_id: f.stage_id || null })
              .then(() => setF({ ...f, title: '', on_date: '' })))}>Add entry</button>
          </div>
        </div>
      ))}
      <div className="reg-block">
        <h4 className="serif">Files from answers in this room</h4>
        <table className="ans-table">
          <thead><tr><th>File</th><th>Question</th><th>Stage</th><th>Mobility</th><th>Status</th></tr></thead>
          <tbody>
            {data.answer_files.map((x, i) => <tr key={i}><td>{x.file}</td><td>{x.question}</td><td>{x.stage}</td><td>{x.mobility}</td><td>{x.status}</td></tr>)}
            {data.answer_files.length === 0 && <tr><td colSpan={5} className="sub">No files attached in answers yet.</td></tr>}
          </tbody>
        </table>
      </div>
      <div className="reg-block">
        <h4 className="serif">Calendar</h4>
        {data.calendar.length === 0 && <p className="sub">Nothing due or scheduled.</p>}
        {data.calendar.map((c, i) => <p key={i}><span className={c.kind === 'Due' ? 'due-ink' : 'sub'}>{c.date}</span> · {c.kind} · {c.title}</p>)}
      </div>
      <div className="inline">
        <input placeholder="New registry name" value={nr.name} onChange={(e) => setNr({ ...nr, name: e.target.value })} aria-label="Registry name" />
        <input placeholder="Two-line description" value={nr.description} onChange={(e) => setNr({ ...nr, description: e.target.value })} aria-label="Description" />
        <select value={nr.holds} onChange={(e) => setNr({ ...nr, holds: e.target.value })} aria-label="Holds"><option>Both</option><option>Events</option><option>Files</option></select>
        <button className="quiet" disabled={!nr.name.trim()} onClick={() => go(() => api.roomAct(data.room_id, 'registries', nr).then(() => setNr({ name: '', description: '', holds: 'Both' })))}>+ Registry</button>
      </div>
      {msg && <p className="error">{msg}</p>}
    </div>
  );
}

export function Chat({ data, room, tree, onDone }) {
  const [body, setBody] = useState('');
  const [mention, setMention] = useState('');
  const [msg, setMsg] = useState('');
  const qs = tree.stages.flatMap((s) => s.topics.flatMap((t) => t.questions)).filter((q) => q.room_id === room.room_id);
  const canWrite = room.member;
  return (
    <aside className="chat">
      <div className="chat-head"><b>{room.name}</b><span className="sub">{data.sees}</span></div>
      <div className="chat-list">
        {data.messages.length === 0 && <p className="sub">No messages yet.</p>}
        {data.messages.map((m, i) => (
          <div key={i} className={m.mine ? 'msg mine' : 'msg'}>
            <span className="sub">{m.by} · {m.at}</span>
            <p>{m.body}</p>
            {m.mention && <span className="mention">↳ {m.mention}</span>}
          </div>
        ))}
      </div>
      {canWrite && (
        <div className="chat-input">
          <textarea rows={2} placeholder="Message this room" value={body} onChange={(e) => setBody(e.target.value)} aria-label="Message" />
          <div className="inline">
            <select value={mention} onChange={(e) => setMention(e.target.value)} aria-label="Mention a clause">
              <option value="">Mention a clause…</option>{qs.map((q) => <option key={q.qr_id} value={q.qr_id}>{q.text}</option>)}</select>
            <button className="primary" disabled={!body.trim()} onClick={async () => {
              setMsg(''); try { await api.roomAct(room.room_id, 'messages', { body, mention_qr: mention || null }); setBody(''); setMention(''); onDone(); } catch (e) { setMsg(e.message); }
            }}>Send</button>
          </div>
          {msg && <p className="error">{msg}</p>}
        </div>
      )}
    </aside>
  );
}

function TopicView({ row, tree, room, meta, onDone, focusQr }) {
  const { s, t, qs } = row;
  const seats = tree.seats.filter((x) => x.stage_id === s.stage_id);
  return (
    <div className="topic-layout">
      <div className="card">
        <div className="topic-head">
          <div>
            <h2 className="serif">{t.name}</h2>
            <p className="sub">{s.name} · {t.path} · {room?.kind === 'PR' ? 'Private' : `Shared · ${room?.name}`}</p>
          </div>
          <span className="pill">{t.status}</span>
        </div>
        <h4 className="serif">The questions inside it · {qs.length}</h4>
        {qs.map((q) => (
          <Question key={q.qr_id} q={q} stage={s} tree={tree} room={room} meta={meta} onDone={onDone} highlight={q.qr_id === focusQr} />
        ))}
      </div>
      <aside className="card side-card">
        <h4 className="serif">Around this topic</h4>
        <p className="label">APPROVAL GROUP</p>
        {seats.length === 0 && <p className="sub">No one seated on this stage yet.</p>}
        {seats.map((x) => <div key={x.seat_id} className="person-row"><span className="avatar">{x.person_name.split(' ').map((p) => p[0]).join('')}</span><span>{x.person_name}<br /><span className="sub">{x.seat}</span></span></div>)}
        {s.expertise.length > 0 && <><p className="label">EXPERTISE</p><p className="sub">{s.expertise.map((e) => `${e.name} (${e.mapped_as})`).join(', ')}</p></>}
        {s.my_seats.length > 0 && <p className="sub">Your seat: <b className="ink">{s.my_seats.join(', ')}</b></p>}
      </aside>
    </div>
  );
}

const n = (v) => (v === null || v === undefined || v === '' ? null : Number(v));
const fmt = (v) => (v === null ? '—' : v.toLocaleString('en-IN'));

// Report and Analytics inside the run: output documents, and Estimation vs Execution
export function Reports({ tree, companies, act }) {
  const [f, setF] = useState({ item: '', source: 'Owned', vendor_id: '', vendor_name: '', est_cost: '', est_price: '', est_days: '' });
  const est = tree.estimates || [];
  const sum = (k) => est.reduce((a, l) => a + (n(l[k]) || 0), 0);
  const both = !tree.estimation_only;
  return (
    <>
      <div className="card">
        <h3 className="serif">Output documents</h3>
        {tree.outputs.length === 0 && <p className="sub">This Krama has no output document topics.</p>}
        {tree.outputs.map((o) => (
          <div key={o.topic} className="reg-block">
            <div className="row-between"><h4 className="serif">{o.topic}</h4><span className="sub">{o.agreed} of {o.total} agreed</span></div>
            <div className="progress"><span style={{ width: `${o.total ? (100 * o.agreed) / o.total : 0}%` }} /></div>
            {o.lines.map((l, i) => <p key={i} className={l.agreed ? '' : 'sub'}><b>{l.question}:</b> {l.answer || 'not answered yet'}{l.agreed ? '' : ' (not agreed yet)'}</p>)}
            {o.files.length > 0 && <p className="sub">Referenced files: {o.files.join(', ')}</p>}
            <p className="sub">Amending the document with AI is not part of the demo.</p>
          </div>
        ))}
      </div>
      <div className="card">
        <h3 className="serif">{both ? 'Estimation vs Execution' : 'Estimation'}</h3>
        {!both && <p className="sub">This module shows Estimation only; Execution comes in Order management.</p>}
        <table className="ans-table">
          <thead><tr><th>Line item</th><th>Source</th><th>Vendor</th><th>Est. cost</th><th>Est. price</th><th>Est. margin</th><th>Est. days</th>
            {both && <><th>Act. cost</th><th>Act. price</th><th>Act. margin</th><th>Act. days</th></>}</tr></thead>
          <tbody>
            {est.map((l) => (
              <tr key={l.line_id}>
                <td>{l.item}</td><td>{l.status}</td><td>{l.vendor || '—'}</td>
                <td>{fmt(n(l.est_cost))}</td><td>{fmt(n(l.est_price))}</td>
                <td>{n(l.est_price) !== null && n(l.est_cost) !== null ? fmt(n(l.est_price) - n(l.est_cost)) : '—'}</td><td>{fmt(n(l.est_days))}</td>
                {both && <>
                  <td>{fmt(n(l.act_cost))}</td><td>{fmt(n(l.act_price))}</td>
                  <td>{n(l.act_price) !== null && n(l.act_cost) !== null ? fmt(n(l.act_price) - n(l.act_cost)) : '—'}</td><td>{fmt(n(l.act_days))}</td>
                </>}
                {both && tree.is_requestor && !tree.locked && (
                  <td><button className="plink ink" onClick={() => {
                    const c = window.prompt('Actual cost', l.act_cost ?? ''); if (c === null) return;
                    const p = window.prompt('Actual price', l.act_price ?? ''); if (p === null) return;
                    const d = window.prompt('Actual days', l.act_days ?? ''); if (d === null) return;
                    act(() => api.setActuals(l.line_id, { act_cost: c, act_price: p, act_days: d }));
                  }}>Record actuals</button></td>
                )}
              </tr>
            ))}
            {est.length > 0 && (
              <tr className="strong"><td>Total</td><td /><td /><td>{fmt(sum('est_cost'))}</td><td>{fmt(sum('est_price'))}</td><td>{fmt(sum('est_price') - sum('est_cost'))}</td><td>{fmt(sum('est_days'))}</td>
                {both && <><td>{fmt(sum('act_cost'))}</td><td>{fmt(sum('act_price'))}</td><td>{fmt(sum('act_price') - sum('act_cost'))}</td><td>{fmt(sum('act_days'))}</td></>}</tr>
            )}
            {est.length === 0 && <tr><td colSpan={11} className="sub">No line items yet.</td></tr>}
          </tbody>
        </table>
        {tree.is_requestor && !tree.locked && (
          <div className="inline">
            <input placeholder="Line item" value={f.item} onChange={(e) => setF({ ...f, item: e.target.value })} aria-label="Line item" />
            <select value={f.source} onChange={(e) => setF({ ...f, source: e.target.value })} aria-label="Source"><option>Owned</option><option>Borrowed</option></select>
            {f.source === 'Borrowed' && (
              <>
                <select value={f.vendor_id} onChange={(e) => setF({ ...f, vendor_id: e.target.value })} aria-label="Vendor">
                  <option value="">Vendor not on Compane…</option>{companies.map((c) => <option key={c.user_id} value={c.user_id}>{c.name}</option>)}</select>
                {!f.vendor_id && <input placeholder="Vendor name" value={f.vendor_name} onChange={(e) => setF({ ...f, vendor_name: e.target.value })} aria-label="Vendor name" />}
              </>
            )}
            <input placeholder="Cost" value={f.est_cost} onChange={(e) => setF({ ...f, est_cost: e.target.value })} aria-label="Cost" />
            <input placeholder="Price" value={f.est_price} onChange={(e) => setF({ ...f, est_price: e.target.value })} aria-label="Price" />
            <input placeholder="Days" value={f.est_days} onChange={(e) => setF({ ...f, est_days: e.target.value })} aria-label="Days" />
            <button className="quiet" disabled={!f.item.trim()} onClick={() => act(() => api.addEstimate(tree.run_id, { ...f, vendor_id: f.vendor_id || null }))
              .then(() => setF({ item: '', source: 'Owned', vendor_id: '', vendor_name: '', est_cost: '', est_price: '', est_days: '' }))}>Add line</button>
          </div>
        )}
      </div>
    </>
  );
}
