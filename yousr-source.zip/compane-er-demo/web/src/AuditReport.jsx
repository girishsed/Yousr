import { useEffect, useState } from 'react';
import { api } from './api.js';

export default function AuditReport({ runId, onBack }) {
  const [report, setReport] = useState(null);
  const [msg, setMsg] = useState('');

  useEffect(() => {
    api.audit(runId).then(setReport).catch((e) => setMsg(e.message));
  }, [runId]);

  if (msg) return <p className="error" role="alert">{msg}</p>;
  if (!report) return <p className="hint">Loading…</p>;

  return (
    <div className="audit">
      <div className="inline no-print">
        <button className="primary" onClick={() => window.print()}>Print / Save as PDF</button>
        <button className="quiet" onClick={onBack}>Back to Work-flow</button>
      </div>
      <div className="audit-head">
        <h2>{report.purpose}</h2>
        <p>
          Requestor/Conductor: {report.requestor_name}. Started {report.date}, version {report.version}.
          Status {report.status}{report.outcome ? `, outcome ${report.outcome}` : ''}.
        </p>
        {report.rooms.length > 0 && (
          <p>Rooms: {report.rooms.map((r) => `${r.name} (${r.type})`).join(', ')}</p>
        )}
      </div>
      <div className="table-wrap">
        <table>
          <thead>
            <tr><th>At</th><th>Who</th><th>Procedure</th><th>Action</th><th>Detail</th></tr>
          </thead>
          <tbody>
            {report.events.map((e, i) => (
              <tr key={i} className="static">
                <td className="id">{e.at}</td>
                <td>{e.who}</td>
                <td>{e.procedure || ''}</td>
                <td>{e.action}</td>
                <td className="wrap">{e.detail || ''}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
