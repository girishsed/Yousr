let actingUser = '';
export function setActingUser(id) { actingUser = id || ''; }
export const getActingUser = () => actingUser;

// Local (Docker) builds call /api; the hosted build calls the Supabase Edge Function and signs in with a session.
const BASE = import.meta.env.VITE_API_BASE || '/api';
export const hosted = !!import.meta.env.VITE_API_BASE;
let session = '';
try { session = window.localStorage.getItem('compane-session') || ''; } catch { /* ignore */ }
export function setSession(t) {
  session = t || '';
  try { if (session) window.localStorage.setItem('compane-session', session); else window.localStorage.removeItem('compane-session'); } catch { /* ignore */ }
}

async function call(method, path, body) {
  const headers = {};
  if (actingUser) headers['X-Acting-User'] = actingUser;
  if (session) headers['x-compane-session'] = session;
  if (body) headers['Content-Type'] = 'application/json';
  const res = await fetch(`${BASE}${path}`, { method, headers, body: body ? JSON.stringify(body) : undefined });
  if (res.status === 204) return null;
  const data = await res.json().catch(() => null);
  if (!res.ok) throw new Error(data?.message || `Request failed (${res.status})`);
  return data;
}

export const api = {
  createItem: (entityId, body) => call('POST', `/entity/${entityId}/catalogue`, body),
  item: (itemId) => call('GET', `/catalogue/${itemId}`),
  me: () => (hosted ? call('GET', '/me') : Promise.resolve(null)),
  demoSignin: (userId) => (hosted ? call('POST', '/demo-signin', { user_id: userId }).then((r) => setSession(r.session)) : Promise.resolve()),
  signOut: () => (hosted ? call('POST', '/sign-out', {}).catch(() => {}).then(() => setSession('')) : Promise.resolve()),
  do: (fn, body) => call('POST', `/do/${fn}`, body || {}),
  meta: () => call('GET', '/meta'),
  list: (e) => call('GET', `/${e}`),
  create: (e, row) => call('POST', `/${e}`, row),
  update: (e, id, row) => call('PUT', `/${e}/${id}`, row),
  remove: (e, id) => call('DELETE', `/${e}/${id}`),

  home: () => call('GET', '/home'),
  business: () => call('GET', '/business'),
  personalTasks: () => call('GET', '/personal/tasks'),
  personalCreate: (body) => call('POST', '/personal/tasks', body),
  personalAct: (id, action, body) => call('POST', `/personal/tasks/${id}/${action}`, body || {}),
  entityView: (entityId, view) => call('GET', `/entity/${entityId}/${view}`),
  setQuadrant: (qrId, quadrant) => call('POST', `/questions/${qrId}/quadrant`, { quadrant }),
  calendar: (from, to) => call('GET', `/calendar?from=${from}&to=${to}`),
  runs: () => call('GET', '/runs'),
  run: (id) => call('GET', `/runs/${id}`),
  audit: (id) => call('GET', `/runs/${id}/audit`),
  console: () => call('GET', '/console'),
  catalogue: () => call('GET', '/catalogue'),

  setStatus: (k, status) => call('POST', `/krama/${k}/status`, { status }),
  newVersion: (k, what) => call('POST', `/krama/${k}/new-version`, { what_changed: what }),
  importKrama: (k, entityId) => call('POST', `/krama/${k}/import`, { entity_id: entityId }),
  addItem: (kramaId, entityId, name) => call('POST', '/catalogue/items', { krama_id: kramaId, entity_id: entityId, name }),
  activate: (itemId, body) => call('POST', `/catalogue/${itemId}/activate`, body),
  resolve: (itemId, relationship, counterparty) =>
    call('GET', `/catalogue/${itemId}/resolve?relationship=${encodeURIComponent(relationship)}&counterparty=${counterparty || ''}`),
  assign: (itemId, kramaId) => call('POST', `/catalogue/${itemId}/assign`, { krama_id: kramaId }),
  updateItem: (itemId, body) => call('PUT', `/catalogue/${itemId}`, body),
  saveSection: (itemId, section, body) => call('POST', `/catalogue/${itemId}/sections/${section}`, body || {}),
  journeyKramas: (entityId) => call('GET', `/journey-kramas/${entityId}`),

  seat: (runId, stageId, seat, personId) => call('POST', `/runs/${runId}/seats`, { stage_id: stageId, seat, person_id: personId }),
  unseat: (seatId) => call('DELETE', `/seats/${seatId}`),
  act: (qrId, action, body) => call('POST', `/questions/${qrId}/${action}`, body || {}),
  amend: (runId) => call('POST', `/runs/${runId}/amend`),
  room: (roomId) => call('GET', `/rooms/${roomId}`),
  capabilities: () => call('GET', '/capabilities'),
  addCapability: (kramaId, body) => call('POST', `/krama/${kramaId}/capabilities`, body),
  removeCapability: (useId) => call('POST', `/capability-uses/${useId}/remove`),
  settleLine: (lineId, note) => call('POST', `/split-lines/${lineId}/settle`, { note }),
  addEstimate: (runId, body) => call('POST', `/runs/${runId}/estimates`, body),
  setActuals: (lineId, body) => call('POST', `/estimates/${lineId}/actuals`, body),
  addRoom: (runId, body) => call('POST', `/runs/${runId}/rooms`, body),
  roomAct: (roomId, action, body) => call('POST', `/rooms/${roomId}/${action}`, body || {}),
  addEntry: (registryId, body) => call('POST', `/registries/${registryId}/entries`, body),
  entryStatus: (entryId, status) => call('POST', `/entries/${entryId}/status`, { status }),
  createStandalone: (body) => call('POST', '/standalone', body),
  updateStandalone: (id, body) => call('PUT', `/standalone/${id}`, body),
  doneStandalone: (id) => call('POST', `/standalone/${id}/done`),
};
