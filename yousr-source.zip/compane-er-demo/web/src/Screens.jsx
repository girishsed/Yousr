import { useEffect, useState } from 'react';
import { api } from './api.js';
import Icon from './Icon.jsx';

export const QUADRANTS = ['Do now', 'Do later', 'Delegate', 'Delete'];
const QUADRANT_LINE = {
  'Do now': 'Urgent and important — these need you first.',
  'Do later': 'Important, not urgent — plan a time for them.',
  Delegate: 'Urgent, not important — hand them to someone.',
  Delete: 'Neither urgent nor important — they still exist and can be moved back.',
};

export function NotInDemo({ title }) {
  return (
    <div className="page">
      <h1 className="serif">{title}</h1>
      <div className="card empty-card"><p>This screen is in the Figma, but not part of the demo.</p></div>
    </div>
  );
}

export function PersonalHome({ name, onBusiness }) {
  const [dueToday, setDueToday] = useState(0);
  const [week, setWeek] = useState(0);
  useEffect(() => {
    const d = new Date();
    const iso = (x) => x.toISOString().slice(0, 10);
    const end = new Date(d); end.setDate(d.getDate() + 7);
    api.calendar(iso(d), iso(end)).then((items) => {
      const due = items.filter((i) => i.kind === 'due');
      setDueToday(due.filter((i) => i.date === iso(d)).length);
      setWeek(due.length);
    }).catch(() => {});
  }, []);
  const hour = new Date().getHours();
  const greet = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';
  return (
    <div className="page">
      <h1 className="serif">{greet}, {name.split(' ')[0]}</h1>
      <p className="sub">Here's what's happening in your workspace today.</p>
      <div className="stat-row">
        <div className="card stat"><div className="stat-head"><Icon name="tasks" /> Tasks</div><div className="stat-num">0</div><div className="sub">Personal tasks are not in the demo</div></div>
        <div className="card stat"><div className="stat-head"><Icon name="calendar" /> Events Today</div>
          <div className="stat-split"><div><div className="stat-num">{week}</div><div className="sub">Upcoming</div></div>
            <div className="sub"><b className="ink">{dueToday}</b> Today<br /><b>{week}</b> This week</div></div></div>
        <div className="card stat"><div className="stat-head"><Icon name="files" /> Files</div><div className="stat-num">0</div><div className="sub">Not in the demo</div></div>
        <div className="card stat"><div className="stat-head"><Icon name="id" /> My ID</div><div className="stat-num">—</div><div className="sub">Not in the demo</div></div>
      </div>
      <div className="two-col">
        <div className="card"><h3 className="serif">Needs you</h3><p className="sub">Nothing personal waiting. Entity work stays inside each entity.</p></div>
        <div className="card"><h3 className="serif">Asked of you by business</h3><p className="sub">No personal details requested.</p></div>
      </div>
      <button className="link-btn" onClick={onBusiness}>Go to Business →</button>
    </div>
  );
}

export function BusinessList({ onOpen }) {
  const [b, setB] = useState(null);
  useEffect(() => { api.business().then(setB).catch(() => setB({ entities: [] })); }, []);
  if (!b) return <div className="page"><p className="sub">Loading…</p></div>;
  const ops = b.entities.filter((e) => e.operational).length;
  return (
    <div className="page">
      <div className="page-head">
        <div><h1 className="serif">Business</h1><p className="sub">Your Business OS is ready. Open your modules and invite your team.</p></div>
      </div>
      <div className="stat-row three">
        <div className="card stat top-line"><div className="label">COMPANIES</div><div className="stat-num">{String(b.entities.length).padStart(2, '0')}</div><div className="sub">Open the list</div></div>
        <div className="card stat top-line"><div className="label">OPERATIONAL</div><div className="stat-num">{String(ops).padStart(2, '0')}</div><div className="sub">Ready to work</div></div>
        <div className="card stat top-line"><div className="label">SETUP INCOMPLETE</div><div className="stat-num muted">{String(b.entities.length - ops).padStart(2, '0')}</div><div className="sub">Still being set up</div></div>
      </div>
      <h2 className="serif section-title">Entities</h2>
      <p className="sub">Everything you need to manage your business, in one place.</p>
      <div className="entity-grid">
        {b.entities.length === 0 && <p className="sub">You don't belong to any entity yet.</p>}
        {b.entities.map((e) => (
          <button key={e.entity_id} className="card entity-card" onClick={() => onOpen(e)}>
            <span className="entity-icon"><Icon name="business" /></span>
            <span className="entity-name">{e.name}</span>
            <span className="sub">{[e.sub_type, e.persona].filter(Boolean).join(' · ')}</span>
            <span className={e.operational ? 'pill' : 'pill warn'}>{e.operational ? 'Operational' : 'Setup incomplete'}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

export function EntityHome({ entity, onOpenTask, onOpenStandalone }) {
  const [items, setItems] = useState([]);
  const [quadrant, setQuadrant] = useState('Do now');
  const [who, setWho] = useState('All');
  useEffect(() => { api.entityView(entity.entity_id, 'home').then(setItems).catch(() => setItems([])); }, [entity.entity_id]);
  const shown = items.filter((i) => i.quadrant === quadrant)
    .filter((i) => who === 'All' || (who === 'With me' ? i.with_me : !i.with_me));
  return (
    <div className="page">
      <div className="quadrant-tabs">
        {QUADRANTS.map((q) => (
          <button key={q} className={q === quadrant ? 'q-tab on' : 'q-tab'} onClick={() => setQuadrant(q)}>
            {q} <span className="count">{items.filter((i) => i.quadrant === q).length}</span>
          </button>
        ))}
      </div>
      <h1 className="serif">{quadrant}</h1>
      <p className="sub">{QUADRANT_LINE[quadrant]}</p>
      <div className="chips">
        {['All', 'With me', 'with others'].map((w) => (
          <button key={w} className={w === who ? 'chip on' : 'chip'} onClick={() => setWho(w)}>{w}</button>
        ))}
      </div>
      <div className="card-grid">
        {shown.length === 0 && <p className="sub">Nothing here.</p>}
        {shown.map((i) => (
          <button key={i.id} className={`card work-card ${i.quadrant === 'Do now' ? 'hot' : ''}`}
            onClick={() => (i.kind === 'standalone' ? onOpenStandalone(i.id) : onOpenTask(i.run_id, i.id))}>
            <span className="meta">{i.ref} · {i.lane} · {i.with_me ? 'with me' : 'with others'} · {i.quadrant}</span>
            <span className="title serif">{i.title}</span>
            <span className="meta-row">
              <span className="sub">{i.context}{i.state && i.kind === 'question' ? ` · ${i.state}` : ''}</span>
              <span className="badge-cap">{i.room === 'PR' ? <><Icon name="lock" size={12} /> Private</> : <><Icon name="shared" size={12} /> Shared</>}</span>
            </span>
            {i.due_date && <span className="due-ink">Due {i.due_date}</span>}
          </button>
        ))}
      </div>
    </div>
  );
}

export function TaskList({ entity, onOpenTask, onOpenStandalone, onNewFromCatalogue, onNewStandalone }) {
  const [rows, setRows] = useState([]);
  const [status, setStatus] = useState('All');
  const [lane, setLane] = useState('');
  const [side, setSide] = useState('');
  const [menu, setMenu] = useState(false);
  useEffect(() => { api.entityView(entity.entity_id, 'tasks').then(setRows).catch(() => setRows([])); }, [entity.entity_id]);
  const shown = rows.filter((r) => status === 'All' || r.status === status)
    .filter((r) => !lane || r.lane === lane).filter((r) => !side || r.side === side);
  return (
    <div className="page">
      <div className="page-head">
        <div><h1 className="serif">Tasks</h1><p className="sub">Everything being settled, inside the entity and outside it.</p></div>
        <div className="menu-wrap">
          <button className="primary" onClick={() => setMenu(!menu)}><Icon name="plus" size={14} /> New task</button>
          {menu && (
            <div className="menu">
              <button onClick={() => { setMenu(false); onNewFromCatalogue(); }}>From a Krama</button>
              <button onClick={() => { setMenu(false); onNewStandalone(); }}>Standalone</button>
            </div>
          )}
        </div>
      </div>
      <div className="card table-card">
        <div className="chips">
          {['All', 'Open', 'Closed'].map((s) => <button key={s} className={s === status ? 'chip on' : 'chip'} onClick={() => setStatus(s)}>{s}</button>)}
          <select className="chip-select" value={lane} onChange={(e) => setLane(e.target.value)} aria-label="Lane">
            <option value="">Lane</option><option>Standalone</option><option>workflow</option>
          </select>
          <select className="chip-select" value={side} onChange={(e) => setSide(e.target.value)} aria-label="Side">
            <option value="">Side</option><option>BUY</option><option>SELL</option><option>INTERNAL</option>
          </select>
        </div>
        <table className="ftable">
          <thead><tr><th>ID</th><th>Task</th><th>Lane</th><th>Side</th><th>Counterparty</th><th>Open lines</th><th>Next due</th><th>Quadrant</th></tr></thead>
          <tbody>
            {shown.map((r) => (
              <tr key={r.id} onClick={() => (r.kind === 'standalone' ? onOpenStandalone(r.id) : onOpenTask(r.id))}>
                <td className="muted">{r.ref}</td>
                <td className="strong serif">{r.title}{r.result ? <span className="sub"> · {r.result}</span> : ''}</td>
                <td><span className={r.lane === 'workflow' ? 'dot ink' : 'dot'}>• {r.lane}</span></td>
                <td className="caps">{r.side}</td>
                <td>{r.counterparty || '-'}</td>
                <td>{r.open_lines} of {r.total_lines}</td>
                <td>{r.next_due || 'No date'}</td>
                <td><span className={r.quadrant === 'Do now' ? 'dot ink' : 'dot'}>{r.quadrant ? `• ${r.quadrant}` : '-'}</span></td>
              </tr>
            ))}
            {shown.length === 0 && <tr><td colSpan={8} className="sub">No tasks.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export function Vendors({ entity }) {
  const [rows, setRows] = useState([]);
  useEffect(() => { api.entityView(entity.entity_id, 'vendors').then(setRows).catch(() => setRows([])); }, [entity.entity_id]);
  return (
    <div className="page">
      <h1 className="serif">Vendors</h1>
      <p className="sub">Entities you buy from, as Vendor or Pre-vendor.</p>
      <div className="card table-card">
        <table className="ftable">
          <thead><tr><th>Vendor</th><th>Relationship</th><th>Persona type</th><th>Tasks</th><th>Open</th></tr></thead>
          <tbody>
            {rows.map((v) => <tr key={v.entity_id} className="static"><td className="strong serif">{v.name}</td><td>{v.relationship}</td><td>{v.persona || '-'}</td><td>{v.runs}</td><td>{v.open}</td></tr>)}
            {rows.length === 0 && <tr><td colSpan={5} className="sub">No vendors yet.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// Standalone: one person's task; only the owner marks it Done
export function StandaloneDialog({ entity, taskId, onClose }) {
  const [t, setT] = useState(null);
  const [f, setF] = useState({ title: '', notes: '', due_date: '', quadrant: 'Do later' });
  const [msg, setMsg] = useState('');
  useEffect(() => {
    if (!taskId) return;
    api.entityView(entity.entity_id, 'tasks').then((rows) => {
      const r = rows.find((x) => x.id === taskId);
      setT(r);
      if (r) setF({ title: r.title, notes: r.notes || '', due_date: r.next_due || '', quadrant: r.quadrant });
    });
  }, [taskId, entity.entity_id]);
  const go = async (fn) => { setMsg(''); try { await fn(); onClose(true); } catch (e) { setMsg(e.message); } };
  const done = t && t.status === 'Closed';
  return (
    <div className="overlay" role="dialog" aria-modal="true">
      <div className="dialog">
        <div className="dialog-head"><h2 className="serif">{taskId ? 'Standalone task' : 'New Standalone task'}</h2><button className="x" onClick={() => onClose(false)}>×</button></div>
        <p className="sub">Only you can see it and mark it Done.</p>
        <label>Title<input disabled={done} value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></label>
        <label>Notes<textarea disabled={done} rows={2} value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} /></label>
        <div className="grid2">
          <label>Due date<input disabled={done} type="date" value={f.due_date} onChange={(e) => setF({ ...f, due_date: e.target.value })} /></label>
          <label>Quadrant<select disabled={done} value={f.quadrant} onChange={(e) => setF({ ...f, quadrant: e.target.value })}>{QUADRANTS.map((q) => <option key={q}>{q}</option>)}</select></label>
        </div>
        {msg && <p className="error">{msg}</p>}
        <div className="dialog-actions">
          {!taskId && <button className="primary" disabled={!f.title.trim()} onClick={() => go(() => api.createStandalone({ ...f, entity_id: entity.entity_id }))}>Create</button>}
          {taskId && !done && <button className="quiet" onClick={() => go(() => api.updateStandalone(taskId, f))}>Save</button>}
          {taskId && !done && <button className="primary" onClick={() => go(() => api.doneStandalone(taskId))}>Mark Done</button>}
          {done && <span className="pill">Done · conserved</span>}
        </div>
      </div>
    </div>
  );
}

// Yousr Tasks (locked 29 Oct 2026): To do / Done board; personal tasks and identifier requests from an entity
export function PersonalTasks() {
  const [rows, setRows] = useState([]);
  const [priority, setPriority] = useState('All');
  const [period, setPeriod] = useState('Today');
  const [showDeleted, setShowDeleted] = useState(false);
  const [adding, setAdding] = useState(false);
  const [f, setF] = useState({ title: '', due_date: '', quadrant: 'Do later' });
  const [msg, setMsg] = useState('');
  const load = () => api.personalTasks().then(setRows).catch((e) => setMsg(e.message));
  useEffect(() => { load(); }, []);
  const go = async (fn) => { setMsg(''); try { await fn(); await load(); } catch (e) { setMsg(e.message); } };

  const today = new Date(); today.setHours(0, 0, 0, 0);
  const limit = new Date(today); limit.setDate(today.getDate() + (period === 'Today' ? 0 : period === 'This week' ? 7 : 31));
  const inPeriod = (t) => {
    const d = t.status === 'Done' ? t.done_on : t.due_date;
    if (!d) return period !== 'Today';
    const x = new Date(d + 'T00:00:00');
    return t.status === 'Done' ? x >= new Date(today.getTime() - (limit - today) - 86400000) : x <= limit;
  };
  const shown = rows.filter((t) => priority === 'All' || t.quadrant === priority).filter(inPeriod);
  const todo = shown.filter((t) => t.status === 'To do');
  const done = shown.filter((t) => t.status === 'Done');
  const deleted = rows.filter((t) => t.status === 'Deleted');
  const when = (t) => {
    if (t.status === 'Done') return 'Done';
    if (!t.due_date) return 'No date';
    const days = Math.round((new Date(t.due_date + 'T00:00:00') - today) / 86400000);
    return days === 0 ? 'Due today' : days < 0 ? `Overdue ${-days} day${days === -1 ? '' : 's'}` : `Due in ${days} day${days === 1 ? '' : 's'}`;
  };

  const card = (t) => (
    <div key={t.task_id} className={`card ptask ${t.kind !== 'Personal' ? 'request' : ''}`}>
      <div className="ptask-title serif">{t.title}</div>
      <div className="ptags">
        <span className="ptag">{t.kind === 'Personal' ? 'Personal' : t.requested_by}</span>
        {t.status === 'To do'
          ? <select className="pquad" value={t.quadrant} aria-label="Priority" onChange={(e) => go(() => api.personalAct(t.task_id, 'quadrant', { quadrant: e.target.value }))}>
              {QUADRANTS.map((q) => <option key={q}>{q}</option>)}</select>
          : <span className="pquad">{t.quadrant}</span>}
      </div>
      {t.purpose && <p className="sub">{t.purpose}. Consent needed.</p>}
      <div className="pmeta">
        <span>{when(t)}</span>
        {t.status === 'To do' && (t.kind === 'Personal'
          ? <span className="pactions"><button className="plink" onClick={() => go(() => api.personalAct(t.task_id, 'done'))}>Mark done</button>
              <button className="plink muted" onClick={() => go(() => api.personalAct(t.task_id, 'delete'))}>Delete</button></span>
          : <button className="plink ink" onClick={() => go(() => api.personalAct(t.task_id, 'consent'))}>Give consent</button>)}
        {t.status === 'Done' && <span>Just you</span>}
      </div>
    </div>
  );

  return (
    <div className="page">
      <div className="toolbar-row">
        <select className="chip-select" value={priority} onChange={(e) => setPriority(e.target.value)} aria-label="Priority">
          <option value="All">Priority: All</option>{QUADRANTS.map((q) => <option key={q}>{q}</option>)}
        </select>
        <span className="push" />
        <button className="primary" onClick={() => setAdding(!adding)}><Icon name="plus" size={14} /> Add task</button>
        <button className="quiet" onClick={() => setShowDeleted(!showDeleted)}>Restore deleted{deleted.length ? ` (${deleted.length})` : ''}</button>
      </div>
      {adding && (
        <div className="card add-row">
          <input placeholder="Task title" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} aria-label="Title" />
          <input type="date" value={f.due_date} onChange={(e) => setF({ ...f, due_date: e.target.value })} aria-label="Due date" />
          <select value={f.quadrant} onChange={(e) => setF({ ...f, quadrant: e.target.value })} aria-label="Quadrant">{QUADRANTS.map((q) => <option key={q}>{q}</option>)}</select>
          <button className="primary" disabled={!f.title.trim()} onClick={() => go(() => api.personalCreate(f).then(() => { setF({ title: '', due_date: '', quadrant: 'Do later' }); setAdding(false); }))}>Add</button>
        </div>
      )}
      {showDeleted && (
        <div className="card add-row">
          {deleted.length === 0 ? <span className="sub">Nothing deleted.</span> : deleted.map((t) => (
            <span key={t.task_id} className="deleted-item">{t.title} <button className="plink ink" onClick={() => go(() => api.personalAct(t.task_id, 'restore'))}>Restore</button></span>
          ))}
        </div>
      )}
      <div className="chips">
        {['Today', 'This week', 'This month'].map((x) => <button key={x} className={x === period ? 'chip on' : 'chip'} onClick={() => setPeriod(x)}>{x}</button>)}
      </div>
      {msg && <p className="error">{msg}</p>}
      <div className="board">
        <div className="column"><h3 className="serif">To do <span className="count">{todo.length}</span></h3>{todo.map(card)}
          {todo.length === 0 && <p className="sub">Nothing to do in this period.</p>}</div>
        <div className="column"><h3 className="serif">Done <span className="count">{done.length}</span></h3>{done.map(card)}
          {done.length === 0 && <p className="sub">Nothing done in this period.</p>}</div>
      </div>
    </div>
  );
}
