import { useEffect, useState } from 'react';
import { api } from './api.js';

// Persona screens for Settings: Work Personas (what people see and may do), authority seats,
// the Entity Persona, and (platform super-user) domain persona definitions.
const MODULES = ['WOM', 'Krama', 'Catalogue', 'Vendors', 'Connections', 'Revenue', 'Compliance', 'Reports'];
const ACTIONS = ['View', 'Approve', 'Sign'];

function useLoad(fn, deps) {
  const [d, setD] = useState(null);
  const [err, setErr] = useState('');
  const load = () => fn().then((x) => { setD(x); setErr(''); }).catch((e) => setErr(e.message));
  useEffect(() => { load(); }, deps); // eslint-disable-line react-hooks/exhaustive-deps
  return [d, load, err];
}

export function WorkPersonas({ entity }) {
  const [d, load, err] = useLoad(() => api.do('work_personas', { entity_id: entity.entity_id }), [entity.entity_id]);
  const [seats, setSeats] = useState([]);
  const [f, setF] = useState({});
  const [edit, setEdit] = useState(null);
  const [msg, setMsg] = useState('');
  useEffect(() => { api.do('spine', { entity_id: entity.entity_id }).then(setSeats).catch(() => {}); }, [entity.entity_id]);
  const [perms, setPerms] = useState([]);
  const [pedit, setPedit] = useState(null);
  const loadPerms = () => api.do('permissions', { entity_id: entity.entity_id }).then(setPerms).catch(() => {});
  useEffect(() => { loadPerms(); }, [entity.entity_id]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!d) return <div className="card">{err ? <p className="error">{err}</p> : <p className="sub">Loading…</p>}</div>;
  const go = async (fn, ok) => { setMsg(''); try { await fn(); await load(); if (ok) setMsg(ok); } catch (e) { setMsg(e.message); } };
  const personas = d.dept_bus.flatMap((x) => x.personas.map((p) => ({ ...p, dept: x.name })));
  const set = (k, v) => setF((x) => ({ ...x, [k]: v }));
  const toggle = (k, v) => setEdit((e) => ({ ...e, [k]: e[k].includes(v) ? e[k].filter((y) => y !== v) : [...e[k], v] }));
  return (
    <>
      <div className="card">
        <h3 className="serif">Work Personas</h3>
        <p className="sub">A Work Persona is the person's role, responsibility and permission in one, set under their Dept/BU. The entity admin and each Dept/BU's admin set them.</p>
        {d.dept_bus.map((x) => (
          <div key={x.dept_bu_id} className="persona-block">
            <h4 className="serif">{x.name}</h4>
            <DeptProfile deptId={x.dept_bu_id} admin={d.is_admin} />
            <p className="sub">Grades: {x.grades.map((g) => g.name).join(' › ') || '—'}</p>
            {x.personas.map((p) => (
              <div key={p.persona_id} className="persona-row">
                <p><b>{p.name}</b> <span className="sub">· {p.grade || '—'}{p.reports_to ? ` · reports to ${p.reports_to}` : ''}{p.seat ? ` · seat: ${p.seat}` : ''}</span><br />
                  <span className="sub">Sees {p.modules.join(', ')} · can {p.actions.join(', ')}</span>
                  {(d.is_admin || d.my_admin_dept === x.dept_bu_id) && edit?.persona_id !== p.persona_id && <button className="link-btn" onClick={() => setEdit({ persona_id: p.persona_id, modules: p.modules, actions: p.actions, seat_id: p.seat_id || '' })}> Edit</button>}</p>
                {edit?.persona_id === p.persona_id && (
                  <div className="mini-form">
                    <div className="inline"><span className="sub">Sees</span>{MODULES.map((m) => <label key={m} className="check"><input type="checkbox" checked={edit.modules.includes(m)} onChange={() => toggle('modules', m)} />{m}</label>)}</div>
                    <div className="inline"><span className="sub">Can</span>{ACTIONS.map((a) => <label key={a} className="check"><input type="checkbox" checked={edit.actions.includes(a)} onChange={() => toggle('actions', a)} />{a}</label>)}</div>
                    <div className="inline"><span className="sub">Attaches to seat</span>
                      <select value={edit.seat_id} onChange={(e) => setEdit({ ...edit, seat_id: e.target.value })}><option value="">No authority seat</option>
                        {seats.map((s) => <option key={s.seat_id} value={s.seat_id}>{s.seat} ({s.min}{s.max ? `–${s.max}` : '+'})</option>)}</select></div>
                    <div className="inline"><button className="primary" onClick={() => go(() => api.do('persona_edit', edit).then(() => setEdit(null)), 'Saved')}>Save</button>
                      <button className="quiet" onClick={() => setEdit(null)}>Cancel</button></div>
                  </div>
                )}
              </div>
            ))}
            {(d.is_admin || d.my_admin_dept === x.dept_bu_id) && (
              <div className="inline">
                <select value={f[`k${x.dept_bu_id}`] || 'Grade'} onChange={(e) => set(`k${x.dept_bu_id}`, e.target.value)}><option>Grade</option><option>Work Persona</option><option>Exception</option></select>
                <input placeholder="Name" value={f[`n${x.dept_bu_id}`] || ''} onChange={(e) => set(`n${x.dept_bu_id}`, e.target.value)} />
                {f[`k${x.dept_bu_id}`] === 'Work Persona' && <select value={f[`g${x.dept_bu_id}`] || ''} onChange={(e) => set(`g${x.dept_bu_id}`, e.target.value)}><option value="">Grade…</option>{x.grades.map((g) => <option key={g.grade_id}>{g.name}</option>)}</select>}
                {['Work Persona', 'Exception'].includes(f[`k${x.dept_bu_id}`]) && <select value={f[`r${x.dept_bu_id}`] || ''} onChange={(e) => set(`r${x.dept_bu_id}`, e.target.value)}><option value="">Reports to…</option>{personas.map((p) => <option key={p.persona_id} value={p.persona_id}>{p.name}</option>)}</select>}
                <button className="quiet" onClick={() => go(() => api.do('add_org', { entity_id: entity.entity_id, dept_bu_id: x.dept_bu_id, kind: f[`k${x.dept_bu_id}`] || 'Grade', name: f[`n${x.dept_bu_id}`], grade: f[`g${x.dept_bu_id}`], reports_to: f[`r${x.dept_bu_id}`] }).then(() => set(`n${x.dept_bu_id}`, '')))}>Add</button>
              </div>
            )}
          </div>
        ))}
      </div>
      <div className="card">
        <h3 className="serif">People and their Work Persona</h3>
        <div className="table-wrap"><table className="ftable wrap"><thead><tr><th>Person</th><th>Dept/BU</th><th>Dept/BU admin</th><th>Work Persona</th><th>Gives</th></tr></thead><tbody>
          {d.people.map((u) => {
            const pr = perms.find((x) => x.link_id === u.link_id);
            const canPersona = d.is_admin || (d.my_admin_dept && d.my_admin_dept === u.dept_bu_id);
            const own = personas.filter((p) => d.is_admin || p.dept === (d.dept_bus.find((x) => x.dept_bu_id === u.dept_bu_id)?.name));
            return (
              <tr key={u.link_id}><td>{u.name}{u.admin ? <span className="sub"> · entity admin</span> : ''}</td>
                <td>{d.is_admin ? <select value={u.dept_bu_id || ''} onChange={(e) => go(() => api.do('set_member_dept', { link_id: u.link_id, dept_bu_id: e.target.value }).then(loadPerms))}>
                  <option value="">Entity level</option>{d.dept_bus.map((x) => <option key={x.dept_bu_id} value={x.dept_bu_id}>{x.name}</option>)}</select> : (u.dept_bu || '—')}</td>
                <td>{d.is_admin && u.dept_bu_id ? <label className="check"><input type="checkbox" checked={!!u.dept_admin} onChange={(e) => go(() => api.do('set_dept_admin', { link_id: u.link_id, on: e.target.checked }))} />Admin</label> : (u.dept_admin ? 'Admin' : '—')}</td>
                <td>{canPersona ? <select value={u.persona_id || ''} onChange={(e) => go(() => api.do('assign_persona', { link_id: u.link_id, persona_id: e.target.value }).then(loadPerms))}>
                  <option value="">No Work Persona</option>{own.map((p) => <option key={p.persona_id} value={p.persona_id}>{p.name} · {p.dept}</option>)}</select> : (u.persona || '—')}</td>
                <td>{pr ? <span>{pr.access.modules.join(', ')} · {pr.access.actions.join(', ')} <span className="sub">({pr.access.source})</span></span> : '—'}</td></tr>
            );
          })}
        </tbody></table></div>
      </div>
      {msg && <p className="sub">{msg}</p>}
    </>
  );
}

export function AuthoritySeats({ entity }) {
  const [rows, , err] = useLoad(() => api.do('spine', { entity_id: entity.entity_id }), [entity.entity_id]);
  return (
    <div className="card">
      <h3 className="serif">Authority seats</h3>
      <p className="sub">Seats come from the legal form, with the minimum and maximum set by law. A Work Persona attaches to a seat; it never creates one.</p>
      <table className="ftable"><thead><tr><th>Seat</th><th>By law</th><th>Work Personas</th><th>Filled</th></tr></thead><tbody>
        {(rows || []).map((s) => (
          <tr key={s.seat_id}><td className="strong">{s.seat}</td><td>{s.min}{s.max ? `–${s.max}` : '+'}</td><td>{s.personas.join(', ') || '—'}{s.people.length ? <span className="sub"> · {s.people.join(', ')}</span> : ''}</td>
            <td className={s.filled < s.min ? 'ink' : ''}>{s.filled}{s.filled < s.min ? ` (${s.min - s.filled} short)` : ''}</td></tr>
        ))}
        {(rows || []).length === 0 && <tr><td colSpan={4} className="sub">No authority seats for this legal form.</td></tr>}
      </tbody></table>
      {err && <p className="error">{err}</p>}
    </div>
  );
}

export function EntityPersona({ entity, admin }) {
  const [d, load, err] = useLoad(() => api.do('entity_persona', { entity_id: entity.entity_id }), [entity.entity_id]);
  const [types, setTypes] = useState(null);
  const [pick, setPick] = useState('');
  const [msg, setMsg] = useState('');
  if (!d) return <div className="card">{err && <p className="error">{err}</p>}</div>;
  return (
    <div className="card">
      <h3 className="serif">Entity Persona</h3>
      <p><b>{d.path || 'Not set'}</b></p>
      {d.description && <p className="sub">{d.description}</p>}
      <p className="sub">Applies to legal forms: {(d.legal_forms || []).join(', ') || 'Any'} · sizes: {(d.size_bands || []).join(', ') || 'Any'}</p>
      <EntityProfile entity={entity} admin={admin} />
      <h4 className="serif">Obligatory</h4><p>{(d.obligatory || []).join(' · ') || <span className="sub">None defined for this persona yet.</span>}</p>
      <h4 className="serif">Non-obligatory</h4><p>{(d.non_obligatory || []).join(' · ') || <span className="sub">None defined for this persona yet.</span>}</p>
      {admin && (types === null
        ? <button className="quiet" onClick={async () => setTypes(await api.do('entity_personas', {}))}>Change Entity Persona</button>
        : <div className="inline"><select value={pick} onChange={(e) => setPick(e.target.value)}><option value="">Pick a persona type…</option>
            {types.map((t) => <option key={t.persona_type_id} value={t.persona_type_id}>{t.path}</option>)}</select>
            <button className="primary" disabled={!pick} onClick={async () => { setMsg(''); try { await api.do('set_entity_persona', { entity_id: entity.entity_id, persona_type_id: pick }); setTypes(null); load(); } catch (e) { setMsg(e.message); } }}>Save</button></div>)}
      {msg && <p className="error">{msg}</p>}
    </div>
  );
}

export function DomainPersonas({ isSuper }) {
  return <><DomainProfiles isSuper={isSuper} /><DomainPersonaList isSuper={isSuper} /></>;
}
function DomainPersonaList({ isSuper }) {
  const [rows, load, err] = useLoad(() => api.do('domain_personas', {}), []);
  const [f, setF] = useState(null);
  const [msg, setMsg] = useState('');
  return (
    <div className="card">
      <h3 className="serif">Domain personas</h3>
      <p className="sub">Each domain persona is defined: requirements, permissible and not permissible, and the seats it needs. The platform super-user maintains them.</p>
      {(rows || []).map((d) => (
        <div key={d.domain_persona_id} className="persona-block">
          <p><b>{d.catalogue} › {d.domain} › {d.name}</b> <span className="sub">· {d.obligatory ? 'Obligatory' : 'Non-obligatory'} · seats {d.seats.join(', ')}</span>
            {isSuper && <button className="link-btn" onClick={() => setF({ ...d, permissible: d.permissible.join('\n'), not_permissible: d.not_permissible.join('\n') })}> Edit</button>}</p>
          {d.requirements && <p className="sub">{d.requirements}</p>}
          {(d.permissible.length > 0 || d.not_permissible.length > 0) && <p className="sub">Permissible: {d.permissible.join(', ') || '—'} · Not permissible: {d.not_permissible.join(', ') || '—'}</p>}
          {f?.domain_persona_id === d.domain_persona_id && (
            <div className="mini-form">
              <label className="check"><input type="checkbox" checked={!!f.obligatory} onChange={(e) => setF({ ...f, obligatory: e.target.checked })} />Obligatory</label>
              <textarea rows={2} placeholder="Requirements" value={f.requirements || ''} onChange={(e) => setF({ ...f, requirements: e.target.value })} />
              <textarea rows={3} placeholder="Permissible, one per line" value={f.permissible} onChange={(e) => setF({ ...f, permissible: e.target.value })} />
              <textarea rows={3} placeholder="Not permissible, one per line" value={f.not_permissible} onChange={(e) => setF({ ...f, not_permissible: e.target.value })} />
              <div className="inline">{['Fulfiller', 'Auditor', 'Representation'].map((x) => (
                <label key={x} className="check"><input type="checkbox" checked={f.seats.includes(x)} onChange={(e) => setF({ ...f, seats: e.target.checked ? [...f.seats, x] : f.seats.filter((y) => y !== x) })} />{x}</label>))}</div>
              <div className="inline"><button className="primary" onClick={async () => { setMsg(''); try { await api.do('save_domain_persona', f); setF(null); load(); } catch (e) { setMsg(e.message); } }}>Save</button>
                <button className="quiet" onClick={() => setF(null)}>Cancel</button></div>
            </div>
          )}
        </div>
      ))}
      {(err || msg) && <p className="error">{err || msg}</p>}
    </div>
  );
}

// Shown on a catalogue item's Overview: the definition of its domain persona
export function DomainPersonaDefinition({ domain, name }) {
  const [rows] = useLoad(() => api.do('domain_personas', {}), []);
  const d = (rows || []).find((x) => x.name === name && (!domain || x.domain === domain));
  if (!d) return null;
  return (
    <div className="persona-def">
      <p className="field-l">Domain persona definition</p>
      <p className="value">{d.obligatory ? 'Obligatory' : 'Non-obligatory'} · seats {d.seats.join(', ')}</p>
      {d.requirements && <p className="hint">{d.requirements}</p>}
      {(d.permissible.length > 0 || d.not_permissible.length > 0) && <p className="hint">Permissible: {d.permissible.join(', ') || '—'} · Not permissible: {d.not_permissible.join(', ') || '—'}</p>}
    </div>
  );
}

// ---------- Entity Profile: objectives and capabilities ----------
function EntityProfile({ entity, admin }) {
  const [d, load] = useLoad(() => api.do('entity_profile', { entity_id: entity.entity_id }), [entity.entity_id]);
  const [f, setF] = useState(null);
  const [msg, setMsg] = useState('');
  if (!d) return null;
  return (
    <div className="persona-def">
      <h4 className="serif">Entity Profile</h4>
      {!f ? <>
        <p><span className="sub">Business objectives</span><br />{d.objectives || <span className="sub">Not set</span>}</p>
        <p><span className="sub">Functional capabilities</span><br />{(d.capabilities || []).join(' · ') || <span className="sub">Not set</span>}</p>
        <p><span className="sub">Areas of operation</span><br />{(d.areas_of_operation || []).join(' · ') || <span className="sub">Not set</span>}</p>
        <p><span className="sub">Business interests</span><br />{(d.business_interests || []).join(' · ') || <span className="sub">Not set</span>}</p>
        {admin && <button className="quiet" onClick={() => setF({ objectives: d.objectives || '', capabilities: (d.capabilities || []).join('\n'),
          areas_of_operation: (d.areas_of_operation || []).join('\n'), business_interests: (d.business_interests || []).join('\n') })}>Edit</button>}
      </> : (
        <div className="mini-form">
          <textarea rows={2} placeholder="Business objectives" value={f.objectives} onChange={(e) => setF({ ...f, objectives: e.target.value })} />
          <textarea rows={3} placeholder="Functional capabilities, one per line" value={f.capabilities} onChange={(e) => setF({ ...f, capabilities: e.target.value })} />
          <textarea rows={2} placeholder="Areas of operation (cities, states, countries), one per line" value={f.areas_of_operation} onChange={(e) => setF({ ...f, areas_of_operation: e.target.value })} />
          <textarea rows={2} placeholder="Business interests, one per line" value={f.business_interests} onChange={(e) => setF({ ...f, business_interests: e.target.value })} />
          <div className="inline"><button className="primary" onClick={async () => { setMsg(''); try { await api.do('entity_profile', { entity_id: entity.entity_id, save: f }); setF(null); load(); } catch (e) { setMsg(e.message); } }}>Save</button>
            <button className="quiet" onClick={() => setF(null)}>Cancel</button></div>
        </div>
      )}
      {msg && <p className="error">{msg}</p>}
    </div>
  );
}

// ---------- Domain Profile: the subject area, above its domain personas ----------
function DomainProfiles({ isSuper }) {
  const [rows, load, err] = useLoad(() => api.do('domain_profiles', {}), []);
  const [f, setF] = useState(null);
  const [msg, setMsg] = useState('');
  const L = (a) => (a || []).join(', ') || '—';
  return (
    <div className="card">
      <h3 className="serif">Domain Profiles</h3>
      <p className="sub">A Domain Profile describes the subject area itself: objectives, terminology, regulations, typical workflows, controls and compliance requirements. Its domain personas sit beneath it.</p>
      {(rows || []).map((d) => (
        <div key={d.domain_id} className="persona-block">
          <p><b>{d.catalogue} › {d.name}</b> <span className="sub">· domain personas: {d.personas.join(', ') || '—'}</span>
            {isSuper && f?.domain_id !== d.domain_id && <button className="link-btn" onClick={() => { const p = d.profile || {}; setF({ domain_id: d.domain_id, objectives: p.objectives || '', terminology: (p.terminology || []).join('\n'),
              regulations: (p.regulations || []).join('\n'), typical_workflows: (p.typical_workflows || []).join('\n'), controls: (p.controls || []).join('\n'), compliance_requirements: p.compliance_requirements || '',
              knowledge: (p.knowledge || []).join('\n') }); }}> Edit</button>}</p>
          {d.profile ? <p className="sub">Objectives: {d.profile.objectives || '—'} · Terminology: {L(d.profile.terminology)} · Regulations: {L(d.profile.regulations)} · Workflows: {L(d.profile.typical_workflows)} · Controls: {L(d.profile.controls)}{d.profile.compliance_requirements ? ` · Compliance: ${d.profile.compliance_requirements}` : ''} · Knowledge: {L(d.profile.knowledge)}</p>
            : <p className="sub">No profile yet.</p>}
          {f?.domain_id === d.domain_id && (
            <div className="mini-form">
              <textarea rows={2} placeholder="Domain objectives" value={f.objectives} onChange={(e) => setF({ ...f, objectives: e.target.value })} />
              <div className="inline">
                <textarea rows={3} placeholder="Terminology, one per line" value={f.terminology} onChange={(e) => setF({ ...f, terminology: e.target.value })} />
                <textarea rows={3} placeholder="Applicable regulations, one per line" value={f.regulations} onChange={(e) => setF({ ...f, regulations: e.target.value })} />
              </div>
              <div className="inline">
                <textarea rows={3} placeholder="Typical workflows, one per line" value={f.typical_workflows} onChange={(e) => setF({ ...f, typical_workflows: e.target.value })} />
                <textarea rows={3} placeholder="Expected controls, one per line" value={f.controls} onChange={(e) => setF({ ...f, controls: e.target.value })} />
              </div>
              <textarea rows={2} placeholder="Compliance requirements" value={f.compliance_requirements} onChange={(e) => setF({ ...f, compliance_requirements: e.target.value })} />
              <textarea rows={3} placeholder="Domain-specific knowledge, one point per line" value={f.knowledge} onChange={(e) => setF({ ...f, knowledge: e.target.value })} />
              <div className="inline"><button className="primary" onClick={async () => { setMsg(''); try { await api.do('save_domain_profile', f); setF(null); load(); } catch (e) { setMsg(e.message); } }}>Save</button>
                <button className="quiet" onClick={() => setF(null)}>Cancel</button></div>
            </div>
          )}
        </div>
      ))}
      {(err || msg) && <p className="error">{err || msg}</p>}
    </div>
  );
}

// ---------- Person Persona: who the individual is professionally (the person edits their own) ----------
export function PersonPersona() {
  const [d, load, err] = useLoad(() => api.do('person_persona', {}), []);
  const [f, setF] = useState(null);
  const [msg, setMsg] = useState('');
  if (!d) return <div className="card">{err && <p className="error">{err}</p>}</div>;
  const p = d.persona || {};
  const names = (ids) => d.expertise.filter((x) => (ids || []).includes(x.expertise_id)).map((x) => x.name).join(', ') || '—';
  return (
    <div className="card">
      <h3 className="serif">My Person Persona</h3>
      <p className="sub">Who you are professionally. It travels with you across every entity; your Permission in each entity is set separately.</p>
      {!f ? <>
        <p><span className="sub">Professional identity</span><br />{p.professional_identity || '—'}</p>
        <p><span className="sub">Skills and competencies</span><br />{(p.skills || []).join(', ') || '—'}</p>
        <p><span className="sub">Areas of expertise</span><br />{names(d.expertise_ids)}</p>
        <p><span className="sub">Experience</span><br />{p.experience || '—'}</p>
        <p><span className="sub">Functional interests</span><br />{(p.functional_interests || []).join(', ') || '—'}</p>
        <p><span className="sub">Working preferences</span><br />{p.working_preferences || '—'}</p>
        <p><span className="sub">Communication preferences</span><br />{p.communication_preferences || '—'}</p>
        <button className="quiet" onClick={() => setF({ professional_identity: p.professional_identity || '', skills: (p.skills || []).join('\n'), expertise_ids: d.expertise_ids || [],
          experience: p.experience || '', functional_interests: (p.functional_interests || []).join('\n'), working_preferences: p.working_preferences || '', communication_preferences: p.communication_preferences || '' })}>Edit</button>
      </> : (
        <div className="mini-form">
          <input placeholder="Professional identity" value={f.professional_identity} onChange={(e) => setF({ ...f, professional_identity: e.target.value })} />
          <textarea rows={3} placeholder="Skills and competencies, one per line" value={f.skills} onChange={(e) => setF({ ...f, skills: e.target.value })} />
          <div className="inline"><span className="sub">Areas of expertise</span>{d.expertise.map((x) => (
            <label key={x.expertise_id} className="check"><input type="checkbox" checked={f.expertise_ids.includes(x.expertise_id)}
              onChange={() => setF({ ...f, expertise_ids: f.expertise_ids.includes(x.expertise_id) ? f.expertise_ids.filter((y) => y !== x.expertise_id) : [...f.expertise_ids, x.expertise_id] })} />{x.name}</label>))}</div>
          <input placeholder="Experience" value={f.experience} onChange={(e) => setF({ ...f, experience: e.target.value })} />
          <textarea rows={2} placeholder="Functional interests, one per line" value={f.functional_interests} onChange={(e) => setF({ ...f, functional_interests: e.target.value })} />
          <input placeholder="Working preferences" value={f.working_preferences} onChange={(e) => setF({ ...f, working_preferences: e.target.value })} />
          <input placeholder="Communication preferences" value={f.communication_preferences} onChange={(e) => setF({ ...f, communication_preferences: e.target.value })} />
          <div className="inline"><button className="primary" onClick={async () => { setMsg(''); try { await api.do('person_persona', { save: f }); setF(null); load(); } catch (e) { setMsg(e.message); } }}>Save</button>
            <button className="quiet" onClick={() => setF(null)}>Cancel</button></div>
        </div>
      )}
      {msg && <p className="error">{msg}</p>}
    </div>
  );
}

// ---------- Responsibility: bearer, fulfiller and auditor against named people or vendors ----------
export function Responsibilities({ entity }) {
  const [rows, load, err] = useLoad(() => api.do('responsibilities', { entity_id: entity.entity_id }), [entity.entity_id]);
  const [items, setItems] = useState([]);
  const [people, setPeople] = useState([]);
  const [vendors, setVendors] = useState([]);
  const [admin, setAdmin] = useState(false);
  const [f, setF] = useState({ item_id: '', obligation: '', kind: 'Fulfiller', who: '' });
  const [msg, setMsg] = useState('');
  useEffect(() => {
    api.catalogue().then((c) => setItems((c.items || []).filter((i) => i.entity_id === entity.entity_id))).catch(() => {});
    api.do('permissions', { entity_id: entity.entity_id }).then(setPeople).catch(() => {});
    api.do('my_access', { entity_id: entity.entity_id }).then((a) => setAdmin(!!a.admin)).catch(() => {});
    api.list('users').then((u) => setVendors(u.filter((x) => x.user_type === 'Company' && x.user_id !== entity.entity_id))).catch(() => {});
  }, [entity.entity_id]);
  const groups = {};
  (rows || []).forEach((r) => { (groups[r.obligation] = groups[r.obligation] || []).push(r); });
  const add = async () => {
    setMsg('');
    const [kind, id] = f.who.split(':');
    try {
      await api.do('responsibilities', { entity_id: entity.entity_id, add: { item_id: f.item_id, obligation: f.obligation, kind: f.kind,
        person_id: kind === 'p' ? id : '', vendor_id: kind === 'v' ? id : '' } });
      setF({ item_id: '', obligation: '', kind: 'Fulfiller', who: '' }); load();
    } catch (e) { setMsg(e.message); }
  };
  return (
    <div className="card">
      <h3 className="serif">Responsibilities</h3>
      <p className="sub">For each obligation: the bearer carries the liability, the fulfiller executes and submits, the auditor examines and certifies. Kept apart from roles (seats) and Permission.</p>
      {Object.keys(groups).length === 0 && <p className="sub">No responsibilities recorded yet.</p>}
      {Object.entries(groups).map(([ob, list]) => (
        <div key={ob} className="persona-block">
          <p><b>{ob}</b></p>
          {list.map((r) => <p key={r.responsibility_id}><span className="sub">{r.kind}</span> {r.who || '—'} <span className="sub">· {r.who_kind}</span>
            {admin && <button className="link-btn" onClick={async () => { await api.do('responsibilities', { entity_id: entity.entity_id, remove: r.responsibility_id }); load(); }}> Remove</button>}</p>)}
        </div>
      ))}
      {admin && (
        <div className="inline">
          <select value={f.item_id} onChange={(e) => setF({ ...f, item_id: e.target.value })}><option value="">Catalogue item…</option>{items.map((i) => <option key={i.item_id} value={i.item_id}>{i.name}</option>)}</select>
          {!f.item_id && <input placeholder="or the obligation" value={f.obligation} onChange={(e) => setF({ ...f, obligation: e.target.value })} />}
          <select value={f.kind} onChange={(e) => setF({ ...f, kind: e.target.value })}><option>Bearer</option><option>Fulfiller</option><option>Auditor</option></select>
          {f.kind !== 'Bearer' && <select value={f.who} onChange={(e) => setF({ ...f, who: e.target.value })}><option value="">Person or vendor…</option>
            <optgroup label="People">{people.map((u) => <option key={u.person_id} value={`p:${u.person_id}`}>{u.name}</option>)}</optgroup>
            <optgroup label="Vendors">{vendors.map((v) => <option key={v.user_id} value={`v:${v.user_id}`}>{v.name}</option>)}</optgroup></select>}
          <button className="quiet" onClick={add}>Add</button>
        </div>
      )}
      {(err || msg) && <p className="error">{err || msg}</p>}
    </div>
  );
}

// ---------- Dept/BU profile: objectives, capabilities, areas of operation, business interests ----------
function DeptProfile({ deptId, admin }) {
  const [d, load] = useLoad(() => api.do('dept_profile', { dept_bu_id: deptId }), [deptId]);
  const [f, setF] = useState(null);
  const [msg, setMsg] = useState('');
  if (!d) return null;
  const L = (a) => (a || []).join(' · ');
  return (
    <div className="dept-profile">
      {!f ? (
        <p className="sub">Profile — Objectives: {d.objectives || 'Not set'} · Capabilities: {L(d.capabilities) || 'Not set'} · Areas: {L(d.areas_of_operation) || 'Not set'} · Interests: {L(d.business_interests) || 'Not set'}{d.head ? ` · Head: ${d.head}` : ''} · {d.people} people
          {admin && <button className="link-btn" onClick={() => setF({ objectives: d.objectives || '', capabilities: (d.capabilities || []).join('\n'), areas_of_operation: (d.areas_of_operation || []).join('\n'), business_interests: (d.business_interests || []).join('\n') })}> Edit profile</button>}</p>
      ) : (
        <div className="mini-form">
          <textarea rows={2} placeholder="Objectives" value={f.objectives} onChange={(e) => setF({ ...f, objectives: e.target.value })} />
          <div className="inline">
            <textarea rows={2} placeholder="Capabilities, one per line" value={f.capabilities} onChange={(e) => setF({ ...f, capabilities: e.target.value })} />
            <textarea rows={2} placeholder="Areas of operation, one per line" value={f.areas_of_operation} onChange={(e) => setF({ ...f, areas_of_operation: e.target.value })} />
            <textarea rows={2} placeholder="Business interests, one per line" value={f.business_interests} onChange={(e) => setF({ ...f, business_interests: e.target.value })} />
          </div>
          <div className="inline"><button className="primary" onClick={async () => { setMsg(''); try { await api.do('dept_profile', { dept_bu_id: deptId, save: f }); setF(null); load(); } catch (x) { setMsg(x.message); } }}>Save</button>
            <button className="quiet" onClick={() => setF(null)}>Cancel</button></div>
        </div>
      )}
      {msg && <p className="error">{msg}</p>}
    </div>
  );
}
