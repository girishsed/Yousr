// Which UI the demo opens with: 'classic' or 'chat'. Both UIs are always available from inside the app.
export const DEFAULT_UI = 'classic';
