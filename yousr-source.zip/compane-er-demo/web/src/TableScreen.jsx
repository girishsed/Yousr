import { useEffect, useState } from 'react';
import { api } from './api.js';
import Field from './Field.jsx';

const short = (id) => (id ? id.slice(-8) : '');

/** A plain table screen for any registered table, built from the registry. */
export default function TableScreen({ ent, byKey, meta, canWrite, note, onChanged }) {
  const [rows, setRows] = useState([]);
  const [refs, setRefs] = useState({});
  const [editing, setEditing] = useState(null);
  const [error, setError] = useState('');

  async function load() {
    const refKeys = [...new Set(ent.cols.filter((c) => c.ref).map((c) => c.ref))];
    const [list, ...refLists] = await Promise.all([api.list(ent.key), ...refKeys.map((k) => api.list(k).catch(() => []))]);
    const next = {};
    refKeys.forEach((k, i) => (next[k] = refLists[i]));
    setRows(list);
    setRefs(next);
  }

  useEffect(() => {
    setEditing(null);
    setError('');
    load().catch((e) => { setRows([]); setError(e.message); });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ent.key]);

  function refLabel(refKey, id) {
    if (!id) return '';
    const refEnt = byKey[refKey];
    const row = refs[refKey]?.find((r) => r[refEnt.pk] === id);
    if (!row) return short(id);
    const text = refEnt.display.map((d) => row[d]).filter(Boolean).join(', ');
    return text ? `${text} (${short(id)})` : short(id);
  }

  function cell(col, row) {
    const v = row[col.name];
    if (col.type === 'UUIDS') return (v || []).map((id) => refLabel(col.ref, id).replace(/ \(.*\)$/, '')).join(', ');
    if (col.type === 'ENUMS') return (v || []).join(', ');
    if (col.ref) return refLabel(col.ref, v);
    if (col.type === 'BOOL') return v ? 'Yes' : 'No';
    return v ?? '';
  }

  const shown = ent.cols.filter((c) => c.label && !c.virtual);
  // fields that depend (directly or further down) on a field
  const dependentsOf = (name) => ent.cols.filter((c) => c.dependsOn === name)
    .flatMap((c) => [c.name, ...dependentsOf(c.name)]);
  // a narrowing choice takes its value from the row picked in the field that depends on it
  const deriveVirtuals = (values) => {
    const v = { ...values };
    ent.cols.filter((c) => c.virtual).forEach((vc) => {
      const dep = ent.cols.find((c) => c.dependsOn === vc.name && v[c.name]);
      const row = dep && refs[dep.ref]?.find((r) => r[byKey[dep.ref].pk] === v[dep.name]);
      v[vc.name] = row ? row[dep.matchKey] : '';
    });
    return v;
  };
  function setValue(name, value) {
    setEditing((e) => {
      const values = { ...e.values, [name]: value };
      dependentsOf(name).forEach((d) => (values[d] = ''));
      return { ...e, values };
    });
  }

  function startAdd() {
    const values = {};
    ent.cols.filter((c) => !c.expr).forEach((c) => {
      if (c.type === 'UUIDS' || c.type === 'ENUMS') values[c.name] = [];
      else if (c.type === 'ENUM') values[c.name] = c.options[0];
      else if (c.type === 'BOOL') values[c.name] = false;
      else values[c.name] = '';
    });
    setError('');
    setEditing({ id: null, values });
  }

  function startEdit(row) {
    const values = {};
    ent.cols.forEach((c) => (values[c.name] = row[c.name] ?? (c.type === 'UUIDS' || c.type === 'ENUMS' ? [] : '')));
    setError('');
    setEditing({ id: row[ent.pk], values: deriveVirtuals(values) });
  }

  async function save() {
    const missing = ent.cols.find((c) => c.required && !c.expr && (editing.values[c.name] === '' || editing.values[c.name] == null));
    if (missing) { setError(`${missing.label} is required.`); return; }
    const body = {};
    ent.cols.filter((c) => !c.expr && !c.virtual).forEach((c) => (body[c.name] = editing.values[c.name]));
    try {
      if (editing.id) await api.update(ent.key, editing.id, body);
      else await api.create(ent.key, body);
      setEditing(null);
      await load();
      onChanged && onChanged();
    } catch (e) { setError(e.message); }
  }

  async function remove() {
    if (!window.confirm(`Delete this ${ent.label} row?`)) return;
    try {
      await api.remove(ent.key, editing.id);
      setEditing(null);
      await load();
      onChanged && onChanged();
    } catch (e) { setError(e.message); }
  }

  const options = (c) => (refs[c.ref] || [])
    .filter((r) => !c.filter || r.user_type === c.filter)
    .filter((r) => !c.dependsOn || (editing?.values[c.dependsOn] && r[c.matchKey] === editing.values[c.dependsOn]))
    .map((r) => ({ id: r[byKey[c.ref].pk], label: refLabel(c.ref, r[byKey[c.ref].pk]) }));

  return (
    <>
      <header className="space-head">
        <div>
          <h1>{ent.label}</h1>
          <p className="count">{rows.length} {rows.length === 1 ? 'row' : 'rows'}</p>
        </div>
        {canWrite && <button className="primary" onClick={startAdd}>Add {ent.label}</button>}
      </header>
      {note && <p className="note">{note}</p>}
      {!editing && error && <p className="error" role="alert">{error}</p>}
      <div className="space-body">
        <div className="table-wrap">
          {rows.length === 0 ? <div className="empty"><p>No {ent.label} yet.</p></div> : (
            <table>
              <thead><tr><th>{ent.pkLabel}</th>{shown.map((c) => <th key={c.name}>{c.label}</th>)}</tr></thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r[ent.pk]} className={editing?.id === r[ent.pk] ? 'picked' : ''} onClick={() => startEdit(r)}
                    tabIndex={0} onKeyDown={(ev) => ev.key === 'Enter' && startEdit(r)}>
                    <td className="id">{short(r[ent.pk])}</td>
                    {shown.map((c) => <td key={c.name}>{String(cell(c, r))}</td>)}
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
        {editing && (
          <section className="form" aria-label={editing.id ? `Edit ${ent.label}` : `Add ${ent.label}`}>
            <h2>{!canWrite ? ent.label : editing.id ? `Edit ${ent.label}` : `Add ${ent.label}`}</h2>
            {editing.id && <p className="id-line">{ent.pkLabel}: {editing.id}</p>}
            <fieldset className="fields" disabled={!canWrite}>
              {ent.cols.filter((c) => c.expr && c.label && editing.id).map((c) => (
                <div key={c.name} className="field"><label>{c.label}</label><p className="readonly">{editing.values[c.name] || '—'}</p></div>
              ))}
              {ent.cols.filter((c) => !c.expr).map((c) => {
                const waiting = c.dependsOn && !editing.values[c.dependsOn];
                const parent = ent.cols.find((x) => x.name === c.dependsOn);
                return (
                  <div key={c.name}>
                    <Field col={c} value={editing.values[c.name]} statuses={meta.statuses} options={options(c)}
                      onChange={(v) => setValue(c.name, v)} />
                    {waiting && <p className="hint">Choose the {parent?.label || 'item above'} first</p>}
                  </div>
                );
              })}
            </fieldset>
            {error && <p className="error" role="alert">{error}</p>}
            <div className="actions">
              {canWrite && <button className="primary" onClick={save}>{editing.id ? 'Save changes' : `Add ${ent.label}`}</button>}
              <button className="quiet" onClick={() => setEditing(null)}>{canWrite ? 'Cancel' : 'Close'}</button>
              {canWrite && editing.id && <button className="danger" onClick={remove}>Delete</button>}
            </div>
          </section>
        )}
      </div>
    </>
  );
}
