export default function Field({ col, value, onChange, statuses, options }) {
  const id = `f-${col.name}`;
  const label = (
    <label htmlFor={id}>
      {col.label}
      {col.required && <span className="req"> *</span>}
    </label>
  );

  if (col.type === 'UUIDS') {
    const picked = value || [];
    return (
      <fieldset className="field">
        <legend>{col.label}</legend>
        {options.length === 0 && <p className="hint">Nothing to pick yet.</p>}
        {options.map((o) => (
          <label key={o.id} className="check">
            <input
              type="checkbox"
              checked={picked.includes(o.id)}
              onChange={(e) => onChange(e.target.checked ? [...picked, o.id] : picked.filter((x) => x !== o.id))}
            />
            {o.label}
          </label>
        ))}
      </fieldset>
    );
  }

  if (col.type === 'ENUMS') {
    const picked = value || [];
    return (
      <fieldset className="field">
        <legend>{col.label}</legend>
        {col.options.map((o) => (
          <label key={o} className="check">
            <input
              type="checkbox"
              checked={picked.includes(o)}
              onChange={(e) => onChange(e.target.checked ? [...picked, o] : picked.filter((x) => x !== o))}
            />
            {o}
          </label>
        ))}
      </fieldset>
    );
  }

  if (col.type === 'ENUM') {
    return (
      <div className="field">
        {label}
        <select id={id} value={value || col.options[0]} onChange={(e) => onChange(e.target.value)}>
          {col.options.map((o) => <option key={o}>{o}</option>)}
        </select>
      </div>
    );
  }

  if (col.ref) {
    return (
      <div className="field">
        {label}
        <select id={id} value={value || ''} onChange={(e) => onChange(e.target.value)}>
          <option value="">{col.required ? 'Choose…' : 'None'}</option>
          {options.map((o) => <option key={o.id} value={o.id}>{o.label}</option>)}
        </select>
      </div>
    );
  }

  if (col.type === 'STATUS') {
    return (
      <div className="field">
        {label}
        <select id={id} value={value || statuses[0]} onChange={(e) => onChange(e.target.value)}>
          {statuses.map((s) => <option key={s}>{s}</option>)}
        </select>
      </div>
    );
  }

  if (col.type === 'BOOL') {
    return (
      <label className="check field">
        <input id={id} type="checkbox" checked={!!value} onChange={(e) => onChange(e.target.checked)} />
        {col.label}
      </label>
    );
  }

  if (col.type === 'LONGTEXT') {
    return (
      <div className="field">
        {label}
        <textarea id={id} rows={3} value={value ?? ''} onChange={(e) => onChange(e.target.value)} />
      </div>
    );
  }

  const type = col.type === 'DATE' ? 'date' : col.type === 'INT' ? 'number' : 'text';
  return (
    <div className="field">
      {label}
      <input id={id} type={type} value={value ?? ''} onChange={(e) => onChange(e.target.value)} />
    </div>
  );
}
