import { useEffect, useState } from 'react';
import { api } from './api.js';
import { DomainPersonaDefinition } from './Personas.jsx';

// Catalogue inside the entity: Owned / Borrowed list, and the item page with its own side menu
export const ITEM_MENU = [['overview', 'Overview'], ['visibility', 'Visibility'], ['variants', 'Variants'], ['content', 'Content'],
  ['report', 'Report and Analytics'], ['marketing', 'Marketing'], ['journey', 'Journey & Dependencies'], ['seats', 'Seats']];

const CATALOGUES = ['Compliance', 'Process', 'Commercial'];
const CAT_PATH = { Compliance: 'Compliance', Process: 'Business › Process', Commercial: 'Business › Commercial' };
const RELEASES = ['Alpha', 'Pilot', 'Beta', 'General Availability'];
const PRICING = ['Fixed', 'Per unit', 'Per hour', 'Per sprint', 'Package', 'Request quote'];
const VARIANT_NAMES = { SKU: ['Single unit', 'Pack', 'Carton', 'Bulk'], SDU: ['Per unit', 'Bundle of 10', 'Monthly cap'],
  Services: ['Starter', 'Standard', 'Premium', 'Custom'] };
const SEATS = [['Buyer', 'Who buys or uses it.'], ['Seller', 'Who sells or offers it.'], ['Fulfiller', 'Who performs it: the entity or a vendor (ownership).'],
  ['Assurer', 'Who checks it was done right; never the Fulfiller.'], ['Representation', 'Who speaks for it to the other side.']];

const Release = ({ r }) => <span className="otag">{r}</span>;
const Review = ({ r }) => (r === 'Success' ? null : <span className="pill">{r === 'In review' ? 'In review' : 'Unpublished'}</span>);

// ---------- Screen 1: list ----------

export function CatalogueList({ entity, onOpen }) {
  const [c, setC] = useState(null);
  const [tab, setTab] = useState('Owned');
  const [cat, setCat] = useState('');
  const [adding, setAdding] = useState(false);
  const [msg, setMsg] = useState('');
  useEffect(() => { api.entityView(entity.entity_id, 'catalogue').then(setC).catch((e) => setMsg(e.message)); }, [entity.entity_id]);
  if (msg) return <div className="page"><p className="error" role="alert">{msg}</p></div>;
  if (!c) return <div className="page"><p className="hint">Loading…</p></div>;
  const rows = (tab === 'Owned' ? c.owned : c.borrowed).filter((r) => !cat || r.catalogue === cat);

  return (
    <div className="page">
      <div className="page-head">
        <div><h1 className="serif">Catalogue</h1><p className="sub">Everything your entity prices, and what you use from your vendors.</p></div>
        {c.can_edit && <button className="primary" onClick={() => setAdding(true)}>+ Add item</button>}
      </div>
      <div className="chips">
        {['Owned', 'Borrowed'].map((t) => <button key={t} className={tab === t ? 'chip on' : 'chip'} onClick={() => setTab(t)}>{t}</button>)}
        <span className="chip-gap" />
        {CATALOGUES.map((k) => <button key={k} className={cat === k ? 'chip on' : 'chip'} onClick={() => setCat(cat === k ? '' : k)}>{k}</button>)}
      </div>
      <div className="card table-card">
        <table className="ftable">
          <thead><tr><th>Item</th><th>Type</th><th>Catalogue</th><th>Visibility</th><th>Variants</th><th>Release</th></tr></thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.item_id} onClick={() => onOpen(r.item_id)}>
                <td><span className="strong">{r.name}</span><br /><span className="muted">Catalogue ID {r.code}{tab === 'Borrowed' ? ` · from ${r.entity_name}` : ''}</span></td>
                <td><span className="pill">{r.item_type}</span></td>
                <td>{r.catalogue}</td>
                <td>{r.visibility}</td>
                <td>{r.variants}</td>
                <td><div className="tag-col"><Release r={r.release} /><Review r={r.review} /></div></td>
              </tr>
            ))}
            {rows.length === 0 && <tr className="static"><td colSpan={6} className="sub">{tab === 'Owned' ? 'No items yet.' : 'No vendor has shared a catalogue with you yet.'}</td></tr>}
          </tbody>
        </table>
      </div>
      <p className="caption">Owned lists the entity's own items; Borrowed lists vendor catalogues shared with the entity.
        Items stay unpublished until their review (Share and Assign) closes as Success.</p>
      {adding && <AddItem entity={entity} c={c} onClose={(id) => { setAdding(false); if (id) onOpen(id); }} />}
    </div>
  );
}

function AddItem({ entity, c, onClose }) {
  const [f, setF] = useState({ catalogue: 'Commercial', from: 'domain', domain_id: '', domain_persona_id: '', library_item_id: '', library_use: 'As it is', item_type: 'Services', name: '' });
  const [q, setQ] = useState('');
  const [msg, setMsg] = useState('');
  const set = (k, v) => setF((x) => ({ ...x, [k]: v }));
  const domains = c.domains.filter((d) => d.catalogue === f.catalogue);
  const personas = domains.find((d) => d.domain_id === f.domain_id)?.personas || [];
  const persona = personas.find((p) => p.domain_persona_id === f.domain_persona_id);
  const fromLib = f.catalogue === 'Commercial' && f.from === 'library';
  const lib = c.library.find((l) => l.library_item_id === f.library_item_id);
  const hits = c.library.filter((l) => !q || `${l.name} ${l.metadata || ''}`.toLowerCase().includes(q.toLowerCase()));

  async function create() {
    setMsg('');
    try {
      const body = fromLib ? { catalogue: 'Commercial', library_item_id: f.library_item_id, library_use: f.library_use, name: f.library_use === 'Customised' ? f.name : '' }
        : { catalogue: f.catalogue, domain_persona_id: f.domain_persona_id, item_type: f.item_type, name: f.name };
      const r = await api.createItem(entity.entity_id, body);
      onClose(r.item_id);
    } catch (e) { setMsg(e.message); }
  }

  return (
    <div className="overlay" role="dialog" aria-modal="true">
      <div className="dialog wide">
        <div className="dialog-head"><h2 className="serif">Add item</h2><button className="x" onClick={() => onClose()}>×</button></div>
        <p className="sub">Only priced things are catalogue items. Steps inside the work, or unpriced documents, belong inside a Krama.</p>
        <label>Catalogue
          <select value={f.catalogue} onChange={(e) => setF({ ...f, catalogue: e.target.value, domain_id: '', domain_persona_id: '', from: 'domain' })}>
            {CATALOGUES.map((k) => <option key={k} value={k}>{CAT_PATH[k]}</option>)}
          </select>
        </label>
        {f.catalogue === 'Commercial' && (
          <div className="seg">
            <button className={f.from === 'domain' ? 'seg-btn on' : 'seg-btn'} onClick={() => set('from', 'domain')}>Catalogue domain</button>
            <button className={f.from === 'library' ? 'seg-btn on' : 'seg-btn'} onClick={() => set('from', 'library')}>Search the library</button>
          </div>
        )}
        {fromLib ? (
          <>
            <input placeholder="Search the library…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search the library" />
            <div className="pick-list">
              {hits.map((l) => (
                <button key={l.library_item_id} className={f.library_item_id === l.library_item_id ? 'pick on' : 'pick'} onClick={() => setF({ ...f, library_item_id: l.library_item_id, name: l.name })}>
                  <span className="strong">{l.name}</span> <span className="pill">{l.kind}</span><br /><span className="muted">{l.metadata}</span>
                </button>
              ))}
              {hits.length === 0 && <p className="hint">Nothing in the library matches.</p>}
            </div>
            {lib && (
              <div className="seg">
                {['As it is', 'Customised'].map((u) => <button key={u} className={f.library_use === u ? 'seg-btn on' : 'seg-btn'} onClick={() => set('library_use', u)}>{u === 'As it is' ? 'Use as it is' : 'Customise'}</button>)}
              </div>
            )}
            {lib && f.library_use === 'Customised' && <label>Name<input value={f.name} onChange={(e) => set('name', e.target.value)} /></label>}
          </>
        ) : (
          <>
            <label>Domain
              <select value={f.domain_id} onChange={(e) => setF({ ...f, domain_id: e.target.value, domain_persona_id: '' })}>
                <option value="">Choose…</option>{domains.map((d) => <option key={d.domain_id} value={d.domain_id}>{d.name}</option>)}
              </select>
            </label>
            <label>Domain persona
              <select value={f.domain_persona_id} disabled={!f.domain_id} onChange={(e) => {
                const p = personas.find((x) => x.domain_persona_id === e.target.value);
                setF({ ...f, domain_persona_id: e.target.value, name: f.name || p?.name || '' });
              }}>
                <option value="">Choose…</option>{personas.map((p) => <option key={p.domain_persona_id} value={p.domain_persona_id}>{p.name}</option>)}
              </select>
            </label>
            {persona?.metadata && <p className="hint">{persona.metadata}</p>}
            <div className="grid2">
              <label>Item type<select value={f.item_type} onChange={(e) => set('item_type', e.target.value)}>{['SKU', 'SDU', 'Services'].map((t) => <option key={t}>{t}</option>)}</select></label>
              <label>Name<input value={f.name} onChange={(e) => set('name', e.target.value)} /></label>
            </div>
          </>
        )}
        <p className="hint">The item starts in Alpha and stays unpublished until its review closes as Success.</p>
        {msg && <p className="error" role="alert">{msg}</p>}
        <div className="dialog-actions">
          <button className="quiet" onClick={() => onClose()}>Cancel</button>
          <button className="primary" disabled={fromLib ? !f.library_item_id : !f.domain_persona_id} onClick={create}>Add item</button>
        </div>
      </div>
    </div>
  );
}

// ---------- Screen 2: the item page ----------

export function CatalogueItem({ itemId, section }) {
  const [it, setIt] = useState(null);
  const [msg, setMsg] = useState('');
  const load = () => api.item(itemId).then(setIt).catch((e) => setMsg(e.message));
  useEffect(() => { load(); }, [itemId]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { if (msg) document.querySelector('.item-error')?.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); }, [msg]);
  const save = async (sec, body) => {
    setMsg('');
    try { const r = await api.saveSection(itemId, sec, body); await load(); return r; } catch (e) { setMsg(e.message); throw e; }
  };
  if (!it) return <div className="page">{msg ? <p className="error" role="alert">{msg}</p> : <p className="hint">Loading…</p>}</div>;
  const ro = !it.can_edit;
  const Body = { overview: Overview, visibility: Visibility, variants: Variants, content: Content, report: Report,
    marketing: Marketing, journey: Journey, seats: Seats }[section] || Overview;

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <h1 className="serif">{it.name}</h1>
          <p className="sub">Catalogue ID {it.code} · {it.item_type} · {it.catalogue}{it.owned ? '' : ` · Borrowed from ${it.entity_name}`}</p>
        </div>
        <div className="head-actions">
          {!ro && it.review === 'Not shared' && <button className="primary" onClick={() => save('share', {}).catch(() => {})}>Share and Assign</button>}
          {!ro && it.review === 'In review' && (
            <div className="inline">
              <span className="pill">In review</span>
              <button className="quiet" onClick={() => save('review-back', {}).catch(() => {})}>Send back</button>
              <button className="primary" onClick={() => save('review-success', {}).catch(() => {})}>Close review as Success</button>
            </div>
          )}
          {it.review === 'Success' && <span className="badge-coral">Published</span>}
        </div>
      </div>
      {ro && <p className="hint">{it.owned ? 'Only the entity super-user can change this item.' : 'A vendor\'s item, shared with you. Read only.'}</p>}
      {msg && <p className="error item-error" role="alert">{msg}</p>}
      <Body it={it} ro={ro} save={save} />
    </div>
  );
}

function Overview({ it, ro, save }) {
  const [name, setName] = useState(it.name);
  const fulfiller = it.seats.filter((s) => s.seat === 'Fulfiller');
  const owner = fulfiller.length === 0 ? 'Not set'
    : fulfiller[0].side === 'Internal' ? `Entity · ${fulfiller[0].name}` : `Vendor · ${fulfiller.map((s) => s.name).join(', ')}`;
  const lockedName = it.library_use === 'As it is';
  return (
    <>
      <div className="grid2 gap">
        <div className="card">
          <p className="field-l">Catalogue</p><p className="value">{CAT_PATH[it.catalogue]}</p>
          <p className="field-l">Domain</p><p className="value">{it.domain || 'Not set'}</p>
          <p className="field-l">Domain persona</p><p className="value">{it.domain_persona?.name || 'Not set'}</p>
          {it.domain_persona?.metadata && <p className="hint">{it.domain_persona.metadata}</p>}
          {it.domain_persona?.name && <DomainPersonaDefinition domain={it.domain} name={it.domain_persona.name} />}
          {it.library && <><p className="field-l">From the library</p>
            <p className="value">{it.library.name} · {it.library_use === 'Customised' ? 'Customised' : 'Used as it is'}
              {!ro && lockedName && <button className="link-inline" onClick={() => save('customise', {}).catch(() => {})}>Customise</button>}</p></>}
        </div>
        <div className="card">
          <p className="field-l">Item type</p><p className="value">{it.item_type}</p>
          <p className="field-l">Owner (Fulfiller seat)</p><p className="value">{owner}</p>
          <p className="field-l">Release</p>
          {ro ? <p className="value"><Release r={it.release} /></p> : (
            <select className="q-select" value={it.release} onChange={(e) => save('release', { release: e.target.value }).catch(() => {})} aria-label="Release">
              {RELEASES.map((r) => <option key={r}>{r}</option>)}
            </select>
          )}
          <p className="field-l">Review</p><p className="value">{it.review === 'Success' ? 'Success · published' : it.review}</p>
        </div>
      </div>
      {!ro && (
        <div className="card mt">
          <div className="inline">
            <label className="grow">Name<input value={name} disabled={lockedName} onChange={(e) => setName(e.target.value)} /></label>
            <button className="quiet" disabled={lockedName || name === it.name} onClick={() => save('overview', { name }).catch(() => {})}>Save</button>
          </div>
          {lockedName && <p className="hint">This item uses the library item as it is. Customise it to rename it.</p>}
        </div>
      )}
      <ItemKramas it={it} ro={ro} save={save} />
      <p className="caption">The Domain persona carries metadata only, never working data. Domains are platform owned and shared; the entity's own details decide what applies.</p>
    </>
  );
}

// The Kramas the item runs; when a task starts, the relationship and counterparty decide which one applies
function ItemKramas({ it, ro, save }) {
  const [pick, setPick] = useState('');
  const chosen = it.assignable.find((k) => k.id === pick);
  return (
    <div className="card mt">
      <h3 className="h3">Kramas this item runs</h3>
      {it.kramas.length === 0 && <p className="hint">None yet.</p>}
      {it.kramas.map((k) => (
        <div key={k.krama_id} className="item">
          <span className="value">{k.name} v{k.version}</span>
          <span className="muted">{k.external ? 'External' : 'Internal'} · {k.runs} run{k.runs === 1 ? '' : 's'}</span>
          {!ro && <button className="danger" onClick={() => save('krama-remove', { krama_id: k.krama_id }).catch(() => {})}>Remove</button>}
        </div>
      ))}
      {!ro && (
        <div className="inline mt">
          <select value={pick} onChange={(e) => setPick(e.target.value)} aria-label="Krama to assign">
            <option value="">{it.assignable.length ? 'Choose a Published Krama…' : 'No other Published Kramas in your pool'}</option>
            {it.assignable.map((k) => <option key={k.id} value={k.id}>{k.name}{k.used_on ? ` · also on ${k.used_on}` : ''}</option>)}
          </select>
          <button className="primary" disabled={!pick} onClick={async () => {
            try { await save('krama-assign', { krama_id: pick }); setPick(''); } catch { /* shown */ }
          }}>Assign</button>
        </div>
      )}
      {chosen?.used_on && <p className="hint">Already on {chosen.used_on}; one Krama can run for several items.</p>}
      <p className="hint mt">Removing a Krama stops new tasks from using it; tasks already started keep it. Platform Built Entity Owned Kramas are imported and published in Settings › Krama console first.</p>
    </div>
  );
}

function NamePicks({ options, picked, onChange, disabled }) {
  return (
    <div className="pick-grid">
      {options.map((o) => (
        <label key={o.id} className="check">
          <input type="checkbox" disabled={disabled} checked={picked.includes(o.id)}
            onChange={(e) => onChange(e.target.checked ? [...picked, o.id] : picked.filter((x) => x !== o.id))} />
          {o.name}{o.relationship ? <span className="muted"> · {o.relationship}</span> : ''}
        </label>
      ))}
    </div>
  );
}

function Visibility({ it, ro, save }) {
  const v = it.visibility;
  const [f, setF] = useState({ scope: v.scope || 'External', audience: v.audience || 'Client', reach: v.reach || 'Generic',
    names: v.names || [], host_dept_bu_id: v.host_dept_bu_id || '' });
  const set = (k, val) => setF((x) => (k === 'scope' && val !== x.scope
    ? { ...x, scope: val, audience: val === 'External' ? 'Client' : 'Internal client', reach: 'Generic', names: [] } : { ...x, [k]: val }));
  const ext = f.scope === 'External';
  const audiences = ext ? ['Discover and Connect', 'Client', 'Vendor'] : ['Internal client', 'Self'];
  const hasReach = ['Client', 'Vendor', 'Internal client'].includes(f.audience);
  const step = (label, opts, k, render = (o) => o) => (
    <div className="vis-step">
      <p className="field-l">{label}</p>
      <div className="seg">{opts.map((o) => <button key={o} disabled={ro} className={f[k] === o ? 'seg-btn on' : 'seg-btn'} onClick={() => set(k, o)}>{render(o)}</button>)}</div>
    </div>
  );
  return (
    <>
      <p className="value">Now: <span className="strong">{v.label}</span></p>
      <div className="card mt">
        {step('Who sees it', ['External', 'Internal'], 'scope')}
        {!ext && (
          <div className="vis-step">
            <p className="field-l">Host: the one Dept/BU that owns it</p>
            <select className="q-select" disabled={ro} value={f.host_dept_bu_id} onChange={(e) => set('host_dept_bu_id', e.target.value)} aria-label="Host">
              <option value="">Choose…</option>{it.dept_bus.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
            </select>
          </div>
        )}
        {step(ext ? 'Where' : 'For whom', audiences, 'audience', (o) => ({ Client: 'Client (sell side)', Vendor: 'Vendor (buy side)', Self: 'Self (host only)' }[o] || o))}
        {hasReach && step(ext ? 'Which ones' : 'Which Dept/BUs', ['Generic', 'Customised'], 'reach',
          (o) => (o === 'Generic' ? (ext ? 'Generic (all)' : 'All Dept/BUs') : 'Customised (by name)'))}
        {hasReach && f.reach === 'Customised' && (
          <NamePicks disabled={ro} picked={f.names} onChange={(n) => set('names', n)} options={ext ? it.entities : it.dept_bus} />
        )}
        {!ro && <div className="inline mt"><button className="primary" onClick={() => save('visibility', f).catch(() => {})}>Save visibility</button></div>}
      </div>
      <ul className="notes">
        <li>Customising changes who sees the item, not its Krama.</li>
        <li>External items reach Discover and Connect only through the entity's platform website; internal items never go through the website.</li>
        {ext && <li>Customised names include pre-clients and pre-vendors.</li>}
      </ul>
    </>
  );
}

function Variants({ it, ro, save }) {
  const [open, setOpen] = useState(it.variants.length === 1 ? it.variants[0].variant_id : '');
  const [nv, setNv] = useState({ name: '', copy_from: '' });
  const names = VARIANT_NAMES[it.item_type] || [];
  return (
    <>
      <p className="sub">Settings that apply to every variant sit on this page; everything variant-specific sits inside each variant.</p>
      <div className="card mt">
        <p className="field-l">Applies to every variant</p>
        <p className="value">{it.item_type} · {CAT_PATH[it.catalogue]} · {it.visibility.label}</p>
      </div>
      {it.variants.map((v) => (
        <div key={v.variant_id} className="card mt">
          <button className="row-btn" onClick={() => setOpen(open === v.variant_id ? '' : v.variant_id)}>
            <span className="strong">{v.name}</span>
            <span className="muted">{v.pricing_type}{v.price != null ? ` · ${Number(v.price).toLocaleString('en-IN')}` : ''} {v.pricing_type !== 'Request quote' ? `· ${v.tax_mode}` : ''}</span>
            {v.offer_kind && <span className="otag">Offer {v.offer_kind === '%' ? `${v.offer_amount}%` : Number(v.offer_amount).toLocaleString('en-IN')}</span>}
            <span className="push muted">{open === v.variant_id ? 'Close' : 'Open'}</span>
          </button>
          {open === v.variant_id && <VariantForm key={v.variant_id} v={v} it={it} ro={ro} save={save} />}
        </div>
      ))}
      {!ro && (
        <div className="card mt">
          <p className="field-l">+ Add variant</p>
          <div className="inline">
            <input list="variant-names" placeholder={`Name, e.g. ${names[0] || 'Standard'}`} value={nv.name} onChange={(e) => setNv({ ...nv, name: e.target.value })} aria-label="Variant name" />
            <datalist id="variant-names">{names.map((n) => <option key={n} value={n} />)}</datalist>
            <select value={nv.copy_from} onChange={(e) => setNv({ ...nv, copy_from: e.target.value })} aria-label="Copy from">
              <option value="">Start blank</option>{it.variants.map((v) => <option key={v.variant_id} value={v.variant_id}>Copy from {v.name}</option>)}
            </select>
            <button className="primary" disabled={!nv.name.trim()} onClick={async () => {
              try { const r = await save('variant', nv); setNv({ name: '', copy_from: '' }); if (r?.id) setOpen(r.id); } catch { /* shown */ }
            }}>Add</button>
          </div>
        </div>
      )}
    </>
  );
}

function VariantForm({ v, it, ro, save }) {
  const [f, setF] = useState({ ...v, price: v.price ?? '', gst_rate: v.gst_rate ?? '', offer_amount: v.offer_amount ?? '', offer_kind: v.offer_kind || '',
    offer_until: v.offer_until || '', hsn_sac: v.hsn_sac || '', quotation_wording: v.quotation_wording || '', invoice_wording: v.invoice_wording || '', promo: v.promo || '' });
  const set = (k, val) => setF((x) => ({ ...x, [k]: val }));
  const quote = f.pricing_type === 'Request quote';
  const clients = it.entities.filter((e) => !e.relationship || /client/i.test(e.relationship));
  return (
    <div className="mini-form mt">
      <div className="grid3">
        <label>Name<input disabled={ro} value={f.name} onChange={(e) => set('name', e.target.value)} /></label>
        <label>Pricing type<select disabled={ro} value={f.pricing_type} onChange={(e) => set('pricing_type', e.target.value)}>{PRICING.map((p) => <option key={p}>{p}</option>)}</select></label>
        {!quote && <label>Price<input disabled={ro} type="number" min="0" value={f.price} onChange={(e) => set('price', e.target.value)} /></label>}
        {!quote && <label>Tax<select disabled={ro} value={f.tax_mode} onChange={(e) => set('tax_mode', e.target.value)}><option>+ tax</option><option>tax included</option></select></label>}
        <label>HSN/SAC<input disabled={ro} value={f.hsn_sac} onChange={(e) => set('hsn_sac', e.target.value)} /></label>
        <label>GST rate (%)<select disabled={ro} value={String(f.gst_rate === '' ? '' : Number(f.gst_rate))} onChange={(e) => set('gst_rate', e.target.value)}>
          <option value="">—</option>{[0, 5, 12, 18, 28].map((g) => <option key={g} value={String(g)}>{g}%</option>)}</select></label>
      </div>
      <div className="grid2">
        <label>Quotation wording<textarea rows={2} disabled={ro} value={f.quotation_wording} onChange={(e) => set('quotation_wording', e.target.value)} /></label>
        <label>Invoice wording<textarea rows={2} disabled={ro} value={f.invoice_wording} onChange={(e) => set('invoice_wording', e.target.value)} /></label>
      </div>
      <p className="field-l">Offer (one at a time)</p>
      <div className="grid3">
        <label>How much<select disabled={ro} value={f.offer_kind} onChange={(e) => set('offer_kind', e.target.value)}><option value="">No offer</option><option value="%">%</option><option value="Fixed">Fixed amount</option></select></label>
        {f.offer_kind && <label>Amount<input disabled={ro} type="number" min="0" value={f.offer_amount} onChange={(e) => set('offer_amount', e.target.value)} /></label>}
        {f.offer_kind && <label>For whom<select disabled={ro} value={f.offer_for} onChange={(e) => set('offer_for', e.target.value)}><option>Everyone</option><option>Named clients</option></select></label>}
        {f.offer_kind && <label>Until (optional)<input disabled={ro} type="date" value={f.offer_until} onChange={(e) => set('offer_until', e.target.value)} /></label>}
      </div>
      {f.offer_kind && f.offer_for === 'Named clients' && <NamePicks disabled={ro} picked={f.offer_names || []} onChange={(n) => set('offer_names', n)} options={clients} />}
      <label>Promo<input disabled={ro} placeholder="The offer in words, or Not applicable" value={f.promo} onChange={(e) => set('promo', e.target.value)} /></label>
      <p className="hint">Journey and Dependencies for this variant are set in Journey &amp; Dependencies.</p>
      {!ro && (
        <div className="inline">
          <button className="primary" onClick={() => save('variant', { ...f, offer_names: f.offer_names || [] }).catch(() => {})}>Save variant</button>
          {it.variants.length > 1 && <button className="danger" onClick={() => save('variant-remove', { variant_id: v.variant_id }).catch(() => {})}>Remove variant</button>}
        </div>
      )}
    </div>
  );
}

function Content({ it, ro, save }) {
  const [f, setF] = useState({ title: it.content.title || '', main_image: it.content.main_image || '', blocks: it.content.blocks || [] });
  const setBlock = (i, b) => setF((x) => ({ ...x, blocks: x.blocks.map((y, j) => (j === i ? b : y)) }));
  const move = (i, d) => setF((x) => { const b = [...x.blocks]; const [y] = b.splice(i, 1); b.splice(i + d, 0, y); return { ...x, blocks: b }; });
  return (
    <>
      <p className="sub">Material only, at item level (not per variant). How it looks is decided by the website.</p>
      <div className="mini-form mt">
        <div className="grid2">
          <label>Title<input disabled={ro} value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></label>
          <label>Catalogue ID<input disabled value={it.code} /></label>
        </div>
        <label>Main image (file name or link)<input disabled={ro} value={f.main_image} onChange={(e) => setF({ ...f, main_image: e.target.value })} /></label>
        {f.blocks.map((b, i) => (
          <div key={i} className="block-row">
            <select disabled={ro} value={b.kind} onChange={(e) => setBlock(i, { ...b, kind: e.target.value })} aria-label="Block kind">{['Text', 'Image', 'Video'].map((k) => <option key={k}>{k}</option>)}</select>
            {b.kind === 'Text' ? <textarea rows={3} disabled={ro} value={b.body} onChange={(e) => setBlock(i, { ...b, body: e.target.value })} aria-label="Text" />
              : <input disabled={ro} placeholder={`${b.kind} file name or link`} value={b.body} onChange={(e) => setBlock(i, { ...b, body: e.target.value })} aria-label={b.kind} />}
            {!ro && <div className="block-tools">
              <button className="quiet sm" disabled={i === 0} onClick={() => move(i, -1)} aria-label="Move up">↑</button>
              <button className="quiet sm" disabled={i === f.blocks.length - 1} onClick={() => move(i, 1)} aria-label="Move down">↓</button>
              <button className="quiet sm" onClick={() => setF({ ...f, blocks: f.blocks.filter((_, j) => j !== i) })} aria-label="Remove block">×</button>
            </div>}
          </div>
        ))}
        {!ro && (
          <div className="inline">
            {['Text', 'Image', 'Video'].map((k) => <button key={k} className="quiet" onClick={() => setF({ ...f, blocks: [...f.blocks, { kind: k, body: '' }] })}>+ Add {k.toLowerCase()}</button>)}
            <button className="primary push" onClick={() => save('content', f).catch(() => {})}>Save content</button>
          </div>
        )}
      </div>
    </>
  );
}

function Report({ it }) {
  const live = it.runs.total > 0;
  // Synthetic data shows as a preview until live data exists
  const synthetic = it.visibility.scope === 'Internal' ? [{ relationship: 'Department', n: 24 }]
    : it.visibility.audience === 'Vendor' ? [{ relationship: 'Vendor', n: 20 }, { relationship: 'Pre-vendor', n: 4 }]
    : [{ relationship: 'Client', n: 18 }, { relationship: 'Pre-client', n: 6 }];
  const r = live ? it.runs : { total: 24, open: 6, fulfilled: 16, unfulfilled: 2, last: null, by_relationship: synthetic };
  return (
    <>
      <div className="inline"><p className="field-l">Focus · this item only</p>{!live && <span className="pill">Preview · synthetic data</span>}</div>
      <div className={live ? 'stat-row' : 'stat-row preview'}>
        {[['Runs', r.total], ['Open', r.open], ['Fulfilled', r.fulfilled], ['Unfulfilled', r.unfulfilled]].map(([l, n]) => (
          <div key={l} className="card"><p className="field-l">{l}</p><p className="stat-num">{n}</p></div>
        ))}
      </div>
      <div className="grid2 gap">
        <div className="card">
          <h3 className="h3">Sales performance</h3>
          {r.by_relationship.map((b) => <p key={b.relationship} className="value">{b.relationship}: {b.n} run{b.n === 1 ? '' : 's'}</p>)}
          {r.last && <p className="hint">Last started {r.last}</p>}
        </div>
        <div className="card">
          <h3 className="h3">Reports</h3>
          {it.kramas.length === 0 && <p className="hint">Reports come from the item's Kramas. Assign one in Settings › Krama.</p>}
          {it.kramas.map((k) => (
            <div key={k.krama_id} className="report-tree">
              <p className="strong">{k.name} v{k.version}</p>
              {k.stages.map((s) => (
                <div key={s.name} className="rt-stage"><p className="value">{s.name}</p>
                  {s.topics.map((t) => <p key={t.name} className="rt-topic muted">{t.name} · {t.questions} question{t.questions === 1 ? '' : 's'}</p>)}
                </div>
              ))}
              {k.reports.map((q) => <p key={q.name} className="rt-q"><span className="ink">{q.name}</span> · {q.question}</p>)}
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

function Marketing({ it, ro, save }) {
  const m = it.marketing;
  const [url, setUrl] = useState(m.landing_status === 'External page' ? m.landing_page || '' : '');
  const [f, setF] = useState({ brand_name: m.brand_name || '', category: m.category || '', sub_category: m.sub_category || '', competitors: m.competitors || [] });
  const setComp = (i, k, v) => setF((x) => ({ ...x, competitors: x.competitors.map((c, j) => (j === i ? { ...c, [k]: v } : c)) }));
  return (
    <>
      <div className="card">
        <h3 className="h3">Landing page</h3>
        <p className="value">{!m.landing_status ? 'None yet.' : m.landing_status === 'Generated' ? 'Generated · waiting for approval.'
          : <>{m.landing_status === 'Approved' ? 'Approved · campaign link' : 'Page built outside'}: <a href={m.landing_page} target="_blank" rel="noreferrer">{m.landing_page}</a></>}</p>
        {!ro && (
          <div className="inline mt">
            {m.landing_status !== 'Generated' && <button className="quiet" onClick={() => save('landing-generate', {}).catch(() => {})}>Generate inside the catalogue</button>}
            {m.landing_status === 'Generated' && <button className="primary" onClick={() => save('landing-approve', {}).catch(() => {})}>Approve and get the link</button>}
            <input placeholder="https://… (a page built outside)" value={url} onChange={(e) => setUrl(e.target.value)} aria-label="Landing page address" />
            <button className="quiet" disabled={!url.trim()} onClick={() => save('landing-external', { url }).catch(() => {})}>Use this address</button>
          </div>
        )}
        <p className="hint">Campaign clicks land on the item.</p>
      </div>
      <div className="mini-form mt">
        <div className="grid3">
          <label>Brand name<input disabled={ro} value={f.brand_name} onChange={(e) => setF({ ...f, brand_name: e.target.value })} /></label>
          <label>Category<input disabled={ro} value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })} /></label>
          <label>Sub-category<input disabled={ro} value={f.sub_category} onChange={(e) => setF({ ...f, sub_category: e.target.value })} /></label>
        </div>
        <p className="field-l">Competitors</p>
        {f.competitors.map((c, i) => (
          <div key={i} className="grid3 comp-row">
            <input disabled={ro} placeholder="Brand name" value={c.brand || ''} onChange={(e) => setComp(i, 'brand', e.target.value)} aria-label="Competitor brand" />
            <input disabled={ro} placeholder="Business name" value={c.business || ''} onChange={(e) => setComp(i, 'business', e.target.value)} aria-label="Competitor business" />
            <div className="inline">
              <input disabled={ro} placeholder="Website" value={c.website || ''} onChange={(e) => setComp(i, 'website', e.target.value)} aria-label="Competitor website" />
              {!ro && <button className="quiet sm" onClick={() => setF({ ...f, competitors: f.competitors.filter((_, j) => j !== i) })} aria-label="Remove competitor">×</button>}
            </div>
          </div>
        ))}
        {!ro && (
          <div className="inline">
            <button className="quiet" onClick={() => setF({ ...f, competitors: [...f.competitors, { brand: '', business: '', website: '' }] })}>+ Competitor</button>
            <button className="primary push" onClick={() => save('marketing', f).catch(() => {})}>Save marketing</button>
          </div>
        )}
      </div>
    </>
  );
}

function journeySteps(it) {
  const v = it.visibility;
  if (v.scope === 'Internal') return ['Process'];
  if (v.audience === 'Vendor') return ['Deal', 'Order management'];
  if (v.scope === 'External') return ['Opportunity', 'Order management'];
  return [];
}

function Journey({ it, ro, save }) {
  const steps = journeySteps(it);
  const side = it.visibility.scope === 'Internal' ? 'Internal: Process, run by the Host'
    : it.visibility.audience === 'Vendor' ? 'Buy side: Deal → Order management (through Borrowed items)'
    : it.visibility.scope === 'External' ? 'Sell side: Opportunity → Order management' : '';
  return (
    <>
      <p className="sub">{side || 'Set Visibility first: the journey follows the side the item sits on.'}</p>
      {it.variants.map((v) => <JourneyRow key={v.variant_id} v={v} it={it} ro={ro} save={save} steps={steps} />)}
      <ul className="notes">
        <li>Dependencies run before or after, never block, and can be marked "done outside the platform".</li>
        <li>Catalogue-level picks list Beta and General Availability items only.</li>
        <li>Anything closed, won or lost, moves to Archives.</li>
      </ul>
    </>
  );
}

function JourneyRow({ v, it, ro, save, steps }) {
  const [d, setD] = useState({ level: 'Krama', ref_id: '', timing: 'Before', done_outside: false });
  const at = (s) => v.journey.find((j) => j.step === s);
  const refs = d.level === 'Krama' ? it.pick_kramas : it.pick_items;
  return (
    <div className="card mt">
      <p className="strong">{v.name}</p>
      {steps.length > 0 && (
        <div className="journey">
          {steps.map((s, i) => (
            <div key={s} className="j-step">
              {i > 0 && <span className="muted">→</span>}
              <div><p className="field-l">{s}</p>
                {ro ? <p className="value">{at(s)?.krama || 'Not set'}</p> : (
                  <select className="q-select" value={at(s)?.krama_id || ''} onChange={(e) => save('journey', { variant_id: v.variant_id, step: s, krama_id: e.target.value }).catch(() => {})} aria-label={`${s} Krama`}>
                    <option value="">Not set</option>{it.pick_kramas.map((k) => <option key={k.id} value={k.id}>{k.name}</option>)}
                  </select>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
      <p className="field-l mt">Dependencies</p>
      {v.dependencies.length === 0 && <p className="hint">None.</p>}
      {v.dependencies.map((x) => (
        <div key={x.dependency_id} className="item">
          <span className="pill">{x.timing}</span><span>{x.level === 'Krama' ? 'Flow' : 'Item'}: {x.name}</span>
          <label className="check"><input type="checkbox" disabled={ro} checked={x.done_outside}
            onChange={(e) => save('dependency-outside', { dependency_id: x.dependency_id, done_outside: e.target.checked }).catch(() => {})} />done outside the platform</label>
          {!ro && <button className="danger" onClick={() => save('dependency-remove', { dependency_id: x.dependency_id }).catch(() => {})}>Remove</button>}
        </div>
      ))}
      {!ro && (
        <div className="inline mt">
          <select value={d.timing} onChange={(e) => setD({ ...d, timing: e.target.value })} aria-label="Before or after"><option>Before</option><option>After</option></select>
          <select value={d.level} onChange={(e) => setD({ ...d, level: e.target.value, ref_id: '' })} aria-label="Level">
            <option value="Krama">Krama level (another flow)</option><option value="Catalogue">Catalogue level (another item)</option></select>
          <select value={d.ref_id} onChange={(e) => setD({ ...d, ref_id: e.target.value })} aria-label="Dependency">
            <option value="">{refs.length ? 'Choose…' : d.level === 'Catalogue' ? 'No Beta or General Availability items' : 'No Published Kramas'}</option>
            {refs.map((r) => <option key={r.id} value={r.id}>{r.name}{r.release ? ` · ${r.release}` : ''}</option>)}
          </select>
          <label className="check"><input type="checkbox" checked={d.done_outside} onChange={(e) => setD({ ...d, done_outside: e.target.checked })} />done outside</label>
          <button className="quiet" disabled={!d.ref_id} onClick={async () => {
            try { await save('dependency', { ...d, variant_id: v.variant_id }); setD({ ...d, ref_id: '', done_outside: false }); } catch { /* shown */ }
          }}>+ Dependency</button>
        </div>
      )}
    </div>
  );
}

function Seats({ it, ro, save }) {
  return (
    <>
      <p className="sub">Five seats, one person or party per seat. Internal → a Dept/BU; External → a client or vendor by name, including pre-clients and pre-vendors.</p>
      {SEATS.map(([s, why]) => <SeatRow key={s} seat={s} why={why} it={it} ro={ro} save={save} />)}
      <ul className="notes">
        <li>The Fulfiller seat shows ownership: the entity or a vendor. Mapping one item to several vendors creates a quote comparison.</li>
        <li>The Assurer is never the Fulfiller on the same item. Outsourcing moves performance, never accountability.</li>
      </ul>
    </>
  );
}

function SeatRow({ seat, why, it, ro, save }) {
  const held = it.seats.filter((s) => s.seat === seat);
  const [f, setF] = useState({ side: 'Internal', ref_id: '', vendor_item_id: '' });
  const [adding, setAdding] = useState(false);
  const ent = it.entities.find((e) => e.id === f.ref_id);
  const vendors = held.filter((h) => h.side === 'External');
  return (
    <div className="card mt seat-row">
      <div className="seat-head">
        <div><p className="strong">{seat}</p><p className="hint">{why}</p></div>
        <div className="seat-held">
          {held.length === 0 && <span className="muted">Empty</span>}
          {held.map((h) => (
            <span key={h.catalogue_seat_id} className="pill">
              {h.side === 'Internal' ? 'Dept/BU' : 'Entity'} · {h.name}{h.vendor_item ? ` · mapped to ${h.vendor_item}` : ''}
              {!ro && <button className="pill-x" onClick={() => save('seat-remove', { catalogue_seat_id: h.catalogue_seat_id }).catch(() => {})} aria-label={`Remove ${h.name}`}>×</button>}
            </span>
          ))}
          {seat === 'Fulfiller' && vendors.length > 1 && <span className="otag">Quote comparison · {vendors.length} vendors</span>}
          {!ro && !adding && <button className="quiet sm" onClick={() => setAdding(true)}>{held.length && !(seat === 'Fulfiller' && vendors.length) ? 'Change' : '+ Add'}</button>}
        </div>
      </div>
      {adding && (
        <div className="inline mt">
          <select value={f.side} onChange={(e) => setF({ side: e.target.value, ref_id: '', vendor_item_id: '' })} aria-label="Internal or External"><option>Internal</option><option>External</option></select>
          <select value={f.ref_id} onChange={(e) => setF({ ...f, ref_id: e.target.value, vendor_item_id: '' })} aria-label={f.side === 'Internal' ? 'Dept/BU' : 'Client or vendor'}>
            <option value="">Choose…</option>
            {(f.side === 'Internal' ? it.dept_bus : it.entities).map((o) => <option key={o.id} value={o.id}>{o.name}{o.relationship ? ` · ${o.relationship}` : ''}</option>)}
          </select>
          {seat === 'Fulfiller' && f.side === 'External' && ent && (
            <select value={f.vendor_item_id} onChange={(e) => setF({ ...f, vendor_item_id: e.target.value })} aria-label="Vendor's item">
              <option value="">{ent.items.length ? "Map the vendor's item…" : 'Vendor has no published items'}</option>
              {ent.items.map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}
            </select>
          )}
          <button className="primary" disabled={!f.ref_id} onClick={async () => {
            try { await save('seat', { ...f, seat }); setAdding(false); setF({ side: 'Internal', ref_id: '', vendor_item_id: '' }); } catch { /* shown */ }
          }}>Save</button>
          <button className="quiet" onClick={() => setAdding(false)}>Cancel</button>
        </div>
      )}
    </div>
  );
}
