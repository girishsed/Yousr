import { useEffect, useState } from 'react';
import { api, getActingUser } from './api.js';
import { AnswerForm, AnswerView } from './Answer.jsx';

const ROOM_NAMES = { PR: 'Private', IR: 'Internal', ER: 'External' };
const KIND_RANK = { PR: 1, IR: 2, ER: 3 };
const PATH_RANK = { 'PR only': 1, 'PR → IR': 2, 'PR → IR → ER': 3 };

export default function Runs({ focus, people, meta, onAudit }) {
  const [runs, setRuns] = useState([]);
  const [runId, setRunId] = useState(focus?.runId || '');
  const [tree, setTree] = useState(null);
  const [tab, setTab] = useState('overview');
  const [msg, setMsg] = useState('');

  const loadRuns = () => api.runs().then((r) => { setRuns(r); if (!runId && r.length) setRunId(r[0].run_id); });
  const loadTree = async (id = runId) => {
    if (!id) return;
    try { setTree(await api.run(id)); setMsg(''); } catch (e) { setTree(null); setMsg(e.message); }
  };
  useEffect(() => { loadRuns(); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { loadTree(); }, [runId]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    // open the room holding a focused question
    if (tree && focus?.qrId) {
      for (const s of tree.stages) for (const t of s.topics) for (const q of t.questions) {
        if (q.qr_id === focus.qrId) setTab(q.ask_in);
      }
    }
  }, [tree]); // eslint-disable-line react-hooks/exhaustive-deps

  const refresh = async () => { await loadTree(); setRuns(await api.runs()); };

  return (
    <div className="runs">
      <div className="run-list" role="list">
        {runs.length === 0 && <p className="hint">You are not seated in any run yet. Start one from the Catalogue.</p>}
        {runs.map((r) => (
          <button key={r.run_id} role="listitem" className={r.run_id === runId ? 'run-card on' : 'run-card'}
            onClick={() => { setRunId(r.run_id); setTab('overview'); }}>
            <span className="run-title">{r.item}</span>
            <span className="run-meta">{r.label} · {r.fy}</span>
            <span className="run-meta">{r.entity_name}{r.counterparty_name ? ` with ${r.counterparty_name}` : ''}</span>
            <span className="tag"><span className="st">{r.locked ? 'Conserved' : r.status}</span>{r.result && <span className={`oc oc-${r.result}`}>{r.result}</span>}</span>
          </button>
        ))}
      </div>
      <div className="tree">
        {msg && <p className="error" role="alert">{msg}</p>}
        {tree && <RunScreen tree={tree} tab={tab} setTab={setTab} people={people} meta={meta} onDone={refresh} onAudit={onAudit} focusQr={focus?.qrId} />}
      </div>
    </div>
  );
}

function useAction(onDone) {
  const [msg, setMsg] = useState('');
  const run = async (fn) => { setMsg(''); try { await fn(); await onDone(); } catch (e) { setMsg(e.message); } };
  return [msg, run];
}

function RunScreen({ tree, tab, setTab, people, meta, onDone, onAudit, focusQr }) {
  const [msg, run] = useAction(onDone);
  const myRooms = tree.rooms.filter((r) => r.member || tree.is_super);
  return (
    <div className="run-screen">
      <div className="run-head">
        <div>
          <h2>{tree.item} <span className="run-meta">{tree.label}</span></h2>
          <p className="run-meta">
            {tree.krama} v{tree.version} · {tree.fy} · Requestor/Conductor {tree.requestor_name}
            {tree.counterparty_name ? ` · with ${tree.counterparty_name} as ${tree.relationship}${tree.counterparty_persona ? ` (${tree.counterparty_persona})` : ''}` : tree.relationship ? ` · ${tree.relationship}` : ''}
          </p>
          <p className="tag"><span className="st">{tree.locked ? 'Conserved' : tree.status}</span>{tree.result && <span className={`oc oc-${tree.result}`}>{tree.result}</span>}</p>
        </div>
        <div className="inline">
          {(tree.is_requestor || tree.is_super) && <button className="quiet" onClick={() => onAudit(tree.run_id)}>History and audit</button>}
          {tree.is_requestor && tree.locked && <button className="primary" onClick={() => run(() => api.amend(tree.run_id))}>Amend</button>}
        </div>
      </div>
      {msg && <p className="error" role="alert">{msg}</p>}
      <div className="tabs" role="tablist">
        <button role="tab" className={tab === 'overview' ? 'tab on' : 'tab'} onClick={() => setTab('overview')}>Overview</button>
        {myRooms.map((r) => (
          <button key={r.kind} role="tab" className={tab === r.kind ? 'tab on' : 'tab'} onClick={() => setTab(r.kind)}
            title={`${ROOM_NAMES[r.kind]}: ${r.name}`}>
            <span className={`room-icon room-${r.kind}`}>{r.kind}</span> {r.name}
          </button>
        ))}
      </div>
      {tab === 'overview' ? <Overview tree={tree} people={people} meta={meta} onDone={onDone} />
        : <RoomView tree={tree} room={tree.rooms.find((r) => r.kind === tab)} meta={meta} onDone={onDone} focusQr={focusQr} />}
    </div>
  );
}

function Overview({ tree, people, meta, onDone }) {
  return (
    <div className="panel">
      <div className="section">
        <h4>Rooms</h4>
        <table>
          <thead><tr><th>Room</th><th>Open</th><th>Closed · Success</th><th>Closed · Dropped</th><th>Cancelled</th></tr></thead>
          <tbody>
            {tree.overview.map((o) => (
              <tr key={o.kind} className="static"><td><span className={`room-icon room-${o.kind}`}>{o.kind}</span> {o.name}</td>
                <td>{o.open}</td><td>{o.success}</td><td>{o.dropped}</td><td>{o.cancelled}</td></tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="section">
        <h4>Report and Analytics</h4>
        {tree.reports.map((r) => <p key={r.name}><strong>{r.name}</strong> <span className="hint">{r.question_text}</span></p>)}
      </div>
      <div className="section">
        <h4>Stages</h4>
        {tree.stages.map((s) => (
          <div key={s.stage_id} className="item">
            <span>{s.name}</span><span className="hint">{s.path}</span><span className="st">{s.status}</span>
            {s.my_seats.length > 0 && <span className="badge">Your seat: {s.my_seats.join(', ')}</span>}
          </div>
        ))}
      </div>
      <Seats tree={tree} meta={meta} onDone={onDone} />
      <div className="section">
        <h4>People in rooms</h4>
        {tree.rooms.map((r) => (
          <p key={r.kind}><span className={`room-icon room-${r.kind}`}>{r.kind}</span> {r.members.map((m) => m.name + (m.spoc ? ' (SPOC)' : '')).join(', ') || '—'}</p>
        ))}
      </div>
    </div>
  );
}

// People relevant to this instance only, grouped by entity (this entity first, then the counterparty)
export function PersonSelect({ value, onChange, options, placeholder, empty }) {
  const groups = [];
  options.forEach((o) => {
    let g = groups.find((x) => x.entity === o.entity);
    if (!g) { g = { entity: o.entity, people: [] }; groups.push(g); }
    g.people.push(o);
  });
  return (
    <select value={value} onChange={(e) => onChange(e.target.value)} aria-label="Person">
      <option value="">{options.length ? placeholder : empty}</option>
      {groups.map((g) => (
        <optgroup key={g.entity} label={g.entity}>
          {g.people.map((o) => <option key={o.user_id} value={o.user_id}>{o.name}{o.dept ? ` · ${o.dept}` : ''}</option>)}
        </optgroup>
      ))}
    </select>
  );
}

export function Seats({ tree, meta, onDone }) {
  const [msg, run] = useAction(onDone);
  const [f, setF] = useState({ stage_id: tree.stages[0]?.stage_id || '', seat: meta.seats[0], person_id: '' });
  const [onlyMatching, setOnlyMatching] = useState(true);
  const stage = tree.stages.find((s) => s.stage_id === f.stage_id);
  const needs = (stage?.expertise || []).map((e) => e.expertise_id);
  const match = (p) => (p.expertise_ids || []).some((x) => needs.includes(x));
  const people = stage?.candidates || [];
  const offered = needs.length && onlyMatching ? people.filter(match) : people;
  const stageName = (id) => tree.stages.find((s) => s.stage_id === id)?.name || '';
  const fitData = useSeatFit(tree.run_id, tree.seats.length);
  const fitOf = (seatId) => fitData?.seats.find((x) => x.seat_id === seatId)?.fit;
  const fitting = (fitData?.candidates || []).filter((c) => c.stage_id === f.stage_id && c.seat === f.seat && c.fit.matches);
  return (
    <div className="section">
      <h4>Seats</h4>
      {tree.seats.length === 0 && <p className="hint">No one seated yet.</p>}
      {tree.seats.map((s) => (
        <div key={s.seat_id} className="item">
          <span>{s.person_name}</span><span className="hint">{s.seat} · {stageName(s.stage_id)}</span>
          {fitOf(s.seat_id) && !fitOf(s.seat_id).matches && <span className="ink">does not match the persona needed</span>}
          {tree.is_requestor && !tree.locked && <button className="danger" onClick={() => run(() => api.unseat(s.seat_id))}>Remove</button>}
        </div>
      ))}
      {tree.is_requestor && !tree.locked && (
        <div className="mini-form">
          {fitting.length > 0 && <p className="hint">Matches the persona needed for {f.seat}: {fitting.map((c) => `${c.name} (${c.fit.matched.join(', ')})`).join(' · ')}</p>}
          <div className="grid2">
            <label>Stage
              <select value={f.stage_id} onChange={(e) => setF({ ...f, stage_id: e.target.value })}>
                {tree.stages.map((s) => <option key={s.stage_id} value={s.stage_id}>{s.name}</option>)}
              </select>
            </label>
            <label>Seat
              <select value={f.seat} onChange={(e) => setF({ ...f, seat: e.target.value })}>
                {meta.seats.map((s) => <option key={s}>{s}</option>)}
              </select>
            </label>
          </div>
          {stage && stage.expertise.length > 0 && (
            <>
              <p className="hint">Expertise for this stage: {stage.expertise.map((e) => `${e.name} (${e.mapped_as})`).join(', ')}</p>
              <label className="check"><input type="checkbox" checked={onlyMatching} onChange={(e) => setOnlyMatching(e.target.checked)} />Only matching expertise</label>
            </>
          )}
          <div className="inline">
            <PersonSelect value={f.person_id} onChange={(v) => setF({ ...f, person_id: v })} options={offered} placeholder="Choose a person…"
              empty={people.length ? 'No one matches; switch the filter off' : 'No one in this entity can take this seat'} />
            <button className="primary" disabled={!f.person_id}
              onClick={() => run(() => api.seat(tree.run_id, f.stage_id, f.seat, f.person_id).then(() => setF({ ...f, person_id: '' })))}>Seat</button>
          </div>
        </div>
      )}
      {msg && <p className="error" role="alert">{msg}</p>}
    </div>
  );
}

function RoomView({ tree, room, meta, onDone, focusQr }) {
  if (!room) return null;
  const stages = tree.stages
    .map((s) => ({ ...s, topics: s.topics.map((t) => ({ ...t, questions: t.questions.filter((q) => q.ask_in === room.kind
      || (q.state === 'Agreed' && KIND_RANK[room.kind] <= PATH_RANK[t.path])) }))
      .filter((t) => t.questions.length) }))
    .filter((s) => s.topics.length);
  return (
    <div className="panel">
      <p className="hint">{ROOM_NAMES[room.kind]} room · {room.members.map((m) => m.name + (m.spoc ? ' (SPOC)' : '')).join(', ')}</p>
      {stages.length === 0 && <p className="hint">Nothing in this room for you yet.</p>}
      {stages.map((s) => (
        <div key={s.stage_id} className="node open">
          <div className="node-head static-head"><span className="kind">Stage</span><span className="title">{s.name}</span>
            <span className="tag"><span className="st">{s.status}</span>{s.my_seats.length > 0 && <span className="badge">{s.my_seats.join(', ')}</span>}</span></div>
          <div className="node-body">
            {s.topics.map((t) => (
              <div key={t.topic_id} className="topic-block">
                <div className="item"><span className="kind">Topic</span><strong>{t.name}</strong><span className="st">{t.status}</span></div>
                {t.questions.map((q) => (
                  <Question key={q.qr_id} q={q} stage={s} tree={tree} room={room} meta={meta} onDone={onDone} highlight={q.qr_id === focusQr} />
                ))}
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

export function Question({ q, stage, tree, room, meta, onDone, highlight }) {
  const [msg, run] = useAction(onDone);
  const [answer, setAnswer] = useState(q.answer || '');
  const [source, setSource] = useState('Person');
  const [reason, setReason] = useState(meta.reasons[0]);
  const [expl, setExpl] = useState('');
  const me = getActingUser();
  const seats = stage.my_seats || [];
  const here = (q.room_id ? q.room_id === room.room_id : q.ask_in === room.kind) && q.in_my_room;
  const open = q.status === 'Open' && !tree.locked;
  const notMine = q.last_submitter !== me;
  const canAnswer = here && open && !q.locked && seats.includes('Doer') && ['Pending', 'Contested'].includes(q.state);
  const canReview = here && open && seats.includes('Reviewer') && q.state === 'Submitted' && notMine && !q.reviewed;
  const canDecide = here && open && q.state === 'Submitted' && notMine && (seats.includes('Approver') || seats.includes('SPOC'));
  const agreeReady = !q.has_reviewer || q.reviewed;
  const canContest = here && open && q.state === 'Submitted' && notMine && (seats.includes('Approver') || seats.includes('Reviewer') || seats.includes('SPOC'));
  const canDeadlock = here && open && ['Submitted', 'Contested'].includes(q.state) && (seats.includes('Approver') || seats.includes('SPOC'));
  const canCancel = open && (tree.is_requestor || seats.includes('Approver'));
  const canReopen = !tree.locked && tree.is_requestor && q.status === 'Closed' && q.closed_as === 'Success';
  const travelled = q.room_id ? q.room_id !== room.room_id : q.ask_in !== room.kind;

  return (
    <div className={`question${highlight ? ' focus' : ''}${q.locked ? ' locked' : ''}`}>
      <div className="data-head">
        <span className="dtype">{q.text}</span>
        <span className="hint">{q.flow_option}{travelled ? ` · agreed in ${q.ask_in}` : ''}</span>
        <span className="tag">
          {q.status === 'Open' && !tree.locked && (q.in_my_room || tree.is_requestor) ? (
            <select className="q-select" value={q.quadrant} aria-label="Priority"
              onChange={(e) => run(() => api.setQuadrant(q.qr_id, e.target.value))}>
              {['Do now', 'Do later', 'Delegate', 'Delete'].map((x) => <option key={x}>{x}</option>)}
            </select>
          ) : <span className="st">{q.quadrant}</span>}
          <span className={`st st-${q.state}`}>{q.state}</span>
          <span className="st">{q.status === 'Closed' ? `Closed${q.closed_as ? ` · ${q.closed_as}` : ''}` : 'Open'}</span>
        </span>
      </div>
      {q.rules && <p className="hint">Rules: {q.rules}</p>}
      {q.locked && <p className="hint">Waits for: {q.waits_for.join(', ')}</p>}
      {q.status === 'Open' && q.due_date && <p className="due-ink">Due {q.due_date}</p>}
      <AnswerView q={q} />
      {q.capabilities?.length > 0 && <div className="caps">{q.capabilities.map((c) => <span key={c.use_id} className="cap-chip">{c.name}</span>)}</div>}
      {q.third_party && <p className="ink small">Waiting for a reply from {q.third_party}</p>}
      {q.rounds.length > 0 && (
        <ul className="rounds">
          {q.rounds.map((r, i) => (
            <li key={i}><span className="kind">{r.kind}</span> {r.by_name} <span className="hint">{r.at}</span>
              {r.reason && <> · <strong>{r.reason}</strong></>}{r.explanation && <>: {r.explanation}</>}{r.kind === 'Submit' && r.body && <>: {r.body}</>}</li>
          ))}
        </ul>
      )}
      {canAnswer && !q.third_party && <AnswerForm q={q} onSubmit={(text, data) => run(() => api.act(q.qr_id, 'submit', { answer: text, source: 'Person', data }))} />}
      {canAnswer && room.kind !== 'ER' && <ThirdParty q={q} run={run} />}
      {q.room_kind === 'ER' && q.answer && q.in_my_room && room.kind === 'ER' && <CallIn q={q} tree={tree} run={run} />}
      {canAnswer && q.removal_asked && (
        <div className="inline"><span className="sub">The other side asks to remove this question.</span>
          <button className="quiet" onClick={() => run(() => api.act(q.qr_id, 'accept-removal'))}>Agree to remove</button></div>
      )}
      {(canReview || canDecide || canContest || canDeadlock) && (
        <div className="mini-form">
          <div className="inline">
            {canReview && <button className="quiet" onClick={() => run(() => api.act(q.qr_id, 'review'))}>Mark reviewed</button>}
            {canDecide && agreeReady && <button className="primary" onClick={() => run(() => api.act(q.qr_id, 'agree'))}>Agree</button>}
            {canDecide && !agreeReady && <span className="hint">Waiting for the Reviewer</span>}
          </div>
          {(canContest || canDeadlock) && (
            <>
              <div className="inline">
                {canContest && (
                  <select value={reason} onChange={(e) => setReason(e.target.value)} aria-label="Reason">
                    {meta.reasons.map((r) => <option key={r}>{r}</option>)}
                  </select>
                )}
                <input value={expl} onChange={(e) => setExpl(e.target.value)} placeholder="Explanation" aria-label="Explanation" />
              </div>
              <div className="inline">
                {canContest && <button className="quiet" disabled={!expl.trim()} onClick={() => run(() => api.act(q.qr_id, 'contest', { reason, explanation: expl }).then(() => setExpl('')))}>Contest</button>}
                {canDeadlock && <button className="quiet" disabled={!expl.trim()} onClick={() => run(() => api.act(q.qr_id, 'deadlock', { explanation: expl }))}>Declare deadlock</button>}
              </div>
            </>
          )}
        </div>
      )}
      <div className="inline">
        {canCancel && <button className="danger" onClick={() => { const why = window.prompt('Why is this question no longer needed?'); if (why) run(() => api.act(q.qr_id, 'cancel', { explanation: why })); }}>Cancel question</button>}
        {canReopen && <button className="quiet" onClick={() => run(() => api.act(q.qr_id, 'reopen'))}>Reopen</button>}
      </div>
      {msg && <p className="error" role="alert">{msg}</p>}
    </div>
  );
}

// Third-party request: sent from a Private or Internal room; the reply returns to the same question
function ThirdParty({ q, run }) {
  const [f, setF] = useState({ party: '', email: '', reply: '' });
  const [open, setOpen] = useState(false);
  if (q.third_party) {
    return (
      <div className="mini-form">
        <textarea rows={2} placeholder="Their reply" value={f.reply} onChange={(e) => setF({ ...f, reply: e.target.value })} aria-label="Reply" />
        <button className="primary" disabled={!f.reply.trim()} onClick={() => run(() => api.act(q.qr_id, 'third-party-reply', { reply: f.reply }))}>Record reply</button>
      </div>
    );
  }
  if (!open) return <button className="plink ink" onClick={() => setOpen(true)}>Send to a third party</button>;
  return (
    <div className="mini-form inline">
      <input placeholder="Party (e.g. the bank)" value={f.party} onChange={(e) => setF({ ...f, party: e.target.value })} aria-label="Party" />
      <input placeholder="Their email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} aria-label="Email" />
      <button className="quiet" disabled={!f.party.trim() || !f.email.trim()} onClick={() => run(() => api.act(q.qr_id, 'third-party', { party: f.party, email: f.email }))}>Send request</button>
      <span className="sub">Recorded in the demo; no email is sent.</span>
    </div>
  );
}

// Call in and split: bring the other side's answer into your own room as lines; only lines Under discussion need settling
function CallIn({ q, tree, run }) {
  const mine = tree.rooms.filter((r) => r.member && r.kind !== 'ER' && !(tree.split || []).some((g) => g.source_qr === q.qr_id && g.room_id === r.room_id));
  const [open, setOpen] = useState(false);
  const [roomId, setRoomId] = useState('');
  const [text, setText] = useState((q.answer || '').split(/(?<=[.;])\s+|\n/).filter(Boolean).join('\n'));
  const [discuss, setDiscuss] = useState([]);
  if (mine.length === 0) return null;
  if (!open) return <button className="plink ink" onClick={() => setOpen(true)}>Call in and split</button>;
  const lines = text.split('\n');
  return (
    <div className="mini-form">
      <select value={roomId} onChange={(e) => setRoomId(e.target.value)} aria-label="Into room">
        <option value="">Call into…</option>{mine.map((r) => <option key={r.room_id} value={r.room_id}>{r.kind === 'PR' ? 'Private' : r.name}</option>)}
      </select>
      <textarea rows={Math.max(3, lines.length)} value={text} onChange={(e) => setText(e.target.value)} aria-label="Lines, one per line" />
      <p className="sub">Tick the lines that need discussing; the rest count as Agreed.</p>
      {lines.map((l, i) => l.trim() && (
        <label key={i} className="check"><input type="checkbox" checked={discuss.includes(i + 1)}
          onChange={() => setDiscuss(discuss.includes(i + 1) ? discuss.filter((x) => x !== i + 1) : [...discuss, i + 1])} />{l}</label>
      ))}
      <button className="primary" disabled={!roomId} onClick={() => run(() => api.act(q.qr_id, 'call-in', { room_id: roomId, lines: text, discuss: discuss.join(',') }))}>Call in</button>
    </div>
  );
}
