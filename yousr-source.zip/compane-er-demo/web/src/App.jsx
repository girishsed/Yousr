import { useEffect, useMemo, useRef, useState } from 'react';
import { api, setActingUser, hosted } from './api.js';
import { SignIn, CreateEntityCard, ConnectionsCard, DiscoverCard } from './ChatPlatform.jsx';
import { ProfileTaskBanner, AddBusinessPrompt, EntityJourney } from './Journeys.jsx';
import Brand, { Mark } from './Brand.jsx';
import ChatUI from './ChatUI.jsx';
import { DEFAULT_UI } from './defaultUi.js';
import Icon from './Icon.jsx';
import Catalogue from './Catalogue.jsx';
import { CatalogueList, CatalogueItem, ITEM_MENU } from './CatalogueScreens.jsx';
import Console from './Console.jsx';
import Calendar from './Calendar.jsx';
import AuditReport from './AuditReport.jsx';
import TableScreen from './TableScreen.jsx';
import TaskDetail from './TaskDetail.jsx';
import { WorkPersonas, AuthoritySeats, EntityPersona, DomainPersonas, PersonPersona, Responsibilities } from './Personas.jsx';
import { PersonalHome, PersonalTasks, BusinessList, EntityHome, TaskList, Vendors, NotInDemo, StandaloneDialog } from './Screens.jsx';

const PERSONAL_RAIL = [['home', 'Home', 'home'], ['tasks', 'Tasks', 'tasks'], ['calendar', 'Calendar', 'calendar'], ['files', 'Files', 'files'],
  ['id', 'ID', 'id'], ['business', 'Business', 'business'], ['discover', 'Discover & Connect', 'compass'], ['settings', 'Settings', 'settings']];
const TOP_RAIL = [['personal', 'Personal', 'person'], ['business', 'Business', 'business'], ['discover', 'Discover & Connect', 'compass']];
// Which Work Persona module each entity menu item needs (items not listed are always shown)
const PAGE_MODULE = { home: 'WOM', task: 'WOM', taskdetail: 'WOM', audit: 'WOM', vendors: 'Vendors', revenue: 'Revenue', compliance: 'Compliance',
  catalogue: 'Catalogue', catalogueitem: 'Catalogue', discover: 'Connections' };
const ENTITY_RAIL = [['home', 'Home', 'home'], ['revenue', 'Revenue', 'revenue'], ['vendors', 'Vendors', 'vendors'], ['compliance', 'Compliance', 'compliance'],
  ['catalogue', 'Catalogue', 'tag'], ['discover', 'Discover and Connect', 'compass'], ['task', 'Task', 'tasks'], ['files', 'Files', 'files'],
  ['tools', 'Tools', 'tools'], ['projects', 'Projects', 'files'], ['settings', 'Settings', 'settings']];
const GROUPS = ['Masters', 'Krama design', 'Runs'];

export default function App() {
  const [meta, setMeta] = useState(null);
  const [users, setUsers] = useState([]);
  const [actingUser, setActing] = useState('');
  const [ui, setUi] = useState(() => (typeof window !== 'undefined' && window.localStorage?.getItem('compane-ui-' + DEFAULT_UI)) || DEFAULT_UI);
  const switchUi = (x) => { setUi(x); try { window.localStorage.setItem('compane-ui-' + DEFAULT_UI, x); } catch { /* ignore */ } };
  const [view, setView] = useState({ space: 'personal', page: 'home' });
  const [access, setAccess] = useState(null);
  const entityKey = view.space === 'entity' && view.entity ? view.entity.entity_id : null;
  const [standalone, setStandalone] = useState(null); // { id } or { id: null } for new
  const [loadError, setLoadError] = useState('');
  const [menu, setMenu] = useState(false);
  const [tick, setTick] = useState(0);
  const menuRef = useRef(null);

  const loadUsers = () => api.list('users').then((u) => { setUsers(u); return u; });
  function chooseActing(id) { setActingUser(id); setActing(id); setView({ space: 'personal', page: 'home' }); setMenu(false); }

  const [needSignIn, setNeedSignIn] = useState(false);
  useEffect(() => {
    if (hosted) {
      // Online: who you are comes from your sign-in, never from a picker
      api.meta().then((m) => { setMeta(m); return api.me(); })
        .then((meResp) => { if (!meResp) { setNeedSignIn(true); return null; } return loadUsers().then(() => chooseActing(meResp.user_id)); })
        .catch(() => setLoadError('Compane is not reachable right now. Try again in a minute.'));
      return;
    }
    Promise.all([api.meta(), loadUsers()])
      .then(([m, u]) => { const first = u.find((x) => x.name === 'Vikram Shah') || u.find((x) => x.user_type === 'Individual'); if (first) chooseActing(first.user_id); setMeta(m); })
      .catch(() => setLoadError('The API is not reachable. Start the API on port 8080, then refresh.'));
  }, []);
  useEffect(() => {
    const close = (e) => { if (menuRef.current && !menuRef.current.contains(e.target)) setMenu(false); };
    document.addEventListener('mousedown', close);
    return () => document.removeEventListener('mousedown', close);
  }, []);

  useEffect(() => {
    setAccess(null);
    if (entityKey && actingUser) api.do('my_access', { entity_id: entityKey }).then(setAccess).catch(() => {});
  }, [entityKey, actingUser]);
  const byKey = useMemo(() => { const m = {}; meta?.entities.forEach((e) => (m[e.key] = e)); return m; }, [meta]);
  if (loadError) return <div className="notice">{loadError}</div>;
  if (!meta) return <div className="notice">Loading…</div>;
  if (needSignIn) return <SignIn people={[]} onSignedIn={async (uid) => { await loadUsers(); chooseActing(uid); setNeedSignIn(false); }} />;

  const me = users.find((u) => u.user_id === actingUser) || { name: '' };
  const isSuper = !!me.is_super_user;
  const allowed = (m) => !m || !access || access.admin || (access.modules || []).includes(m);
  const people = users.filter((u) => u.user_type === 'Individual');
  const initials = me.name.split(' ').map((p) => p[0]).join('').slice(0, 2);
  const go = (v) => { setView(v); setMenu(false); };
  const openTask = (runId, qrId) => go({ ...view, space: 'entity', page: 'taskdetail', runId, qrId });

  // ---------- rail ----------
  let railItems; let active = view.page; let onPick;
  if (view.space === 'personal') {
    railItems = PERSONAL_RAIL;
    onPick = (k) => (k === 'business' ? go({ space: 'business', page: 'business' }) : go({ space: 'personal', page: k }));
  } else if (view.space === 'business') {
    railItems = TOP_RAIL; active = 'business';
    onPick = (k) => (k === 'personal' ? go({ space: 'personal', page: 'home' }) : go({ space: 'business', page: k }));
  } else if (view.space === 'entity' && view.page === 'catalogueitem') {
    // The item page has its own side menu in the same place; "‹ Catalogue" goes back
    railItems = []; onPick = () => {};
  } else if (view.space === 'entity') {
    railItems = ENTITY_RAIL.filter(([k]) => allowed(PAGE_MODULE[k])); active = view.page === 'taskdetail' ? 'task' : view.page;
    onPick = (k) => go({ space: 'entity', entity: view.entity, page: k });
  } else {
    railItems = []; onPick = () => {};
  }

  const rail = (
    <aside className="frail">
      {view.space === 'entity' && view.page === 'catalogueitem' && (
        <>
          <button className="rail-back" onClick={() => go({ space: 'entity', entity: view.entity, page: 'catalogue' })}><Icon name="back" /> Catalogue</button>
          {ITEM_MENU.map(([k, label]) => (
            <button key={k} className={(view.section || 'overview') === k ? 'frail-item on' : 'frail-item'} onClick={() => go({ ...view, section: k })}>{label}</button>
          ))}
        </>
      )}
      {view.space === 'entity' && view.page !== 'catalogueitem' && (
        <button className="rail-back" onClick={() => go({ space: 'business', page: 'business' })}><Icon name="back" /> Business</button>
      )}
      {view.space === 'entity' && view.page !== 'catalogueitem' && <p className="rail-entity">{view.entity.name}</p>}
      {view.space === 'admin' && (
        <>
          <button className="rail-back" onClick={() => go({ space: 'personal', page: 'home' })}><Icon name="back" /> Platform admin</button>
          <button className={view.page === 'krama-console' ? 'frail-item on' : 'frail-item'} onClick={() => go({ space: 'admin', page: 'krama-console' })}>Krama console</button>
          {GROUPS.map((g) => (
            <div key={g} className="rail-group-f">
              <p className="rail-label">{g}</p>
              {meta.entities.filter((e) => e.group === g).map((e) => (
                <button key={e.key} className={view.page === e.key ? 'frail-item on' : 'frail-item'} onClick={() => go({ space: 'admin', page: e.key })}>{e.label}</button>
              ))}
            </div>
          ))}
        </>
      )}
      {railItems.map(([k, label, icon]) => (
        <button key={k} className={active === k ? 'frail-item on' : 'frail-item'} onClick={() => onPick(k)} aria-label={label}>
          {k === 'business' && view.space === 'personal' ? <><Mark /> compane</>
            : k === 'personal' && view.space === 'business' ? <><Mark /> Yousr</>
            : <><Icon name={icon} /> {label}</>}
        </button>
      ))}
      <div className="promo">
        <Icon name="sparkle" />
        <p className="serif strong">Unlock the full power</p>
        <p className="sub">Create a business and manage everything in one place.</p>
        <button className="primary block" onClick={() => go({ ...view, page: 'createbusiness' })}>Create Business</button>
      </div>
    </aside>
  );

  // ---------- header ----------
  const header = (
    <header className="fheader">
      <div className="flogo"><Brand name={view.space === 'personal' ? 'Yousr' : 'compane'} /></div>
      <div className="fsearch"><Icon name="search" size={16} /><input placeholder="Search for anything..." aria-label="Search" /></div>
      <div className="fhead-right" ref={menuRef}>
        <button className="icon-btn" title="Email" onClick={() => go({ ...view, page: 'mail' })}><Icon name="mail" /></button>
        <button className="icon-btn" title="Calendar" onClick={() => go({ space: view.space === 'admin' ? 'personal' : view.space, entity: view.entity, page: 'calendar' })}><Icon name="calendar" /></button>
        <button className="user-chip" onClick={() => setMenu(!menu)}><span className="avatar">{initials}</span>{me.name.split(' ')[0]}<Icon name="chevron" size={14} /></button>
        {menu && (
          <div className="user-menu">
            <p className="label">WORKING AS</p>
            {people.map((u) => (
              <button key={u.user_id} className={u.user_id === actingUser ? 'on' : ''} onClick={() => chooseActing(u.user_id)}>
                {u.name}{u.is_super_user ? ' · super-user' : ''}
              </button>
            ))}
            {isSuper && <><hr /><button onClick={() => go({ space: 'admin', page: 'krama-console' })}>Krama console</button><button onClick={() => go({ space: 'admin', page: 'users' })}>Platform admin</button></>}
            <hr /><button onClick={() => { setMenu(false); switchUi('chat'); }}>Chat view</button>
          </div>
        )}
      </div>
    </header>
  );

  // ---------- page ----------
  const ent = view.entity;
  const p = view.page;
  let body;
  if (p === 'calendar') body = <div className="page"><h1 className="serif">Calendar</h1><p className="sub">Only what involves you.</p><Calendar key={actingUser} onOpen={(runId, qrId, entityId, entityName) => runId && entityId
        && go({ space: 'entity', entity: { entity_id: entityId, name: entityName }, page: 'taskdetail', runId, qrId })} /></div>;
  else if (p === 'mail') body = <NotInDemo title="Email" />;
  else if (p === 'createbusiness') body = <div className="page"><h1 className="serif">Add your business</h1><CreateEntityCard me={me} ctx={{ refreshEntities: () => {} }} /></div>;
  else if (view.space === 'personal') body = p === 'home' ? <><div className="page journey-top"><ProfileTaskBanner key={actingUser} onDone={() => loadUsers()} /></div><PersonalHome name={me.name} onBusiness={() => go({ space: 'business', page: 'business' })} /></>
    : p === 'tasks' ? <PersonalTasks key={actingUser} />
    : <NotInDemo title={PERSONAL_RAIL.find((r) => r[0] === p)?.[1] || ''} />;
  else if (view.space === 'business') body = p === 'business' ? <><BusinessList key={actingUser} onOpen={(e) => go({ space: 'entity', entity: e, page: 'home' })} />
      <BusinessPrompt actingUser={actingUser} onAdd={() => go({ space: 'personal', page: 'createbusiness' })} /></> : <NotInDemo title="Discover & Connect" />;
  else if (view.space === 'entity' && !allowed(PAGE_MODULE[p])) {
    body = <div className="page"><div className="card empty-card"><p>Your Work Persona{access?.persona ? ` (${access.persona})` : ''} does not include {PAGE_MODULE[p]}. Ask your entity admin.</p></div></div>;
  }
  else if (view.space === 'entity') {
    if (p === 'discover') body = (
      <div className="page">
        <h1 className="serif">Discover and Connect</h1>
        <p className="sub">Connections: accept a request with your code, invite a client or vendor, cancel or resend.</p>
        <ConnectionsCard key={`${ent.entity_id}-${actingUser}`} entity={ent} ctx={{ me, addCard: () => {} }} />
        <h3 className="serif">Discover</h3>
        <DiscoverCard key={`d-${ent.entity_id}-${actingUser}`} entity={ent} ctx={{ addCard: () => {} }} />
      </div>
    );
    else if (p === 'home') body = <><div className="page journey-top"><EntityJourney key={`${ent.entity_id}-${actingUser}`} entity={ent} /></div><EntityHome key={`${ent.entity_id}-${tick}`} entity={ent} onOpenTask={openTask} onOpenStandalone={(id) => setStandalone({ id })} /></>;
    else if (p === 'task') body = <TaskList key={`${ent.entity_id}-${tick}`} entity={ent} onOpenTask={(id) => openTask(id)} onOpenStandalone={(id) => setStandalone({ id })}
      onNewFromCatalogue={() => go({ ...view, page: 'settings', tab: 'krama' })} onNewStandalone={() => setStandalone({ id: null })} />;
    else if (p === 'taskdetail') body = <TaskDetail key={`${view.runId}-${view.qrId || ''}`} runId={view.runId} focusQr={view.qrId} meta={meta}
      companies={users.filter((u) => u.user_type === 'Company')}
      onBack={() => go({ ...view, page: 'task' })} onAudit={(runId) => go({ ...view, page: 'audit', runId })} />;
    else if (p === 'audit') body = <div className="page"><AuditReport runId={view.runId} onBack={() => go({ ...view, page: 'taskdetail' })} /></div>;
    else if (p === 'catalogue') body = <CatalogueList key={`${ent.entity_id}-${actingUser}`} entity={ent} onOpen={(itemId) => go({ ...view, page: 'catalogueitem', itemId, section: 'overview' })} />;
    else if (p === 'catalogueitem') body = <CatalogueItem key={`${view.itemId}-${actingUser}`} itemId={view.itemId} section={view.section || 'overview'} />;
    else if (p === 'vendors') body = <Vendors entity={ent} />;
    else if (p === 'settings') {
      const tabs = [['krama', 'Krama', 'Catalogue'], ['console', 'Krama console', 'Krama'], ['personas', 'Work Personas'], ['seats', 'Authority seats'],
        ['persona', 'Entity Persona'], ['responsibility', 'Responsibilities'], ['me', 'My Person Persona'], ...(isSuper ? [['domains', 'Domain profiles and personas']] : [])].filter(([, , m]) => allowed(m));
      const tab = tabs.some(([k]) => k === view.tab) ? view.tab : tabs[0][0];
      body = (
        <div className="page">
          <h1 className="serif">Settings</h1>
          <div className="seg">
            {tabs.map(([k, l]) => <button key={k} className={tab === k ? 'seg-btn on' : 'seg-btn'} onClick={() => go({ ...view, tab: k })}>{l}</button>)}
          </div>
          {tab === 'krama' && <><p className="sub">Start a task from a Krama, and add or assign Published Kramas.</p>
            <Catalogue key={ent.entity_id} entityId={ent.entity_id} onStarted={(runId) => openTask(runId)} /></>}
          {tab === 'console' && <><p className="sub">Build, import, test and publish Kramas.</p><Console key={actingUser} meta={meta} /></>}
          {tab === 'personas' && <WorkPersonas key={`${ent.entity_id}-${actingUser}`} entity={ent} />}
          {tab === 'seats' && <AuthoritySeats key={ent.entity_id} entity={ent} />}
          {tab === 'persona' && <EntityPersona key={`${ent.entity_id}-${actingUser}`} entity={ent} admin={!!access?.admin || isSuper} />}
          {tab === 'domains' && <DomainPersonas isSuper={isSuper} />}
          {tab === 'responsibility' && <Responsibilities key={`${ent.entity_id}-${actingUser}`} entity={ent} />}
          {tab === 'me' && <PersonPersona key={actingUser} />}
        </div>
      );
    }
    else body = <NotInDemo title={ENTITY_RAIL.find((r) => r[0] === p)?.[1] || ''} />;
  } else if (view.space === 'admin' && p === 'krama-console') {
    body = (
      <div className="page">
        <h1 className="serif">Krama console</h1>
        <p className="sub">Platform Kramas: create with no owner entity, build, and publish. Entities then Import them.</p>
        <Console key={actingUser} meta={meta} />
      </div>
    );
  } else if (view.space === 'admin' && byKey[p]) {
    const e = byKey[p];
    body = <div className="page admin-page"><TableScreen key={e.key} ent={e} byKey={byKey} meta={meta} canWrite={isSuper && !e.readOnly}
      onChanged={e.key === 'users' ? loadUsers : undefined}
      note={e.readOnly ? `${e.label} change only through actions.` : e.design ? 'Design rows of a Published Krama are frozen; use New version in the Krama console.' : ''} /></div>;
  }

  if (ui === 'chat' && actingUser) {
    return (
      <ChatUI me={me} users={users} actingUser={actingUser} meta={meta} byKey={byKey} isSuper={isSuper} onUsersChanged={loadUsers} onActing={(id) => { setActingUser(id); setActing(id); }}
        onClassic={(pg) => { switchUi('classic'); if (pg && pg.page) { const e = pg.entity ? { entity_id: pg.entity.entity_id, name: pg.entity.name } : view.entity; if (e) go({ space: 'entity', entity: e, page: pg.page, tab: pg.tab }); } }}
        onOpenTask={(r, e) => { switchUi('classic'); go({ space: 'entity', entity: e ? { entity_id: e.entity_id, name: e.name } : view.entity, page: 'taskdetail', runId: r.run_id, qrId: r.qr_id }); }} />
    );
  }

  return (
    <div className="fshell">
      {header}
      <div className="fbody">{rail}<main className="fmain">{body}</main></div>
      {standalone && ent && <StandaloneDialog entity={ent} taskId={standalone.id} onClose={(changed) => { setStandalone(null); if (changed) setTick((t) => t + 1); }} />}
    </div>
  );
}

// Business Dashboard: prompts to add a business when the person has none
function BusinessPrompt({ actingUser, onAdd }) {
  const [none, setNone] = useState(false);
  useEffect(() => { api.business().then((b) => setNone(!(b.entities || b || []).length)).catch(() => {}); }, [actingUser]);
  return none ? <div className="page"><AddBusinessPrompt onAdd={onAdd} /></div> : null;
}
