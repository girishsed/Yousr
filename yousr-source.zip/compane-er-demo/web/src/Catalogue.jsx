import { useEffect, useState } from 'react';
import { api } from './api.js';

const INTERNAL = ['Department', 'Business Unit'];
const EXTERNAL = ['Pre-client', 'Client', 'Pre-vendor', 'Vendor'];

export default function Catalogue({ onStarted, entityId }) {
  const [c, setC] = useState(null);
  const [msg, setMsg] = useState('');
  const load = () => api.catalogue().then((d) => setC(entityId ? {
    ...d, items: d.items.filter((i) => i.entity_id === entityId), addable: d.addable.filter((a) => a.entity_id === entityId),
  } : d)).catch((e) => setMsg(e.message));
  useEffect(() => { load(); }, []);
  if (msg) return <p className="error" role="alert">{msg}</p>;
  if (!c) return <p className="hint">Loading…</p>;

  return (
    <div className="catalogue">
      {c.items.length === 0 && <p className="hint">No catalogue items for your entities yet.</p>}
      <div className="cat-list">
        {c.items.map((it) => <Item key={it.item_id} it={it} c={c} onStarted={onStarted} />)}
      </div>
      {c.addable.length > 0 && <Addable c={c} reload={load} />}
    </div>
  );
}

function Item({ it, c, onStarted }) {
  const relationships = [...(it.has_internal ? INTERNAL : []), ...(it.has_external ? EXTERNAL : [])];
  const [rel, setRel] = useState(relationships[0] || '');
  const [cp, setCp] = useState('');
  const [options, setOptions] = useState([]);
  const [kramaId, setKramaId] = useState('');
  const [msg, setMsg] = useState('');
  const external = EXTERNAL.includes(rel);

  useEffect(() => {
    setKramaId('');
    if (!rel || (external && !cp)) { setOptions([]); return; }
    api.resolve(it.item_id, rel, external ? cp : '').then((o) => { setOptions(o); setKramaId(o[0]?.krama_id || ''); })
      .catch((e) => setMsg(e.message));
  }, [rel, cp]); // eslint-disable-line react-hooks/exhaustive-deps

  async function start() {
    setMsg('');
    try {
      const r = await api.activate(it.item_id, { relationship: rel, counterparty: external ? cp : null, krama_id: kramaId || null });
      onStarted(r.run_id);
    } catch (e) { setMsg(e.message); }
  }

  return (
    <article className="cat-card">
      <div className="cat-head">
        <div>
          <h2>{it.name}</h2>
          <p className="run-meta">
            {it.entity_name}
            {it.library ? ` · ${it.library.kind}: ${it.library.name}` : ''}
            {it.offering ? ` · host ${it.offering}` : ''}{` · ${it.release}`}
          </p>
          {it.library && <p className="hint">Seller persona: {it.library.seller || '—'} · Buyer persona: {it.library.buyer || '—'}</p>}
        </div>
      </div>
      <div className="section">
        <h4>Kramas</h4>
        {it.kramas.map((k) => (
          <p key={k.krama_id}>{k.name} v{k.version} <span className="hint">{k.external ? (k.relationships.length ? k.relationships.join(', ') : 'not mapped to any persona type yet') : 'Internal'}</span></p>
        ))}
      </div>
      <div className="mini-form">
        <div className="grid2">
          <label>Relationship
            <select value={rel} onChange={(e) => setRel(e.target.value)}>
              {relationships.map((r) => <option key={r}>{r}</option>)}
            </select>
          </label>
          {external && (
            <label>With
              <select value={cp} onChange={(e) => setCp(e.target.value)} aria-label="Counterparty">
                <option value="">Choose an entity…</option>
                {c.companies.filter((co) => co.user_id !== it.entity_id).map((co) => (
                  <option key={co.user_id} value={co.user_id}>{co.name}{co.persona ? ` (${co.persona})` : ''}</option>
                ))}
              </select>
            </label>
          )}
        </div>
        {(!external || cp) && (options.length === 0
          ? <p className="hint">No Krama of this item is mapped to {external ? "this entity's persona type" : 'this relationship'}.</p>
          : options.length > 1
            ? <label>Krama<select value={kramaId} onChange={(e) => setKramaId(e.target.value)}>{options.map((o) => <option key={o.krama_id} value={o.krama_id}>{o.name} v{o.version}</option>)}</select></label>
            : <p className="hint">Runs: {options[0].name} v{options[0].version}</p>)}
        <div className="inline">
          <button className="primary" disabled={!options.length || (external && !cp)} onClick={start}>Start</button>
        </div>
      </div>
      {msg && <p className="error" role="alert">{msg}</p>}
    </article>
  );
}

function Addable({ c, reload }) {
  const [msg, setMsg] = useState({});
  const [target, setTarget] = useState({});
  async function go(k) {
    try {
      const t = target[k.krama_id + k.entity_id];
      if (t) await api.assign(t, k.krama_id);
      else await api.addItem(k.krama_id, k.entity_id, k.name);
      reload();
    } catch (e) { setMsg((m) => ({ ...m, [k.krama_id]: e.message })); }
  }
  return (
    <section className="section">
      <h4>Published Kramas you can add or assign</h4>
      {c.addable.map((k) => (
        <div key={k.krama_id + k.entity_id} className="item">
          <span>{k.name} v{k.version}</span>
          <span className="hint">{k.entity_name} · {k.ownership_type}</span>
          <select value={target[k.krama_id + k.entity_id] || ''} onChange={(e) => setTarget((t) => ({ ...t, [k.krama_id + k.entity_id]: e.target.value }))} aria-label="Assign to">
            <option value="">As a new catalogue item</option>
            {c.items.filter((it) => it.entity_id === k.entity_id && it.can_edit).map((it) => <option key={it.item_id} value={it.item_id}>Assign to {it.name}</option>)}
          </select>
          <button className="quiet" onClick={() => go(k)}>Add</button>
          {msg[k.krama_id] && <span className="error">{msg[k.krama_id]}</span>}
        </div>
      ))}
    </section>
  );
}
