import { useEffect, useState } from 'react';
import { api } from './api.js';

// Whose work it is (Entity Profile), each stage's domain profile and the person persona each seat needs
export default function TaskContext({ runId }) {
  const [d, setD] = useState(null);
  const [open, setOpen] = useState(false);
  useEffect(() => { api.do('task_context', { run_id: runId }).then(setD).catch(() => {}); }, [runId]);
  if (!d) return null;
  const L = (a) => (a || []).join(', ');
  return (
    <div className="task-context">
      <button className="link-btn" onClick={() => setOpen(!open)}>{open ? 'Hide context' : 'Context: entity, domains and persona needed'}</button>
      {open && (
        <div className="ctx-box">
          <p><b>For {d.entity?.name}</b> <span className="hint">· {d.entity?.persona}</span></p>
          {(d.entity?.objectives || (d.entity?.capabilities || []).length > 0) && <p className="hint">Objectives: {d.entity.objectives || '—'} · Capabilities: {L(d.entity.capabilities) || '—'}</p>}
          {((d.entity?.areas_of_operation || []).length > 0 || (d.entity?.business_interests || []).length > 0) && <p className="hint">Areas of operation: {L(d.entity.areas_of_operation) || '—'} · Business interests: {L(d.entity.business_interests) || '—'}</p>}
          {d.stages.map((s) => (
            <div key={s.stage_id} className="ctx-stage">
              <p><b>{s.name}</b> {s.domain ? <span className="hint">· {s.domain.name}</span> : <span className="hint">· no domain profile</span>}</p>
              {s.domain && (s.domain.objectives || (s.domain.controls || []).length > 0) && <p className="hint">{s.domain.objectives}{(s.domain.regulations || []).length ? ` · Regulations: ${L(s.domain.regulations)}` : ''}{(s.domain.controls || []).length ? ` · Controls: ${L(s.domain.controls)}` : ''}</p>}
              {s.domain && (s.domain.knowledge || []).length > 0 && <p className="hint">Knowledge: {L(s.domain.knowledge)}</p>}
              {s.needs.map((n) => <p key={n.seat} className="hint">{n.seat} needs: {[...n.expertise, ...n.skills].join(', ')}</p>)}
              {s.topics.map((t) => <p key={t.topic_id} className="hint">Topic {t.name}: {t.domain?.name}</p>)}
              {s.questions.map((q) => <p key={q.question_id} className="hint">Question “{q.text}”: {q.domain?.name}</p>)}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// For the Seats section: fit of each seated person, and who matches each stage seat
export function useSeatFit(runId, refreshKey) {
  const [d, setD] = useState(null);
  useEffect(() => { api.do('task_context', { run_id: runId }).then(setD).catch(() => {}); }, [runId, refreshKey]);
  return d;
}

// Controls of each stage's domain: confirmed by the stage's Reviewer or Approver, or the Requestor/Conductor.
// The task closes only when every control is confirmed.
export function TaskControls({ runId, onDone }) {
  const [rows, setRows] = useState(null);
  const [msg, setMsg] = useState('');
  const load = () => api.do('task_controls', { run_id: runId }).then(setRows).catch(() => {});
  useEffect(() => { load(); }, [runId]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!rows || rows.length === 0) return null;
  const pending = rows.reduce((n, s) => n + s.controls.filter((c) => !c.by).length, 0);
  const act = async (b) => { setMsg(''); try { await api.do('confirm_control', { run_id: runId, ...b }); await load(); onDone && onDone(); } catch (x) { setMsg(x.message); } };
  return (
    <div className="ctx-box task-controls">
      <p><b>Controls to confirm</b> <span className="hint">· {pending ? `${pending} pending; the task closes only when all are confirmed` : 'all confirmed'}</span></p>
      {rows.map((s) => (
        <div key={s.stage_id}>
          <p className="hint">{s.stage}</p>
          {s.controls.map((c) => (
            <label key={c.control} className="check">
              <input type="checkbox" checked={!!c.by} disabled={!s.can_confirm} onChange={() => act({ stage_id: s.stage_id, control: c.control, withdraw: !!c.by })} />
              {c.control}{c.by && <span className="hint"> · {c.by}, {c.at}</span>}
            </label>
          ))}
        </div>
      ))}
      {msg && <p className="error">{msg}</p>}
    </div>
  );
}
