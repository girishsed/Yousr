import { useEffect, useState } from 'react';
import { api } from './api.js';

// Journey prompts: update your profile (Personal), add your business, complete your client listing (entity)

export function ProfileTaskBanner({ onDone }) {
  const [a, setA] = useState(null);
  const [f, setF] = useState(null);
  const [msg, setMsg] = useState('');
  const load = () => api.do('my_actions', {}).then(setA).catch(() => {});
  useEffect(() => { load(); }, []);
  if (!a?.profile) return null;
  return (
    <div className="card journey-card">
      <p><b>Update your personal profile</b> <span className="sub">· your name and photo</span></p>
      {!f ? <button className="primary" onClick={async () => { const p = await api.do('profile', {}); setF({ name: p.name || '', photo: p.photo || '' }); }}>Update now</button> : (
        <div className="inline">
          <input placeholder="Your full name" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} aria-label="Full name" />
          <input placeholder="Photo (file name)" value={f.photo} onChange={(e) => setF({ ...f, photo: e.target.value })} aria-label="Photo" />
          <button className="primary" onClick={async () => { setMsg(''); try { await api.do('profile', f); await load(); onDone && onDone(); } catch (x) { setMsg(x.message); } }}>Save</button>
        </div>
      )}
      {msg && <p className="error">{msg}</p>}
    </div>
  );
}

export function AddBusinessPrompt({ onAdd }) {
  return (
    <div className="card journey-card">
      <p><b>Add your business</b></p>
      <p className="sub">Register your entity to run its work, catalogue, clients and vendors on compane.</p>
      <button className="primary" onClick={onAdd}>Add business</button>
    </div>
  );
}

export function ClientListingCard({ entity, taskId, onDone }) {
  const [rows, setRows] = useState([]);
  const [q, setQ] = useState('');
  const [found, setFound] = useState([]);
  const [picked, setPicked] = useState(null);
  const [isNew, setIsNew] = useState(false);
  const [f, setF] = useState({ user_name: '', user_email: '' });
  const [msg, setMsg] = useState('');
  const load = () => api.do('clients', { entity_id: entity.entity_id }).then(setRows).catch(() => {});
  useEffect(() => { load(); }, [entity.entity_id]); // eslint-disable-line react-hooks/exhaustive-deps
  // Search existing businesses as you type
  useEffect(() => {
    if (picked || isNew || q.trim().length < 2) { setFound([]); return undefined; }
    const t = setTimeout(() => api.do('discover', { entity_id: entity.entity_id, q: q.trim() }).then(setFound).catch(() => {}), 250);
    return () => clearTimeout(t);
  }, [q, picked, isNew, entity.entity_id]);
  const reset = () => { setQ(''); setPicked(null); setIsNew(false); setFound([]); setF({ user_name: '', user_email: '' }); };
  const add = async () => {
    setMsg('');
    try {
      const r = await api.do('add_client', { entity_id: entity.entity_id, client_entity_id: picked?.entity_id || '', client_name: picked ? '' : q.trim(), ...f });
      setMsg(r.on_platform ? 'Added; this business is on compane, so a connection request went to them.' : 'Added; listed until they join compane.');
      reset(); load();
    } catch (x) { setMsg(x.message); }
  };
  const listed = (name) => rows.some((c) => c.name.toLowerCase() === name.toLowerCase());
  return (
    <div className="card journey-card">
      <p><b>Complete your client listing</b> <span className="sub">· pick an existing business, or add a new client</span></p>
      {rows.map((c) => <p key={c.name} className="sub">{c.name} · {c.user_name || '—'} · {c.user_email || '—'} · {c.on_platform ? c.state : 'not on compane yet'}</p>)}
      {!picked && !isNew && (
        <div className="client-search">
          <input placeholder="Client name: start typing to find businesses on compane" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Find client" />
          {found.length > 0 && (
            <div className="client-results">
              {found.map((x) => (
                <button key={x.entity_id} disabled={!!x.connection || listed(x.name)} onClick={() => setPicked(x)}>
                  <b>{x.name}</b> <span className="sub">{x.persona || ''}{x.connection || listed(x.name) ? ' · already in your list' : ''}</span>
                </button>
              ))}
            </div>
          )}
          {q.trim().length >= 2 && <button className="cu-link" onClick={() => setIsNew(true)}>Not found? Add “{q.trim()}” as a new client</button>}
        </div>
      )}
      {(picked || isNew) && (
        <div className="inline">
          <span className="client-chip">{picked ? `${picked.name} · on compane` : `${q.trim()} · new`}</span>
          <input placeholder={picked ? 'User name (optional)' : 'User name'} value={f.user_name} onChange={(e) => setF({ ...f, user_name: e.target.value })} aria-label="User name" />
          <input placeholder={picked ? 'User email (optional)' : 'User email'} value={f.user_email} onChange={(e) => setF({ ...f, user_email: e.target.value })} aria-label="User email" />
          <button className="primary" onClick={add}>Add client</button>
          <button className="quiet" onClick={reset}>Change</button>
        </div>
      )}
      {taskId && <div className="inline"><button className="quiet" onClick={async () => { await api.do('finish_task', { task_id: taskId }); onDone && onDone(); }}>Listing complete</button></div>}
      {msg && <p className="sub">{msg}</p>}
    </div>
  );
}

// For an entity page: the client listing task, if it is open for this person
export function EntityJourney({ entity }) {
  const [task, setTask] = useState(null);
  const load = () => api.do('my_actions', {}).then((a) => setTask((a.client_listing || []).find((x) => x.entity_id === entity.entity_id) || null)).catch(() => {});
  useEffect(() => { load(); }, [entity.entity_id]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!task) return null;
  return <ClientListingCard entity={entity} taskId={task.task_id} onDone={load} />;
}
