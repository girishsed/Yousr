import { useState } from 'react';

const lines = (t) => (t || '').split('\n').map((x) => x.trim()).filter(Boolean);
const CHECKS = ['Checked', 'Matched', 'Clear', 'Flagged'];

// The answer screen for each flow option. onSubmit(text, data) sends a readable summary and the structured answer.
export function AnswerForm({ q, onSubmit }) {
  const prev = q.answer_data || {};
  const [d, setD] = useState(prev);
  const [err, setErr] = useState('');
  const set = (k, v) => setD((x) => ({ ...x, [k]: v }));
  const opts = lines(q.setup_options);
  const choices = lines(q.setup_choices).length ? lines(q.setup_choices) : ['Yes', 'No', 'Not applicable'];
  const cols = lines(q.setup_columns);
  const rows = d.rows || [];
  const diff = d.a !== undefined && d.b !== undefined && d.a !== '' && d.b !== '' ? Math.abs(Number(d.a) - Number(d.b)) : null;
  const outside = diff !== null && q.setup_limit !== null && q.setup_limit !== undefined && diff > Number(q.setup_limit);

  function summary() {
    switch (q.flow_option) {
      case 'Decision': return d.text;
      case 'Input field': return d.value;
      case 'Choice list': return (d.picked || []).join(', ');
      case 'Checklist': return opts.map((o) => `${o}: ${(d.items || {})[o] || '—'}`).join('; ');
      case 'File drop': return `${d.file} (${d.mobility}${d.evidence ? ', evidence' : ''})`;
      case 'Assign': return d.note;
      case 'Table grid': return `${rows.length} row${rows.length === 1 ? '' : 's'}: ${rows.filter((r) => r.check === 'Flagged').length} Flagged`;
      case 'Compare box': return `${d.a} vs ${d.b}, difference ${diff}`;
      case 'Finding control': return d.finding + (d.explanation ? `: ${d.explanation}` : '');
      case 'Signature panel': return `Signed ${d.version} (${d.method || 'Yes'})`;
      default: return '';
    }
  }
  function submit() {
    setErr('');
    const text = (summary() || '').trim();
    if (!text) { setErr('Complete the answer first'); return; }
    onSubmit(text, d).catch?.((e) => setErr(e.message));
  }
  const fileFields = (k) => {
    const v = d[k] || {};
    const upd = (f, val) => set(k, { ...v, [f]: val });
    return (
      <div className="inline">
        <input placeholder="File name" value={v.file || ''} onChange={(e) => upd('file', e.target.value)} aria-label="File" />
        <select value={v.mobility || ''} onChange={(e) => upd('mobility', e.target.value)} aria-label="Mobility">
          <option value="">Mobile or Fixed?</option><option>Mobile</option><option>Fixed</option>
        </select>
        <label className="check"><input type="checkbox" checked={!!v.evidence} onChange={(e) => upd('evidence', e.target.checked)} />Evidence</label>
      </div>
    );
  };

  let body;
  switch (q.flow_option) {
    case 'Decision':
      body = <textarea rows={3} placeholder="Your position, in full wording" value={d.text || ''} onChange={(e) => set('text', e.target.value)} />; break;
    case 'Input field':
      body = <input placeholder="Answer" value={d.value || ''} onChange={(e) => set('value', e.target.value)} />; break;
    case 'Choice list':
      body = (
        <div className="opt-list">
          {opts.map((o) => {
            const on = (d.picked || []).includes(o);
            return (
              <label key={o} className="check">
                <input type={q.setup_multi ? 'checkbox' : 'radio'} name={q.qr_id} checked={on}
                  onChange={() => set('picked', q.setup_multi ? (on ? d.picked.filter((x) => x !== o) : [...(d.picked || []), o]) : [o])} />{o}
              </label>
            );
          })}
        </div>
      ); break;
    case 'Checklist':
      body = (
        <table className="ans-table"><tbody>
          {opts.map((o) => (
            <tr key={o}><td>{o}</td><td>
              <select value={(d.items || {})[o] || ''} onChange={(e) => set('items', { ...(d.items || {}), [o]: e.target.value })} aria-label={o}>
                <option value="">Choose…</option>{choices.map((c) => <option key={c}>{c}</option>)}
              </select></td></tr>
          ))}
        </tbody></table>
      ); break;
    case 'File drop':
      body = (
        <div className="inline">
          <input placeholder="File name" value={d.file || ''} onChange={(e) => set('file', e.target.value)} aria-label="File" />
          <select value={d.mobility || ''} onChange={(e) => set('mobility', e.target.value)} aria-label="Mobility">
            <option value="">Mobile or Fixed?</option><option>Mobile</option><option>Fixed</option>
          </select>
          <label className="check"><input type="checkbox" checked={!!d.evidence} onChange={(e) => set('evidence', e.target.checked)} />Evidence</label>
        </div>
      ); break;
    case 'Assign':
      body = (
        <>
          <textarea rows={2} placeholder="What was done" value={d.note || ''} onChange={(e) => set('note', e.target.value)} />
          <input placeholder="Evidence (file name, optional)" value={d.evidence || ''} onChange={(e) => set('evidence', e.target.value)} />
        </>
      ); break;
    case 'Table grid':
      body = (
        <>
          <table className="ans-table">
            <thead><tr>{cols.map((c) => <th key={c}>{c}</th>)}<th>Check</th><th>Explanation / evidence</th><th /></tr></thead>
            <tbody>
              {rows.map((r, i) => {
                const upd = (k, v) => set('rows', rows.map((x, j) => (j === i ? { ...x, [k]: v } : x)));
                return (
                  <tr key={i}>
                    {cols.map((c) => <td key={c}><input value={(r.cells || {})[c] || ''} onChange={(e) => upd('cells', { ...(r.cells || {}), [c]: e.target.value })} aria-label={c} /></td>)}
                    <td><select value={r.check || ''} onChange={(e) => upd('check', e.target.value)} aria-label="Check">
                      <option value="">—</option>{CHECKS.map((c) => <option key={c}>{c}</option>)}</select></td>
                    <td>{r.check === 'Flagged' && <><input placeholder="Explanation" value={r.explanation || ''} onChange={(e) => upd('explanation', e.target.value)} />
                      <input placeholder="Evidence" value={r.evidence || ''} onChange={(e) => upd('evidence', e.target.value)} /></>}</td>
                    <td><button className="plink muted" onClick={() => set('rows', rows.filter((_, j) => j !== i))}>Remove</button></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          <button className="quiet" onClick={() => set('rows', [...rows, { cells: {} }])}>+ Add row</button>
        </>
      ); break;
    case 'Compare box':
      body = (
        <div className="inline">
          <input type="number" placeholder="Value A" value={d.a ?? ''} onChange={(e) => set('a', e.target.value)} aria-label="Value A" />
          <input type="number" placeholder="Value B" value={d.b ?? ''} onChange={(e) => set('b', e.target.value)} aria-label="Value B" />
          {diff !== null && <span className={outside ? 'ink' : 'sub'}>Difference {diff}{q.setup_limit != null ? ` (limit ${q.setup_limit})` : ''}</span>}
          {outside && <input placeholder="Explain the difference" value={d.explanation || ''} onChange={(e) => set('explanation', e.target.value)} />}
        </div>
      ); break;
    case 'Finding control':
      body = (
        <div className="inline">
          <select value={d.finding || ''} onChange={(e) => set('finding', e.target.value)} aria-label="Finding">
            <option value="">Clear or Flagged?</option><option>Clear</option><option>Flagged</option></select>
          {d.finding === 'Flagged' && <><input placeholder="Explanation" value={d.explanation || ''} onChange={(e) => set('explanation', e.target.value)} />
            <input placeholder="Evidence" value={d.evidence || ''} onChange={(e) => set('evidence', e.target.value)} /></>}
        </div>
      ); break;
    case 'Signature panel':
      body = (
        <div className="inline">
          <input placeholder="Version being signed (e.g. v3)" value={d.version || ''} onChange={(e) => set('version', e.target.value)} aria-label="Version" />
          <select value={d.method || 'Yes'} onChange={(e) => set('method', e.target.value)} aria-label="Method">
            <option>Yes</option><option>Platform signature</option><option>National ID</option></select>
          <label className="check"><input type="checkbox" checked={!!d.signed} onChange={(e) => set('signed', e.target.checked)} />I sign this version (it locks)</label>
        </div>
      ); break;
    default: body = null;
  }

  return (
    <div className="mini-form">
      {body}
      {q.also_needs === 'File drop' && <><p className="sub">Also attach a file (optional)</p>{fileFields('attachment')}</>}
      {q.also_needs === 'Finding control' && (
        <div className="inline">
          <select value={d.finding || ''} onChange={(e) => set('finding', e.target.value)} aria-label="Overall finding">
            <option value="">Overall finding: Clear or Flagged?</option><option>Clear</option><option>Flagged</option></select>
          {d.finding === 'Flagged' && <input placeholder="Explanation" value={d.explanation || ''} onChange={(e) => set('explanation', e.target.value)} />}
        </div>
      )}
      <div className="inline"><button className="primary" onClick={submit}>{q.flow_option === 'Signature panel' ? 'Sign and submit' : 'Submit answer'}</button></div>
      {err && <p className="error">{err}</p>}
    </div>
  );
}

// Shows a submitted answer in the shape of its flow option
export function AnswerView({ q }) {
  const d = q.answer_data;
  if (!d) return q.answer ? <p><strong>Answer:</strong> {q.answer} <span className="hint">({q.source})</span></p> : null;
  const cols = lines(q.setup_columns);
  return (
    <div className="answer-view">
      {q.flow_option === 'Table grid' && d.rows ? (
        <table className="ans-table">
          <thead><tr>{cols.map((c) => <th key={c}>{c}</th>)}<th>Check</th></tr></thead>
          <tbody>{d.rows.map((r, i) => (
            <tr key={i}>{cols.map((c) => <td key={c}>{(r.cells || {})[c]}</td>)}
              <td className={r.check === 'Flagged' ? 'ink' : ''}>{r.check}{r.explanation ? ` — ${r.explanation}` : ''}</td></tr>
          ))}</tbody>
        </table>
      ) : q.flow_option === 'Checklist' && d.items ? (
        <table className="ans-table"><tbody>{Object.entries(d.items).map(([k, v]) => <tr key={k}><td>{k}</td><td>{v}</td></tr>)}</tbody></table>
      ) : <p><strong>Answer:</strong> {q.answer} <span className="hint">({q.source})</span></p>}
      {d.attachment?.file && <p className="sub">Attached: {d.attachment.file} · {d.attachment.mobility}{d.attachment.evidence ? ' · evidence' : ''}</p>}
      {q.also_needs === 'Finding control' && d.finding && <p className={d.finding === 'Flagged' ? 'ink' : 'sub'}>Finding: {d.finding}{d.explanation ? ` — ${d.explanation}` : ''}</p>}
    </div>
  );
}
