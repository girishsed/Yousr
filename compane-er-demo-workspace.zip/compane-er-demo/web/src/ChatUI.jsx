import { useEffect, useRef, useState } from 'react';
import { api } from './api.js';
import Brand from './Brand.jsx';
import Icon from './Icon.jsx';
import Catalogue from './Catalogue.jsx';
import { HomeCard, StandaloneCard, TaskCard, SettingsCard, MastersCard, CalendarCard, PersonalTasksCard, EntitiesCard, ItemPanel } from './ChatPanels.jsx';
import Console from './Console.jsx';
import { CatalogueList, CatalogueItem, ITEM_MENU } from './CatalogueScreens.jsx';
import { ProfileTaskBanner, AddBusinessPrompt, ClientListingCard } from './Journeys.jsx';
import { SignIn, CreateEntityCard, InvitesCard, MyIdCard, ProfileCard, FilesCard, SearchCard, EmailCard, ChatToolCard, ConnectionsCard, DiscoverCard,
  RevenueCard, ComplianceCard, ToolsCard, FullSettingsCard, ReportsCard, KindsCard, ComponentsCard, EntityPersonaCard, DomainPersonasCard, SpineCard } from './ChatPlatform.jsx';

const lc = (s) => (s || '').toLowerCase();
const iso = (d) => d.toISOString().slice(0, 10);
const money = (v) => (v === null || v === undefined || v === '' ? '' : `₹${Number(v).toLocaleString('en-IN')}`);
const QCODE = { 'Do now': 'DN', 'Do later': 'DL', Delegate: 'DG', Delete: 'DX' };
// Tools only (the platform band plus Files); modules are reached by asking
// Cards that open as a page in the content pane rather than inside the chat
const SURFACES = new Set(['task', 'settings', 'item', 'calendar-full', 'email', 'chat', 'files', 'search', 'home', 'manage-catalogue', 'console', 'masters',
  'revenue', 'compliance', 'reports', 'kinds', 'components', 'connections', 'discover', 'personal-tasks', 'entity-persona', 'spine', 'domain-personas',
  'my-id', 'profile', 'create-entity', 'invites', 'standalone']);
const TITLES = { task: 'Task', settings: 'Settings', item: 'Catalogue item', 'calendar-full': 'Calendar', email: 'Email', chat: 'Chat', files: 'Files', search: 'Search',
  home: 'Home', 'manage-catalogue': 'Catalogue', console: 'Krama console', masters: 'Masters', revenue: 'Revenue', compliance: 'Compliance', reports: 'Reports',
  kinds: 'Modules and reports', components: 'Components', connections: 'Connections', discover: 'Discover and Connect', 'personal-tasks': 'Tasks',
  'entity-persona': 'Entity Persona', spine: 'Authority seats', 'domain-personas': 'Domain personas', 'my-id': 'My ID', profile: 'Profile',
  'create-entity': 'Create an entity', invites: 'Invites', standalone: 'Standalone task' };
const SURFACE_TITLE = (c) => (c.kind === 'settings' && c.group ? c.group : TITLES[c.kind] || '');
const SETTINGS_GROUPS = ['Entity', 'User and Access', 'Plan and Usage', 'Entity Data'];
const TOOLS = [['Calendar', 'calendar'], ['Email', 'mail'], ['Chat', 'shared'], ['Files', 'files'], ['Search', 'search']];
const MODULE_OF = { 'Show the catalogue': 'Catalogue', 'Open office supplies': 'Catalogue', 'Start Office supplies with Northwind': 'Catalogue', 'Manage the catalogue': 'Catalogue',
  Vendors: 'Vendors', Connections: 'Connections', Revenue: 'Revenue', Compliance: 'Compliance', Reports: 'Reports', 'Modules and reports': 'Krama', Components: 'Krama', 'Krama console': 'Krama' };
const HELP_ALL = [
  ['Personal', ["What's waiting on me?", 'My tasks', 'My ID', 'Profile', 'Create an entity', 'My invites', 'Discover and Connect', 'Calendar', 'Email', 'Chat', 'Files', 'Search']],
  ['Business', ['Entity persona', 'Authority seats', 'My entities', 'Home', "What's waiting on me?", 'Show my tasks', 'Open INS-0001', 'New standalone task', 'Show the catalogue', 'Open office supplies',
    'Start Office supplies with Northwind', 'Manage the catalogue', 'Vendors', 'Connections', 'Discover and Connect', 'Revenue', 'Compliance',
    'Reports', 'Modules and reports', 'Components', 'Settings', 'Krama console', 'Tools', 'Calendar', 'Email', 'Chat', 'Files', 'Search']],
  ['Platform', ['Masters', 'Domain personas']],
];
const HELP = ["What's waiting on me?", 'Show my calendar for this week', 'Show the catalogue', 'Start Office supplies with Northwind', 'Show my tasks'];

// Second UI: a clean, chat-only screen. Work arrives as cards you act on; every change asks you to confirm first.
export default function ChatUI({ me, users, actingUser, onActing, onClassic, onOpenTask, meta, byKey, isSuper, onUsersChanged }) {
  const [entities, setEntities] = useState([]);
  const [entity, setEntity] = useState(null);
  const [msgs, setMsgs] = useState([]);
  const [text, setText] = useState('');
  const [mode, setMode] = useState('Text');
  const [listening, setListening] = useState(false);
  const [panel, setPanel] = useState(false);
  const [surface, setSurface] = useState(null);      // a tool or page open in the content pane
  const [mtab, setMtab] = useState('chat');            // phones: Content or Chat
  const [userMenu, setUserMenu] = useState(false);
  const [tools, setTools] = useState(false);
  const [signedIn, setSignedIn] = useState(true);
  const [access, setAccess] = useState(null);
  useEffect(() => { setAccess(null); if (entity) api.do('my_access', { entity_id: entity.entity_id }).then(setAccess).catch(() => {}); }, [entity?.entity_id, actingUser]); // eslint-disable-line react-hooks/exhaustive-deps
  // Work Persona decides what shows: modules, and admin-only settings
  // Journey prompts when a space opens: profile task and add-business (Personal), client listing (entity)
  useEffect(() => {
    if (!signedIn) return;
    Promise.all([api.do('my_actions', {}), api.home()]).then(([a, h]) => {
      const cards = [];
      if (!entity && a.profile) cards.push({ kind: 'profile-task' });
      if (!entity && (h.entities || []).length === 0) cards.push({ kind: 'add-business' });
      const cl = entity && (a.client_listing || []).find((x) => x.entity_id === entity.entity_id);
      if (cl) cards.push({ kind: 'client-listing', taskId: cl.task_id });
      if (cards.length) setMsgs((m) => (m.length ? m : [{ id: Date.now(), from: 'ai', body: '', cards }]));
    }).catch(() => {});
  }, [entity?.entity_id, actingUser, signedIn]); // eslint-disable-line react-hooks/exhaustive-deps
  const can = (m) => !entity || !access || access.admin || (access.modules || []).includes(m);
  const [searching, setSearching] = useState(false);
  const endRef = useRef(null);
  const recRef = useRef(null);
  const companies = users.filter((u) => u.user_type === 'Company');
  const people = users.filter((u) => u.user_type === 'Individual');

  useEffect(() => {
    setMsgs([]);
    api.home().then((h) => { setEntities(h.entities || []); setEntity(null); }).catch(() => {});
  }, [actingUser]);
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [msgs]);

  const push = (m) => setMsgs((x) => [...x, { id: Math.random().toString(36).slice(2), ...m }]);
  const say = (body, cards) => {
    // Pages and tools open in the content pane beside the chat; small cards stay in the chat
    const big = (cards || []).find((c) => SURFACES.has(c.kind));
    if (big) { setSurface(big); setMtab('content'); }
    const rest = (cards || []).filter((c) => c !== big);
    push({ from: 'ai', body: big ? `Opened ${SURFACE_TITLE(big) || 'it'} beside the chat.` : body, cards: rest });
    if (mode === 'Audio' && body && window.speechSynthesis) {
      const u = new SpeechSynthesisUtterance(body); u.lang = 'en-IN'; window.speechSynthesis.speak(u);
    }
  };

  async function handle(raw) {
    const t = lc(raw).trim();
    if (!t) return;
    push({ from: 'me', body: raw, spoken: mode === 'Audio' });
    try {
      const GATES = [[/krama console|^console|^krama$|components?|modules/, 'Krama'], [/catalogue|catalog|^start |^open (?!ins-)|items|products|services/, 'Catalogue'],
        [/vendors?/, 'Vendors'], [/connections?|clients and vendors|^connect$/, 'Connections'], [/^revenue|sales/, 'Revenue'], [/^compliance/, 'Compliance'],
        [/^reports?$|analytics/, 'Reports'], [/waiting|my tasks|show my tasks|^home$|standalone|open ins-/, 'WOM']];
      if (entity) for (const [re, m] of GATES) if (re.test(t) && !can(m)) return say(`Your Work Persona${access?.persona ? ` (${access.persona})` : ''} does not include ${m}. Ask your entity admin.`);
      if (entity && /masters|manage.*catalogue|edit.*catalogue/.test(t) && access && !access.admin && !isSuper) return say('Only an entity admin can do that.');
      if (/entity persona|my persona|what applies/.test(t)) return entity ? say(`${entity.name} · Entity Persona`, [{ kind: 'entity-persona' }]) : say('Choose an entity from the menu first.');
      if (/domain personas?/.test(t)) return say('Domain personas', [{ kind: 'domain-personas' }]);
      if (entity && /seats|authority spine|authority/.test(t)) return say(`${entity.name} · Authority seats`, [{ kind: 'spine' }]);
      if (/^(help|what can you do|hi|hello)/.test(t)) return say('You can ask me things like these:', [{ kind: 'help-all' }]);
      const sw = t.match(/^(?:switch to|work as)\s+(.+)$/);
      if (sw) {
        const e = entities.find((x) => lc(x.name).includes(sw[1].trim()));
        if (e) { setEntity(e); return say(`Now working in ${e.name}.`); }
        const p = people.find((x) => lc(x.name).includes(sw[1].trim()));
        if (p) { onActing(p.user_id); return; }
        return say("I couldn't find that entity or person.");
      }
      if (/^(my )?id$|my id|identity/.test(t)) return !entity ? say('', [{ kind: 'my-id' }]) : say('My ID is in your personal space. Choose Personal in the menu.');
      if (!entity && /^(profile|settings|my profile|personal settings)$/.test(t)) return say('', [{ kind: 'profile' }]);
      if (/(create|new|add) (an )?entity|create a business/.test(t)) return say('', [{ kind: 'create-entity' }]);
      if (/invites?|join an entity/.test(t)) return say('', [{ kind: 'invites' }]);
      if (/discover/.test(t)) return say('', [{ kind: 'discover' }]);
      if (/^files?$|my files|show files/.test(t)) return say('', [{ kind: 'files' }]);
      const sr = t.match(/^search\s*(.*)$/);
      if (sr) return say('', [{ kind: 'search', q: sr[1] }]);
      if (/^e-?mail|inbox|my email/.test(t)) return say('', [{ kind: 'email' }]);
      if (/^chat$|messages|my chat/.test(t)) return say('', [{ kind: 'chat' }]);
      if (entity && /connections?|clients and vendors|^connect$/.test(t)) return say(`${entity.name} · Connections`, [{ kind: 'connections' }]);
      if (entity && /^revenue|sales/.test(t)) return say(`${entity.name} · Revenue`, [{ kind: 'revenue' }]);
      if (entity && /^compliance/.test(t)) return say(`${entity.name} · Compliance`, [{ kind: 'compliance' }]);
      if (entity && /^tools$/.test(t)) return say('Tools', [{ kind: 'tools' }]);
      if (entity && /modules|report and analytics krama/.test(t)) return say('Modules and Report and Analytics', [{ kind: 'kinds' }]);
      if (entity && /^reports?$|analytics/.test(t)) return say(`${entity.name} · Reports`, [{ kind: 'reports' }]);
      if (entity && /components?/.test(t)) return say('Reusable components', [{ kind: 'components' }]);
      if (entity && /user and access|^users$|^people$/.test(t)) return say(`${entity.name} · Settings`, [{ kind: 'settings' }]);
      if (/^(my )?(entities|businesses|business)$/.test(t)) return say('Your entities:', [{ kind: 'entities' }]);
      if (/(masters|platform admin|tables)/.test(t)) return isSuper ? say('Masters:', [{ kind: 'masters' }]) : say('Masters are for the platform super-user.');
      if (!entity && /(my tasks|personal tasks|consent|add task)/.test(t)) return say('', [{ kind: 'personal-tasks' }]);
      if (/^calendar$|my calendar|show calendar|^calendar /.test(t) && !/this week/.test(t)) return say('', [{ kind: 'calendar-full' }]);
      const needsEntity = /(catalogue|catalog|items|products|services|start |begin |raise |create |vendors|tasks|runs|agree )/.test(`${t} `);
      if (!entity && needsEntity) return say('That is business work. Choose an entity from the menu to switch to compane.');
      if (!entity && /(waiting|pending|on me|to do|todo|today|my work)/.test(t)) {
        const rows = (await api.personalTasks()).filter((x) => x.status === 'To do');
        if (!rows.length) return say('Nothing personal is waiting on you.');
        return say(`${rows.length} personal item${rows.length === 1 ? '' : 's'}:`, [{ kind: 'personal', rows }]);
      }
      if (entity && /^(home|overview|focus|my home)$/.test(t)) return say(`${entity.name} · Home`, [{ kind: 'home' }]);
      if (entity && /(new standalone|standalone task|new task)/.test(t)) return say('', [{ kind: 'standalone' }]);
      const openItem = t.match(/^open\s+(?!ins-)(.+)$/);
      if (entity && openItem) {
        const c = await api.catalogue();
        const it = c.items.find((i) => i.entity_id === entity.entity_id && lc(i.name).includes(openItem[1].trim()));
        if (it) return say('', [{ kind: 'item', itemId: it.item_id }]);
      }
      const open = t.match(/(?:open|show|history(?: of)?)\s+(ins-\d+)/);
      if (entity && open) {
        const runs = await api.runs();
        const r = runs.find((x) => lc(x.label).startsWith(open[1]));
        if (!r) return say(`I couldn't find ${open[1].toUpperCase()}.`);
        return say('', [{ kind: 'task', runId: r.run_id }]);
      }
      if (entity && /(manage|edit|add|assign).*(catalogue|catalog|item)/.test(t)) return say(`${entity.name} · Catalogue`, [{ kind: 'manage-catalogue' }]);
      if (entity && /^vendors?$|my vendors|show vendors/.test(t)) {
        const rows = await api.entityView(entity.entity_id, 'vendors');
        return rows.length ? say(`${entity.name} buys from:`, [{ kind: 'vendors', rows }]) : say('No vendors yet.');
      }
      if ((entity || isSuper) && /(krama console|^console|^krama$)/.test(t)) return say('Krama console', [{ kind: 'console' }]);
      if (entity && /^settings/.test(t)) return say(`${entity.name} · Settings`, [{ kind: 'settings' }]);
      if (/(waiting|pending|on me|to do|todo|today|my work)/.test(t)) {
        const h = await api.home();
        const items = [...h.to_decide.map((x) => ({ ...x, kind: 'decide' })), ...h.to_answer.map((x) => ({ ...x, kind: 'answer' }))];
        if (!items.length) return say('Nothing is waiting on you right now.');
        return say(`${items.length} item${items.length === 1 ? '' : 's'} need${items.length === 1 ? 's' : ''} you.`, items.map((x) => ({ kind: 'work', x })));
      }
      if (/(calendar|this week|schedule|due)/.test(t)) {
        const d = new Date(); const e = new Date(); e.setDate(d.getDate() + 7);
        const cal = await api.calendar(iso(d), iso(e));
        const rows = (cal.items || cal || []).filter((r) => r.kind !== 'activity').slice(0, 12);
        if (!rows.length) return say('Nothing in the next seven days.');
        return say('Here is your next seven days:', [{ kind: 'calendar', rows }]);
      }
      const start = t.match(/^(?:start|begin|raise|create)\s+(?:a\s+task\s+(?:for\s+)?)?(.+?)(?:\s+(?:with|for)\s+(.+))?$/);
      if (start) {
        const c = await api.catalogue();
        const items = c.items.filter((i) => !entity || i.entity_id === entity.entity_id);
        const it = items.find((i) => lc(start[1]).includes(lc(i.name)) || lc(i.name).includes(lc(start[1]).trim()));
        if (!it) return say("I couldn't find that item in the catalogue.", [{ kind: 'catalogue', items }]);
        const cp = start[2] ? companies.find((x) => lc(x.name).includes(lc(start[2]).replace(/^the\s+/, '').split(' ')[0])) : null;
        const rel = /client/.test(t) ? 'Client' : it.has_external ? 'Vendor' : (entity && 'Department');
        return say(`Starting ${it.name}. Check the details and confirm:`, [{ kind: 'start', it, rel, cp: cp?.user_id || '' }]);
      }
      if (/(catalogue|catalog|items|products|services|what do we (sell|buy))/.test(t)) {
        const c = await api.catalogue();
        const items = c.items.filter((i) => !entity || i.entity_id === entity.entity_id);
        if (!items.length) return say('There are no catalogue items here yet.');
        return say(`${entity?.name || 'Your'} catalogue`, [{ kind: 'manage-catalogue' }]);
      }
      const ag = t.match(/^agree\s+(.+)$/);
      if (ag) {
        const h = await api.home();
        const x = h.to_decide.find((w) => lc(`${w.question} ${w.item} ${w.label}`).includes(ag[1].replace(/^the\s+/, '').split(' ')[0]));
        if (!x) return say("I couldn't find that among the items waiting for your decision.");
        return say('', [{ kind: 'confirm-agree', x }]);
      }
      if (/(tasks|runs|instances|open work)/.test(t)) {
        const runs = await api.runs();
        const mine = runs.filter((r) => !entity || r.entity_name === entity.name || r.counterparty_name === entity.name);
        return say(`${mine.length} task${mine.length === 1 ? '' : 's'}:`, [{ kind: 'runs', runs: mine.slice(0, 10) }]);
      }
      const srch = t.match(/^(?:search|find|look for)\s+(.+)$/);
      if (srch) return runSearch(srch[1].trim());
      if (/(vendor|supplier)/.test(t)) {
        if (!entity) return say('Choose an entity first.');
        const rows = await api.entityView(entity.entity_id, 'vendors');
        return rows.length ? say(`${entity.name} buys from:`, [{ kind: 'vendors', rows }]) : say('No vendors yet.');
      }
      if (/(krama|workflow|console)/.test(t)) return say('The Krama console opens in the classic view.', [{ kind: 'open-classic', page: 'settings', tab: 'console' }]);
      if (/(setting)/.test(t)) return say('Settings open in the classic view.', [{ kind: 'open-classic', page: 'settings', tab: 'krama' }]);
      if (/(report|estimat|execution|output document)/.test(t)) return say('Reports sit inside each task. Ask for your tasks, then open one and choose Reports.');
      if (/(email|mail|files?|documents?|chat)/.test(t)) return say("That isn't built yet.");
      return say("I can't do that yet. Try one of these:", [{ kind: 'help-all' }]);
    } catch (e) { say(e.message); }
  }

  async function runSearch(q) {
    const [c, runs] = await Promise.all([api.catalogue(), api.runs()]);
    const items = c.items.filter((i) => (!entity || i.entity_id === entity.entity_id) && lc(i.name).includes(lc(q)));
    const rs = runs.filter((r) => (!entity || r.entity_name === entity.name || r.counterparty_name === entity.name)
      && lc(`${r.item} ${r.label} ${r.counterparty_name || ''}`).includes(lc(q)));
    if (!items.length && !rs.length) return say(`Nothing in ${entity?.name || 'this entity'} matches "${q}".`);
    return say(`Found for "${q}":`, [...(items.length ? [{ kind: 'catalogue', items }] : []), ...(rs.length ? [{ kind: 'runs', runs: rs.slice(0, 10) }] : [])]);
  }

  async function tool(name) {
    setTools(false);
    if (name === 'Search') { setMode('Text'); setSearching(true); return; }
    push({ from: 'me', body: name, tool: true });
    try {
      if (name === 'Calendar') return say('', [{ kind: 'calendar-full' }]);
      if (name === 'Email') return say('', [{ kind: 'email' }]);
      if (name === 'Chat') return say('', [{ kind: 'chat' }]);
      if (name === 'Files') return say('', [{ kind: 'files' }]);
      if (name === 'Search') return say('', [{ kind: 'search', q: '' }]);
      return say(`${name} isn't built yet.`);
    } catch (e) { say(e.message); }
  }

  // Search covers only the current space (this entity): its catalogue items and its tasks
  async function search(q) {
    setSearching(false);
    push({ from: 'me', body: `Search: ${q}` });
    try {
      const needle = lc(q).trim();
      const [c, runs] = await Promise.all([api.catalogue(), api.runs()]);
      const items = c.items.filter((i) => (!entity || i.entity_id === entity.entity_id) && lc(i.name).includes(needle));
      const tasks = runs.filter((r) => (!entity || r.entity_name === entity.name || r.counterparty_name === entity.name)
        && lc(`${r.item} ${r.label} ${r.counterparty_name || ''}`).includes(needle));
      if (!items.length && !tasks.length) return say(`Nothing in ${entity?.name || 'this space'} matches "${q}".`);
      const cards = [];
      if (items.length) cards.push({ kind: 'catalogue', items });
      if (tasks.length) cards.push({ kind: 'runs', runs: tasks.slice(0, 10) });
      return say(`Found in ${entity?.name || 'this space'}:`, cards);
    } catch (e) { say(e.message); }
  }

  function send() { const v = text; setText(''); if (searching) search(v); else handle(v); }
  function listen() {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) { say('Audio needs Chrome or Edge on this device. Switch to Text, or try another browser.'); return; }
    if (listening) { recRef.current?.stop(); return; }
    const r = new SR(); r.lang = 'en-IN'; r.interimResults = false;
    r.onresult = (ev) => handle(ev.results[0][0].transcript);
    r.onend = () => setListening(false);
    r.onerror = () => setListening(false);
    recRef.current = r; setListening(true); r.start();
  }

  const addCard = (card) => (SURFACES.has(card.kind) ? (setSurface(card), setMtab('content')) : push({ from: 'ai', body: '', cards: [card] }));
  const refreshEntities = () => api.home().then((h) => setEntities(h.entities || [])).catch(() => {});
  const ctx = { say, push, entity, companies, people, meta, byKey, isSuper, entities, addCard, me, refreshEntities, tool, can, access,
    openTaskCard: (runId, qrId) => addCard({ kind: 'task', runId, qrId }),
    switchEntity: (e) => { setEntity(e); setMsgs([]); },
    onOpenTask: (r) => addCard({ kind: 'task', runId: r.run_id, qrId: r.qr_id }), onClassicPage: (pg) => onClassic({ ...pg, entity }),
    refresh: () => handle("what's waiting on me") };

  if (!signedIn) {
    return <SignIn people={people} onSignedIn={async (uid, isNew) => { if (isNew && onUsersChanged) await onUsersChanged(); onActing(uid); setSignedIn(true); setEntity(null); }} />;
  }

  const spaceName = entity ? entity.name : 'Personal';
  const pick = (e) => { setEntity(e); setMsgs([]); setSurface(null); setMtab('chat'); };
  return (
    <div className="cf" onClick={() => { if (tools) setTools(false); if (userMenu) setUserMenu(false); }}>
      <header className="cf-hdr">
        <button className="cf-icon" aria-label="Spaces" aria-pressed={panel} onClick={(e) => { e.stopPropagation(); setPanel(!panel); }}><Icon name="menu" size={20} /></button>
        <Brand name={entity ? 'compane' : 'Yousr'} height={22} />
        <span className="cf-space">{spaceName}</span>
      </header>

      {surface && (
        <nav className="cf-mtabs" role="tablist">
          {[['content', 'Content'], ['chat', 'Chat']].map(([k, l]) => <button key={k} role="tab" aria-selected={mtab === k} className="cf-mtab" onClick={() => setMtab(k)}>{l}</button>)}
        </nav>
      )}

      <div className={`cf-main${panel ? ' rail-open' : ''}${surface ? ' has-surface' : ''} show-${mtab}`}>
        {panel && (
          <aside className="cf-rail">
            <button className={!entity ? 'cf-ritem on' : 'cf-ritem'} onClick={() => pick(null)}><Icon name="person" />Personal</button>
            {entities.map((e) => (
              <button key={e.entity_id} className={entity?.entity_id === e.entity_id ? 'cf-ritem on' : 'cf-ritem'} onClick={() => pick(e)}><Icon name="business" />{e.name}</button>
            ))}
            <div className="cf-rfoot" onClick={(e) => e.stopPropagation()}>
              {userMenu && (
                <div className="cf-umenu">
                  <p className="cf-ulabel">Settings</p>
                  {entity
                    ? SETTINGS_GROUPS.map((g) => <button key={g} onClick={() => { setUserMenu(false); addCard({ kind: 'settings', group: g }); }}>{g}</button>)
                    : <button onClick={() => { setUserMenu(false); addCard({ kind: 'profile' }); }}>Profile</button>}
                  <p className="cf-ulabel">View</p>
                  <button onClick={() => onClassic()}>Classic view</button>
                  <button onClick={() => { setMsgs([]); setSurface(null); }}>New chat</button>
                  <button onClick={async () => { setUserMenu(false); setMsgs([]); setSurface(null); await api.signOut(); setSignedIn(false); }}>Sign out</button>
                </div>
              )}
              <button className="cf-me" onClick={() => setUserMenu(!userMenu)}>
                <span className="avatar">{me.name.split(' ').map((x) => x[0]).join('').slice(0, 2)}</span><span className="cf-me-name">{me.name}</span><Icon name="settings" size={16} />
              </button>
            </div>
          </aside>
        )}
        {surface && (
          <section className="cf-content">
            <div className="cf-content-head">
              <b>{SURFACE_TITLE(surface)}</b>
              <button className="cf-icon small" aria-label="Close" onClick={() => { setSurface(null); setMtab('chat'); }}><Icon name="x" size={16} /></button>
            </div>
            <div className="cf-content-body"><Card key={JSON.stringify(surface)} c={surface} ctx={ctx} onAsk={handle} /></div>
          </section>
        )}
        <section className="cf-chat">
          <main className="cu-thread">
            {msgs.map((m) => (
              <div key={m.id} className={m.from === 'me' ? 'cu-me' : 'cu-ai'}>
                {m.body && <p className={m.spoken ? 'spoken' : ''}>{m.spoken ? `“${m.body}”` : m.body}</p>}
                {(m.cards || []).map((c, i) => <Card key={i} c={c} ctx={ctx} onAsk={handle} />)}
              </div>
            ))}
            <div ref={endRef} />
          </main>
        </section>
      </div>

      <footer className="cf-composer" onClick={(e) => e.stopPropagation()}>
        {tools && (
          <div className="cf-tray">
            {TOOLS.map(([n, ic]) => <button key={n} onClick={() => { setTools(false); tool(n); }}><Icon name={ic} size={18} /><span>{n}</span></button>)}
          </div>
        )}
        <div className={listening ? 'cf-box listening' : 'cf-box'}>
          <button className="cf-icon small plain" aria-label="Tools" aria-pressed={tools} onClick={() => setTools(!tools)}><Icon name="grid" size={18} /></button>
          {listening
            ? <p className="cf-listen">Listening…</p>
            : <input value={text} onChange={(e) => setText(e.target.value)} placeholder={searching ? `Search ${entity?.name || ''}` : 'Type or ask anything'}
                onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); send(); } }} aria-label="Message" />}
          <button className="cf-icon small plain" aria-label={listening ? 'Stop' : 'Record audio'} onClick={() => { setMode('Audio'); listen(); }}><Icon name="mic" size={18} /></button>
          <button className="cf-icon small plain" aria-label="Send" disabled={!text.trim()} onClick={send}><Icon name="arrowup" size={18} /></button>
        </div>
      </footer>
    </div>
  );
}

function Card({ c, ctx, onAsk }) {
  if (c.kind === 'help-all') {
    return (
      <div className="cu-card">
        {HELP_ALL.filter(([g]) => g !== 'Platform' || ctx.isSuper).map(([g, list]) => (
          <div key={g}><p className="cu-gh">{g}</p><div className="cu-sugg left">{list.filter((h) => !MODULE_OF[h] || ctx.can(MODULE_OF[h])).map((h) => <button key={h} onClick={() => onAsk(h)}>{h}</button>)}</div></div>
        ))}
      </div>
    );
  }
  if (c.kind === 'profile-task') return <ProfileTaskBanner />;
  if (c.kind === 'add-business') return <AddBusinessPrompt onAdd={() => ctx.addCard({ kind: 'create-entity' })} />;
  if (c.kind === 'client-listing') return ctx.entity ? <ClientListingCard entity={ctx.entity} taskId={c.taskId} /> : null;
  if (c.kind === 'entity-persona') return ctx.entity ? <EntityPersonaCard entity={ctx.entity} ctx={ctx} /> : null;
  if (c.kind === 'domain-personas') return <DomainPersonasCard ctx={ctx} />;
  if (c.kind === 'spine') return ctx.entity ? <SpineCard entity={ctx.entity} /> : null;
  if (c.kind === 'my-id') return <MyIdCard />;
  if (c.kind === 'profile') return <ProfileCard />;
  if (c.kind === 'create-entity') return <CreateEntityCard me={ctx.me} ctx={ctx} />;
  if (c.kind === 'invites') return <InvitesCard ctx={ctx} />;
  if (c.kind === 'discover') return <DiscoverCard entity={ctx.entity} ctx={ctx} />;
  if (c.kind === 'files') return <FilesCard entity={ctx.entity} />;
  if (c.kind === 'search') return <SearchCard entity={ctx.entity} ctx={ctx} q0={c.q} />;
  if (c.kind === 'email') return <EmailCard entity={ctx.entity} surface />;
  if (c.kind === 'chat') return <ChatToolCard entity={ctx.entity} />;
  if (c.kind === 'connections') return ctx.entity ? <ConnectionsCard entity={ctx.entity} ctx={ctx} to0={c.to} /> : null;
  if (c.kind === 'revenue') return ctx.entity ? <RevenueCard entity={ctx.entity} ctx={ctx} /> : null;
  if (c.kind === 'compliance') return ctx.entity ? <ComplianceCard entity={ctx.entity} ctx={ctx} /> : null;
  if (c.kind === 'tools') return <ToolsCard onTool={(n) => ctx.tool(n)} />;
  if (c.kind === 'reports') return ctx.entity ? <ReportsCard entity={ctx.entity} /> : null;
  if (c.kind === 'kinds') return ctx.entity ? <KindsCard entity={ctx.entity} /> : null;
  if (c.kind === 'components') return ctx.entity ? <ComponentsCard entity={ctx.entity} /> : null;
  if (c.kind === 'item') return <WsItem itemId={c.itemId} />;
  if (c.kind === 'entities') return <EntitiesCard entities={ctx.entities} ctx={ctx} />;
  if (c.kind === 'home') return ctx.entity ? <HomeCard entity={ctx.entity} ctx={ctx} /> : null;
  if (c.kind === 'standalone') return ctx.entity ? <StandaloneCard entity={ctx.entity} id={c.id} ctx={ctx} /> : null;
  if (c.kind === 'task') return <TaskCard runId={c.runId} focusQr={c.qrId} ctx={ctx} />;
  if (c.kind === 'settings') return ctx.entity ? <FullSettingsCard entity={ctx.entity} ctx={ctx} group={c.group} /> : <ProfileCard />;
  if (c.kind === 'console') return <div className="cu-card wide"><Console meta={ctx.meta} /></div>;
  if (c.kind === 'manage-catalogue') return ctx.entity ? <div className="cu-card wide ws-embed"><CatalogueList entity={ctx.entity} onOpen={(itemId) => ctx.addCard({ kind: 'item', itemId })} /></div> : null;
  if (c.kind === 'masters') return <MastersCard ctx={ctx} />;
  if (c.kind === 'calendar-full') return <CalendarCard ctx={ctx} />;
  if (c.kind === 'personal-tasks') return <PersonalTasksCard />;
  if (c.kind === 'help') return <div className="cu-card cu-sugg">{HELP.map((h) => <button key={h} onClick={() => onAsk(h)}>{h}</button>)}</div>;
  if (c.kind === 'work') return <WorkCard x={c.x} ctx={ctx} />;
  if (c.kind === 'confirm-agree') return <AgreeConfirm x={c.x} ctx={ctx} />;
  if (c.kind === 'calendar') {
    return (
      <div className="cu-card">
        {c.rows.map((r, i) => <p key={i}><span className="sub">{r.date}</span> · {r.title} <span className="sub">{[r.process, r.entity_name].filter(Boolean).join(' · ')}</span></p>)}
      </div>
    );
  }
  if (c.kind === 'runs') {
    return (
      <div className="cu-card">
        {c.runs.map((r) => (
          <div key={r.run_id} className="cu-line">
            <span><b>{r.item}</b> <span className="sub">{[r.label, r.counterparty_name, r.result || r.status].filter(Boolean).join(' · ')}</span></span>
            <button className="cu-link" onClick={() => ctx.openTaskCard(r.run_id)}>Open</button>
          </div>
        ))}
      </div>
    );
  }
  if (c.kind === 'personal') {
    return (
      <div className="cu-card">
        {c.rows.map((x) => (
          <div key={x.task_id} className="cu-line">
            <span><b>{x.title}</b> <span className="sub">{[x.kind === 'Personal' ? 'Personal' : x.requested_by, x.purpose, x.due_date && `due ${x.due_date}`].filter(Boolean).join(' · ')}</span></span>
            <span className="qc">{QCODE[x.quadrant] || 'DL'}</span>
          </div>
        ))}
      </div>
    );
  }
  if (c.kind === 'vendors') {
    return (
      <div className="cu-card">
        {c.rows.map((v) => <div key={v.entity_id} className="cu-line"><span><b>{v.name}</b> <span className="sub">{[v.relationship, v.persona].filter(Boolean).join(' · ')}</span></span><span className="sub">{v.open} open</span></div>)}
      </div>
    );
  }
  if (c.kind === 'open-classic') return <div className="cu-card"><button className="cu-link" style={{ alignSelf: 'flex-start' }} onClick={() => ctx.onClassicPage(c)}>Open {c.tab === 'console' ? 'the Krama console' : 'Settings'}</button></div>;
  if (c.kind === 'catalogue') return <>{c.items.map((it) => <ItemCard key={it.item_id} it={it} ctx={ctx} />)}</>;
  if (c.kind === 'start') return <StartCard it={c.it} rel0={c.rel} cp0={c.cp} ctx={ctx} />;
  if (c.kind === 'started') {
    return (
      <div className="cu-card">
        <p><b>Started {c.label}</b> · {c.item}</p><p className="sub">{c.krama} · rooms set up · you are its Requestor/Conductor.</p>
        <button className="cu-link" onClick={() => ctx.openTaskCard(c.run.run_id)}>Open the task</button>
      </div>
    );
  }
  return null;
}

function WorkCard({ x, ctx }) {
  const [state, setState] = useState(null);
  const [reason, setReason] = useState('');
  const [expl, setExpl] = useState('');
  if (state === 'done') return <div className="cu-card done">{x.question} · {x.label} — done.</div>;
  return (
    <div className="cu-card">
      <div className="cu-line"><b>{x.question}</b><span className="qc">{QCODE[x.quadrant] || 'DL'}</span></div>
      <p className="sub">{x.item} · {x.label} · {x.kind === 'decide' ? `submitted by ${x.from}` : x.state} · due {x.due_date}</p>
      {x.kind === 'decide' && !state && (
        <div className="cu-actions">
          <button className="primary" onClick={() => setState('confirm')}>Agree</button>
          <button className="quiet" onClick={() => setState('contest')}>Contest</button>
          <button className="cu-link" onClick={() => ctx.openTaskCard(x.run_id, x.qr_id)}>Show details</button>
        </div>
      )}
      {x.kind === 'answer' && <div className="cu-actions"><button className="quiet" onClick={() => ctx.openTaskCard(x.run_id, x.qr_id)}>Answer it</button></div>}
      {state === 'confirm' && (
        <div className="cu-confirm">
          <p>Agree <b>{x.question}</b> on {x.label}? This closes the question.</p>
          <div className="cu-actions">
            <button className="primary" onClick={async () => { try { await api.act(x.qr_id, 'agree'); setState('done'); } catch (e) { setState(null); ctx.say(e.message); } }}>Confirm</button>
            <button className="quiet" onClick={() => setState(null)}>Cancel</button>
          </div>
        </div>
      )}
      {state === 'contest' && (
        <div className="cu-confirm">
          <select value={reason} onChange={(e) => setReason(e.target.value)} aria-label="Reason">
            <option value="">Reason…</option>{['Error found', 'Incomplete', 'Evidence missing', 'Disagree', 'Remove', 'Other'].map((r) => <option key={r}>{r}</option>)}
          </select>
          <input placeholder="Explanation" value={expl} onChange={(e) => setExpl(e.target.value)} aria-label="Explanation" />
          <div className="cu-actions">
            <button className="primary" disabled={!reason || !expl.trim()} onClick={async () => { try { await api.act(x.qr_id, 'contest', { reason, explanation: expl }); setState('done'); } catch (e) { ctx.say(e.message); } }}>Confirm contest</button>
            <button className="quiet" onClick={() => setState(null)}>Cancel</button>
          </div>
        </div>
      )}
    </div>
  );
}

function AgreeConfirm({ x, ctx }) {
  const [done, setDone] = useState(false);
  if (done) return <div className="cu-card done">Agreed: {x.question} · {x.label}.</div>;
  return (
    <div className="cu-card cu-confirm">
      <p>Agree <b>{x.question}</b> on {x.item} ({x.label})? This closes the question.</p>
      <div className="cu-actions">
        <button className="primary" onClick={async () => { try { await api.act(x.qr_id, 'agree'); setDone(true); } catch (e) { ctx.say(e.message); } }}>Confirm</button>
        <button className="quiet" onClick={() => ctx.say('Cancelled. Nothing was changed.')}>Cancel</button>
      </div>
    </div>
  );
}

function ItemCard({ it, ctx }) {
  const [open, setOpen] = useState(false);
  const [starting, setStarting] = useState(false);
  const lib = it.library || {};
  return (
    <div className="cu-card">
      <div className="cu-line"><b>{it.name}</b><span className="sub">{lib.item_type || (it.has_external ? 'External' : 'Internal')}</span></div>
      <p className="sub">
        {[it.visibility && `Visibility: ${it.visibility}`, it.offering && `Offered by ${it.offering}`, it.buying && `Bought by ${it.buying}`, it.pricing && `Pricing: ${it.pricing}`].filter(Boolean).join(' · ') || 'No details added yet.'}
      </p>
      {open && (
        <div className="cu-detail">
          {lib.name && <p>Library item: {lib.name}{lib.seller_persona ? ` · seller ${lib.seller_persona}` : ''}{lib.buyer_persona ? ` · buyer ${lib.buyer_persona}` : ''}</p>}
          {it.variants && <p>Variants: {it.variants}</p>}
          {it.seats && <p>Seats: {it.seats}</p>}
          <p className="sub">Kramas it runs:</p>
          {it.kramas.map((k) => (
            <p key={k.krama_id}>{k.name} v{k.version} <span className="sub">· {k.ownership_type}{k.relationships?.length ? ` · ${k.relationships.map((r) => `${r.relationship}: ${r.persona}`).join(', ')}` : ''}</span></p>
          ))}
        </div>
      )}
      <div className="cu-actions">
        <button className="primary" onClick={() => setStarting(!starting)}>Start a task</button>
        <button className="quiet" onClick={() => setOpen(!open)}>{open ? 'Hide details' : 'Details'}</button>
        <button className="quiet" onClick={() => ctx.addCard({ kind: 'item', itemId: it.item_id })}>Open item</button>
      </div>
      {starting && <StartCard it={it} rel0={it.has_external ? 'Vendor' : 'Department'} cp0="" ctx={ctx} inline />}
    </div>
  );
}

function StartCard({ it, rel0, cp0, ctx, inline }) {
  const external = it.has_external;
  const RELS = external ? ['Pre-vendor', 'Vendor', 'Pre-client', 'Client'] : ['Department', 'Business Unit'];
  const [rel, setRel] = useState(RELS.includes(rel0) ? rel0 : RELS[0]);
  const [cp, setCp] = useState(cp0 || '');
  const [opts, setOpts] = useState([]);
  const [k, setK] = useState('');
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    setMsg('');
    if (external && !cp) { setOpts([]); return; }
    api.resolve(it.item_id, rel, external ? cp : '').then((o) => { setOpts(o); setK(o[0]?.krama_id || ''); }).catch((e) => setMsg(e.message));
  }, [rel, cp]); // eslint-disable-line react-hooks/exhaustive-deps
  const cpName = ctx.companies.find((c) => c.user_id === cp)?.name;
  return (
    <div className={inline ? 'cu-confirm' : 'cu-card cu-confirm'}>
      {!inline && <b>{it.name}</b>}
      <div className="cu-actions">
        <select value={rel} onChange={(e) => setRel(e.target.value)} aria-label="Relationship">{RELS.map((r) => <option key={r}>{r}</option>)}</select>
        {external && (
          <select value={cp} onChange={(e) => setCp(e.target.value)} aria-label="With">
            <option value="">With whom?</option>
            {ctx.companies.filter((c) => c.user_id !== ctx.entity?.entity_id).map((c) => <option key={c.user_id} value={c.user_id}>{c.name}</option>)}
          </select>
        )}
      </div>
      {external && cp && opts.length === 0 && !msg && <p className="sub">No Krama is mapped for {rel} with {cpName}'s persona type, so this can't start with them.</p>}
      {opts.length > 0 && (
        <p>Runs <b>{opts.find((o) => o.krama_id === k)?.name}</b>{external ? ` with ${cpName}` : ''} as {rel}.
          {opts.length > 1 && <select value={k} onChange={(e) => setK(e.target.value)} aria-label="Krama">{opts.map((o) => <option key={o.krama_id} value={o.krama_id}>{o.name}</option>)}</select>}
        </p>
      )}
      {msg && <p className="error">{msg}</p>}
      <div className="cu-actions">
        <button className="primary" disabled={busy || !opts.length} onClick={async () => {
          setBusy(true); setMsg('');
          try {
            const r = await api.activate(it.item_id, { relationship: rel, counterparty: external ? cp : null, krama_id: k || null });
            const run = await api.run(r.run_id);
            ctx.push({ from: 'ai', body: '', cards: [{ kind: 'started', label: run.label, item: it.name, krama: `${run.krama} v${run.version}`,
              run: { run_id: r.run_id, company_user_id: it.entity_id, entity_name: it.entity_name } }] });
          } catch (e) { setMsg(e.message); } finally { setBusy(false); }
        }}>Confirm and start</button>
      </div>
    </div>
  );
}

// A catalogue item, with the workspace's own item pages and its item menu as chips
function WsItem({ itemId }) {
  const [section, setSection] = useState('overview');
  return (
    <div className="cu-card wide ws-embed">
      <div className="cu-chips">{ITEM_MENU.map(([k, l]) => <button key={k} className={section === k ? 'on' : ''} onClick={() => setSection(k)}>{l}</button>)}</div>
      <CatalogueItem key={`${itemId}-${section}`} itemId={itemId} section={section} />
    </div>
  );
}
