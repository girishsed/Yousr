import { useEffect, useState } from 'react';
import { api } from './api.js';

const pad = (n) => String(n).padStart(2, '0');
const iso = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

export default function Calendar({ onOpen }) {
  const today = new Date();
  const [month, setMonth] = useState(new Date(today.getFullYear(), today.getMonth(), 1));
  const [items, setItems] = useState([]);
  const [day, setDay] = useState(iso(today));
  const [msg, setMsg] = useState('');

  const first = month;
  const last = new Date(month.getFullYear(), month.getMonth() + 1, 0);

  useEffect(() => {
    api.calendar(iso(first), iso(last)).then((r) => { setItems(r); setMsg(''); }).catch((e) => setMsg(e.message));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [month]);

  const byDay = {};
  items.forEach((it) => { (byDay[it.date] = byDay[it.date] || []).push(it); });

  const lead = (first.getDay() + 6) % 7; // Monday first
  const cells = [];
  for (let i = 0; i < lead; i++) cells.push(null);
  for (let d = 1; d <= last.getDate(); d++) cells.push(new Date(month.getFullYear(), month.getMonth(), d));

  const shift = (n) => setMonth(new Date(month.getFullYear(), month.getMonth() + n, 1));
  const label = month.toLocaleDateString('en-GB', { month: 'long', year: 'numeric' });
  const dayItems = byDay[day] || [];

  return (
    <section className="cal" aria-label="Calendar">
      <div className="cal-head">
        <h2>Calendar</h2>
        <div className="inline">
          <button className="quiet" onClick={() => shift(-1)} aria-label="Previous month">‹</button>
          <span className="cal-month">{label}</span>
          <button className="quiet" onClick={() => shift(1)} aria-label="Next month">›</button>
        </div>
        <span className="hint"><span className="due-ink">Due</span> and what happened</span>
      </div>
      {msg && <p className="error" role="alert">{msg}</p>}
      <div className="cal-grid">
        {DAYS.map((d) => <div key={d} className="cal-dow">{d}</div>)}
        {cells.map((c, i) => {
          if (!c) return <div key={`e${i}`} className="cal-cell empty" />;
          const key = iso(c);
          const list = byDay[key] || [];
          const due = list.filter((x) => x.kind === 'due');
          const done = list.filter((x) => x.kind === 'activity');
          return (
            <button key={key}
              className={`cal-cell${key === iso(today) ? ' today' : ''}${key === day ? ' picked' : ''}`}
              onClick={() => setDay(key)} aria-label={`${c.getDate()} ${label}, ${list.length} items`}>
              <span className="cal-day">{c.getDate()}</span>
              {due.length > 0 && <span className="due-ink">{due.length} due</span>}
              {done.length > 0 && <span className="cal-act">{done.length} done</span>}
            </button>
          );
        })}
      </div>
      <div className="cal-list">
        <h3>{new Date(day).toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' })}</h3>
        {dayItems.length === 0 && <p className="hint">Nothing on this day.</p>}
        {dayItems.map((it, i) => (
          <button key={i} className="cal-item" onClick={() => onOpen(it.run_id, it.proc_instance_id, it.entity_id, it.entity_name)}>
            <span className={it.kind === 'due' ? 'due-ink' : 'cal-time'}>{it.kind === 'due' ? 'Due' : it.at}</span>
            <span>{it.title.replace(/^Due: /, '')}</span>
            <span className="run-meta">{it.process}{it.who ? `, ${it.who}` : ''}</span>
          </button>
        ))}
      </div>
    </section>
  );
}
