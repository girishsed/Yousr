// Simple line icons in the style of the Figma rail (24px grid, 1.6 stroke)
const P = {
  home: 'M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z',
  sidebar: 'M3 5h18v14H3zM9 5v14',
  chat: 'M4 5h16v11H9l-5 4z',
  grid: 'M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z',
  tag: 'M3 12V4h8l10 10-8 8L3 12zM7.5 7.5h.01',
  report: 'M4 20V10M10 20V4M16 20v-7M22 20H2',
  flow: 'M5 4h6v5H5zM13 15h6v5h-6zM8 9v3h8v3',
  logout: 'M15 4h4v16h-4M10 8l-4 4 4 4M6 12h11',
  newchat: 'M12 5v14M5 12h14',
  tasks: 'M4 5h16M4 12h10M4 19h7M17 15l2 2 4-4',
  calendar: 'M4 6h16v14H4zM4 10h16M8 3v4M16 3v4',
  files: 'M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z',
  id: 'M3 5h18v14H3zM7 10a2 2 0 1 0 4 0 2 2 0 1 0-4 0M6 16c.8-1.6 2-2.4 3-2.4s2.2.8 3 2.4M14 9h4M14 13h4',
  business: 'M4 21V5h10v16M14 9h6v12M7 9h4M7 13h4M7 17h4M4 21h16',
  compass: 'M12 3a9 9 0 1 0 0 18 9 9 0 1 0 0-18M15.5 8.5l-2 5-5 2 2-5z',
  settings: 'M12 9a3 3 0 1 0 0 6 3 3 0 1 0 0-6M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z',
  revenue: 'M3 17l6-6 4 4 8-8M15 7h6v6',
  vendors: 'M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8M2 21v-1a6 6 0 0 1 12 0v1M17 11a3 3 0 1 0 0-6M22 21v-1a5 5 0 0 0-4-4.9',
  compliance: 'M4 21V7l8-4 8 4v14M9 21v-6h6v6M8 10h.01M12 10h.01M16 10h.01',
  tools: 'M14.7 6.3a4 4 0 0 0-5.4 5.4L3 18l3 3 6.3-6.3a4 4 0 0 0 5.4-5.4l-2.6 2.6-2.4-.6-.6-2.4z',
  person: 'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8M4 21v-1a8 8 0 0 1 16 0v1',
  search: 'M11 4a7 7 0 1 0 0 14 7 7 0 1 0 0-14M21 21l-4.3-4.3',
  mail: 'M3 6h18v12H3zM3 7l9 6 9-6',
  back: 'M15 18l-6-6 6-6',
  chevron: 'M6 9l6 6 6-6',
  sparkle: 'M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5 18 18M6 18l2.5-2.5M15.5 8.5 18 6',
  plus: 'M12 5v14M5 12h14',
  lock: 'M6 11h12v10H6zM8 11V8a4 4 0 0 1 8 0v3',
  menu: 'M4 6h16M4 12h16M4 18h16',
  mic: 'M9 5a3 3 0 0 1 6 0v5a3 3 0 0 1-6 0zM5 10a7 7 0 0 0 14 0M12 17v4M8 21h8',
  arrowup: 'M12 19V5M6 11l6-6 6 6',
  x: 'M18 6L6 18M6 6l12 12',
  inbox: 'M4 5h16v14H4zM4 13h4l2 3h4l2-3h4',
  send: 'M10 14L21 3M21 3l-6.5 18-3.5-7-7-3.5z',
  draft: 'M14 3v5h5M17 21H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7l5 5v11',
  briefcase: 'M3 8a1 1 0 0 1 1-1h16a1 1 0 0 1 1 1v11a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1zM8 7V5a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2M3 13h18',
  trash: 'M4 7h16M10 11v6M14 11v6M5 7l1 13h12l1-13M9 7V4h6v3',
  spam: 'M8.5 3h7L21 8.5v7L15.5 21h-7L3 15.5v-7zM12 8v4M12 16h.01',
  shared: 'M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8M2 21v-1a6 6 0 0 1 12 0v1M19 8v6M22 11h-6',
};

export default function Icon({ name, size = 18 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"
      strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d={P[name] || P.home} />
    </svg>
  );
}
